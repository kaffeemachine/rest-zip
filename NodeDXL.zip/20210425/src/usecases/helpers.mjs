import dxlCfg from '../dxl-cfg.mjs'
import { Warning } from '../main/imqo-errors.mjs'
import process from 'process'
import Buffer from 'buffer'

const queueManagerName = dxlCfg.permanentQueues.queueManagerName

function nanos(hrt = process.hrtime()) {
    return hrt[0] * 1000000000 + hrt[1]
}
function nanoStr() {
    return ('0000000000000000' + nanos().toString(16)).substr(-16).toUpperCase()
}

function generateIdStr() {
    return `AMQ ${queueManagerName}            `.substr(0, 16) + nanoStr()
}

function generateId() {
    return mixedStringToBuf24(generateIdStr())
}


function hexStringToBuf(xStr) {
    return Buffer.from(xStr, 'hex')
}

function mixedStringToBuf24(mxStr) {
    return Buffer.concat([
        Buffer.from(mxStr.substr(0, 16), 'latin1'),
        Buffer.from(mxStr.substr(16), 'hex'),
    ])
}

function bufToHexString(buf) {
    return buf.toString('hex').toUpperCase()
}

function buf24ToStringPlusHexString(buf) {
    return buf.toString('latin1', 0, 16) + buf.toString('hex', 16).toUpperCase()
}

function reportPut(result) {
    let text = `${result.error?'failed':'succeeded'} to put message onto queue`
    if (result.error) {
        console.log(result.error)
        console.log(text)
    } else if (result instanceof Warning) {
        console.log(`WARNING [${result.code}] ${result.warning}`)
    } else {
        console.log(text)
        if (result.correlationId)  {
            console.log(`correlation id: ${bufToHexString(result.correlationId)}`)
            console.log(`                ${(result.correlationId.length === 24)?
                buf24ToStringPlusHexString(result.correlationId):
                result.correlationId.toString('latin1').toUpperCase()}`)
        }
        if (result.msgId) {
            console.log(`message Id: ${bufToHexString(result.msgId)}`)
            console.log(`            ${(result.msgId.length === 24)?
                buf24ToStringPlusHexString(result.msgId):
                result.msgId.toString('latin1').toUpperCase()}`)
        }
    }
}

export {
    nanos,
    nanoStr,
    generateIdStr,
    generateId,
    hexStringToBuf,
    mixedStringToBuf24,
    bufToHexString,
    buf24ToStringPlusHexString,
    reportPut,
}