import dxlCfg from '../dxl-cfg.mjs'
import {
    Connection,
    provideConnection,
} from '../main/imqo-connection.mjs'
import {
    nanoStr,
    // generateIdStr,
    generateId,
    // hexStringToBuf,
    // mixedStringToBuf24,
    // bufToHexString,
    // buf24ToStringPlusHexString,
    reportPut,
} from './helpers.mjs';
import Buffer from 'buffer'

const {
    queueManagerName,
    asyncReplyQueueName,
    asyncRequestQueueName,
    asyncReplyQueueModel,
    dynamicQueueNamePrefix,
    syncQueueName,
} = dxlCfg.bridgeCfg

const endianess = 1
const encoding ='latin1'

Connection.initialize(endianess, encoding)

const END = 'SCENARIO END <<<'

async function sendSimpleDatagramString() {
    console.log('>>> SCENARIO: Putting a simple text message onto a local queue')
    try {
        const cn = await provideConnection(queueManagerName)
        console.log(`opened local connection to ${cn.mqManagerName}`)
        const queue = await cn.createQueueWriter(syncQueueName, { })
        console.log(`opened queue ${queue.name}`)
        const msg = 'Hello MQ!'
        const result = await queue.putMessageAsync(msg, {
            msgType: 'DATAGRAM',
        })
        reportPut(result)
        await queue.close()
        console.log(`queue ${queue.name} closed`)
        await cn.close()
        console.log('connection closed')
    } catch(e) {
        console.log(e)
    }
    console.log(END)
}

async function sendSimpleDatagramBuffer() {
    console.log('>>> SCENARIO: Putting a simple text message onto a local queue')
    try {
        const cn = await provideConnection(queueManagerName)
        console.log(`opened local connection to ${cn.mqManagerName}`)
        const queue = await cn.createQueueWriter(syncQueueName, { })
        console.log(`opened queue ${queue.name}`)
        const msg = 'Hello MQ!'
        const result = await queue.putMessageAsync(Buffer.from(msg), {
            msgType: 'DATAGRAM',
        })
        reportPut(result)
        await queue.close()
        console.log(`queue ${queue.name} closed`)
        await cn.close()
        console.log('connection closed')
    } catch(e) {
        console.log(e)
    }
    console.log(END)
}

async function sendSimpleDatagramStringAndAskForMsgId() {
    console.log('>>> SCENARIO: Putting a simple text message onto a local queue - with message id generation')
    try {
        const cn = await provideConnection(queueManagerName)
        console.log(`opened local connection to ${cn.mqManagerName}`)
        const queue = await cn.createQueueWriter(syncQueueName, { })
        console.log(`opened queue ${queue.name}`)
        const msg = 'Hello MQ!'
        const result = await queue.putMessageAsync(msg, {
            msgType: 'DATAGRAM',
            generateMsgId: true,
        })
        reportPut(result)
        await queue.close()
        console.log(`queue ${queue.name} closed`)
        await cn.close()
        console.log('connection closed')
    } catch(e) {
        console.log(e)
    }
    console.log(END)
}

async function sendSimpleDatagramStringAndAskForCorrelationId() {
    console.log('>>> SCENARIO: Putting a simple text message onto a local queue - with correlation id generation')
    try {
        const cn = await provideConnection(queueManagerName)
        console.log(`opened local connection to ${cn.mqManagerName}`)
        const queue = await cn.createQueueWriter(syncQueueName, { })
        console.log(`opened queue ${queue.name}`)
        const msg = 'Hello MQ!'
        const result = await queue.putMessageAsync(msg, {
            msgType: 'DATAGRAM',
            generateCorrelationId: true,
        })
        reportPut(result)
        await queue.close()
        console.log(`queue ${queue.name} closed`)
        await cn.close()
        console.log('connection closed')
    } catch(e) {
        console.log(e)
    }
    console.log(END)
}

async function sendSimpleRequestString() {
    console.log('>>> SCENARIO: Putting a simple request message onto a local queue')
    try {
        const cn = await provideConnection(queueManagerName)
        console.log(`opened local connection to ${cn.mqManagerName}`)
        const queue = await cn.createQueueWriter(asyncRequestQueueName, { })
        console.log(`opened queue ${queue.name}`)
        const msg = 'Hello MQ!'
        const result = await queue.putMessageAsync(msg, {
            msgType: 'REQUEST',
            replyQueueName: asyncReplyQueueName,
        })
        reportPut(result)
        await queue.close()
        console.log(`queue ${queue.name} closed`)
        await cn.close()
        console.log('connection closed')
    } catch(e) {
        console.log(e)
    }
    console.log(END)
}

async function sendSimpleDatagramBufferWithMsgIdAndCorrelationId() {
    console.log('>>> SCENARIO: Putting a simple text message with MsgId and CorrelationId onto a local queue')
    try {
        const cn = await provideConnection(queueManagerName)
        console.log(`opened local connection to ${cn.mqManagerName}`)
        const queue = await cn.createQueueWriter(syncQueueName, { })
        console.log(`opened queue ${queue.name}`)
        const msg = 'Hello MQ!'
        const result = await queue.putMessageAsync(Buffer.from(msg), {
            msgType: 'DATAGRAM',
            msgId: generateId(),
            correlationId: generateId(),
        })
        reportPut(result)
        await queue.close()
        console.log(`queue ${queue.name} closed`)
        await cn.close()
        console.log('connection closed')
    } catch(e) {
        console.log(e)
    }
    console.log(END)
}

async function sendSimpleRequestBufferWithMsgIdAndCorrelationId() {
    console.log('>>> SCENARIO: Putting a simple text request with MsgId and CorrelationId onto a local queue')
    try {
        const cn = await provideConnection(queueManagerName)
        console.log(`opened local connection to ${cn.mqManagerName}`)
        const queue = await cn.createQueueWriter(asyncRequestQueueName, { })
        console.log(`opened queue ${queue.name}`)
        const msg = 'Hello MQ!'
        const correlationId = generateId()
        const result = await queue.putMessageAsync(Buffer.from(msg), {
            msgType: 'REQUEST',
            msgId: generateId(),
            correlationId,
            replyQueueName: asyncReplyQueueName,
        })
        reportPut(result)
        await queue.close()
        console.log(`queue ${queue.name} closed`)
        await cn.close()
        console.log('connection closed')
    } catch(e) {
        console.log(e)
    }
    console.log(END)
}

// async function sendSimpleRequestBufferWithZeroLeadingCorrelationId() {
//     console.log('>>> SCENARIO: Putting a simple text request with CorrelationId with 16 leading 0-bytes onto a local queue')
//     try {
//         const cn = await provideConnection(queueManagerName)
//         console.log(`opened local connection to ${cn.mqManagerName}`)
//         const queue = await cn.createQueueWriter(asyncRequestQueueName, { })
//         console.log(`opened queue ${queue.name}`)
//         const msg = 'Hello MQ!'
//         const id = '\0'.repeat(16) + nanoStr()
//         // eslint-disable-next-line no-undef
//         const correlationId = Buffer.concat([
//             Buffer.from(id.substr(0, 16), 'latin1'),
//             Buffer.from(id.substr(16), 'hex')
//         ])
//         const result = await queue.putMessageAsync(Buffer.from(msg), {
//             msgType: 'REQUEST',
//             correlationId,
//             replyQueueName: asyncReplyQueueName,
//         })
//         reportPut(result)
//         await queue.close()
//         console.log(`queue ${queue.name} closed`)
//         await cn.close()
//         console.log('connection closed')
//     } catch(e) {
//         console.log(e)
//     }
//     console.log(END)
// }

async function sendSimpleRequestBufferWith8BytesWideCorrelationId() {
    console.log('>>> SCENARIO: Putting a simple text request with a 8 bytes wide CorrelationId onto a local queue')
    try {
        const cn = await provideConnection(queueManagerName)
        console.log(`opened local connection to ${cn.mqManagerName}`)
        const queue = await cn.createQueueWriter(asyncRequestQueueName, { })
        console.log(`opened queue ${queue.name}`)
        const msg = 'Hello MQ!'
        const id = nanoStr()
        const correlationId = parseInt('0x' + id.toString(16))
        console.log(`input correlationId: ${id}`)
        const result = await queue.putMessageAsync(Buffer.from(msg), {
            msgType: 'REQUEST',
            correlationId,
            replyQueueName: asyncReplyQueueName,
        })
        reportPut(result)
        await queue.close()
        console.log(`queue ${queue.name} closed`)
        await cn.close()
        console.log('connection closed')
    } catch(e) {
        console.log(e)
    }
    console.log(END)
}

async function sendRequestAndReceiveReplyViaDynamicQueue() {
    console.log('>>> SCENARIO: Create dynamic queue to receive reply to request sent before')
    try {
        const cn = await provideConnection(queueManagerName)
        console.log(`opened local connection to ${cn.mqManagerName}`)
        const dynQueue = await cn.createDynamicReplyQueue(dynamicQueueNamePrefix, {
            modelQueueName: asyncReplyQueueModel,
            readExclusive: true,
            failIfQuiescing: true,
        })
        console.log(`created dynamic queue ${dynQueue.name}`)
        const queue = await cn.createQueueWriter(asyncRequestQueueName, { })
        console.log(`opened queue ${queue.name}`)
        const msg = 'Hello MQ!'
        const id = nanoStr()
        const correlationId = parseInt('0x' + id, 'hex')
        console.log(`input correlationId: ${id}`)
        const result = await queue.putMessageAsync(Buffer.from(msg), {
            msgType: 'REQUEST',
            correlationId,
            replyQueueName: asyncReplyQueueName,
        })
        reportPut(result)
        await queue.close()
        console.log(`queue ${queue.name} closed`)
        await cn.close()
        console.log('connection closed')
    } catch(e) {
        console.log(e)
    }
    console.log(END)
}

async function runScenarios() {
    console.group('SCENARIO GROUP: Putting messages')
    await sendSimpleDatagramString()
    await sendSimpleDatagramBuffer()
    await sendSimpleDatagramStringAndAskForMsgId()
    await sendSimpleDatagramStringAndAskForCorrelationId()
    await sendSimpleRequestString()
    await sendSimpleDatagramBufferWithMsgIdAndCorrelationId()
    await sendSimpleRequestBufferWithMsgIdAndCorrelationId()
    // await sendSimpleRequestBufferWithZeroLeadingCorrelationId()
    await sendSimpleRequestBufferWith8BytesWideCorrelationId()
    await sendRequestAndReceiveReplyViaDynamicQueue()   
}

runScenarios()