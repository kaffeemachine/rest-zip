import { 
    Connection,
    provideConnection,
} from '../main/imqo-connection.mjs'
import Message from '../main/imqo-message.mjs'
import { Warning } from '../main/imqo-errors.mjs'
import dxlCfg from '../dxl-cfg.mjs'
import { reportPut, } from './helpers.mjs'
import { strict as assert } from 'assert'

const {
    endianess,
    encoding,
    queueManagerName,
    asyncReplyQueueModel,
    asyncRequestQueueName,
    dynamicQueueNamePrefix,
    syncQueueName
} = dxlCfg.bridgeCfg

const END = 'SCENARIO END <<<'

async function pauseForMs(ms) {
    return new Promise(resolve => {
        setTimeout(resolve, ms)
    })
}

Connection.initialize(endianess, encoding)

function reportGet(result) {
    let text
    if (result instanceof Message) {
        text = `result: ${result.typeStr} content: ${result.contentString}`
        console.log(text)
    } else if (result instanceof Warning) {
        text = `WARNING [${result.code}] ${result.verb}: ${result.message}`
        console.log(text)
    }
}

// eslint-disable-next-line no-unused-vars
function printId(id) {
    if (typeof id === 'string' || typeof id === 'number') {
        console.log(id)
    // eslint-disable-next-line no-undef
    } else if (id instanceof Buffer) {
        console.log(buf2HexString(id))
    } else {
        console.log(id.toString())
    }
}

function buf2HexString(id) {
    return '0x' + id.reduce((a, v) => a + v.toString(16), '').toUpperCase()
}

async function getMessageAsync(queueReader, options) {
    return new Promise((resolve, reject) => {
        queueReader.getMessage(options, (err, data) => {
            queueReader.getDone()
            if (err) {
                return reject(err)
            }
            resolve(data)
        })
    })
}

async function pauseOfMs(ms) {
    return new Promise(resolve => {
        setTimeout(resolve, ms)
    })
}

// eslint-disable-next-line no-unused-vars
async function retrieveSimpleDatagramString() {
    console.log('>>> SCENARIO: Retrieving a simple text message from a local queue')
    try {
        const cn = await provideConnection(queueManagerName)
        let text = `opened local connection to ${cn.mqManagerName}`
        console.log(text)
        let queue = await cn.createQueueWriter(syncQueueName, { })
        text = `opened queue ${queue.name} for writing`
        console.log(text)
        const msg = 'Hello asynchronous MQ!'
        let result = await queue.putMessageAsync(msg, {
            msgType: 'DATAGRAM',
        })
        reportPut(result)
        await queue.close()
        text = `queue ${queue.name} closed`
        console.log(text)
        queue = await cn.createQueueReader(syncQueueName, { })
        text = `opened queue ${queue.name} for reading`
        console.log(text)
        result = await getMessageAsync(queue, {
            wait: true,
            waitInterval: 1000,
        })
        reportGet(result);
        await cn.close()
        console.log('connection closed')
    } catch(e) {
        console.log(e)
    }
    console.log(END)
}

async function handleRequestReplySequence() {
    console.log('>>> SCENARIO: sending request and retrieving reply from dynamic queue')
    try {
        const cn = await provideConnection(queueManagerName)
        let text = `opened local connection to ${cn.mqManagerName}`
        console.log(text)
        let dynQueue = await cn.createDynamicReplyQueue(dynamicQueueNamePrefix, { 
            dynamic: true,
            readExclusive: true,
            modelQueueName: asyncReplyQueueModel,
            tx: false,
        })
        const dynamicQueueName = dynQueue.name
        text = `created dynamic queue ${dynamicQueueName} for reading`
        console.log(text)

        // put request
        let queueWriter = await cn.createQueueWriter(asyncRequestQueueName, { })
        text = `opened queue ${queueWriter.name} for writing`
        console.log(text)
        const msg = 'Hello asynchronous MQ!'
        let result = await queueWriter.putMessageAsync(msg, {
            msgType: 'REQUEST',
            generateCorrelationId: true,
            replyQueueName: dynamicQueueName,
        })
        const correlationId = result.correlationId
        console.log('Correlation Id:', buf2HexString(correlationId))
        reportPut(result)
        await queueWriter.close()
        text = `queue ${queueWriter.name} closed`
        console.log(text)

        // get request by correlation id
        let queueReader = await cn.createQueueReader(asyncRequestQueueName, { })
        text = `opened queue ${queueReader.name} for reading`
        console.log(text)
        if (cn.isClosed) {
            console.err('Connection closed - terminating this use case prematurlely')
        }
        try {
            result = await queueReader.getFirstMessageAsync({
                correlationId,
                wait: false,
            })
        } catch(err) {
            console.log(err)
            return console.err('terminating this use case prematurely')
        }
        reportGet(result)
        await queueReader.close()
        text = `queue ${queueReader.name} closed`
        console.log(text)
        // put reply
        result = await result.putReplyAsync('Same back!', {
            generateCorrelationId: false,
            correlationId,
        })
        const newCorrelationId = result.correlationId
        assert(newCorrelationId === correlationId)
        console.log('wrote reply')
        console.log('Correlation Id:', buf2HexString(newCorrelationId))
        console.log('reading reply queue')
        if (cn.isClosed) {
            console.err('Connection closed - terminating this use case prematurlely')
        }
        try {
            result = await dynQueue.getFirstMessageAsync({
                correlationId,
                wait: false,
            })
        } catch(err) {
            console.log(err)
            return console.err('terminating this use case prematurlely')
        }
        reportGet(result)
        await dynQueue.close()
        text = `dynamic queue ${dynQueue.name} closed`
        console.log(text)
        await pauseOfMs(1000)
        await cn.close()
        console.log('connection closed')
    } catch(e) {
        console.log(e)
    }
    console.log(END)
}

// eslint-disable-next-line no-unused-vars
async function handleRequestReplyWithPolling() {
    console.log('>>> SCENARIO: sending request and retrieving reply from dynamic queue')
    let cleanup
    try {
        const cn = await provideConnection(queueManagerName)
        console.log(`opened local connection to ${cn.mqManagerName}`)
        let dynQueue = await cn.createDynamicReplyQueue(dynamicQueueNamePrefix, { 
            dynamic: true,
            readExclusive: true,
            modelQueueName: asyncReplyQueueModel,
            tx: false,
        })
        const dynamicQueueName = dynQueue.name
        console.log(`created dynamic queue ${dynamicQueueName} and opened it for reading`)

        cleanup = async function () {
            try {
                if (dynQueue.isOpen) {
                    await dynQueue.close()
                    console.log(`closed dynamic queue ${dynQueue.name}`)
                }
                if (cn.isOpen) {
                    await cn.close()
                    console.log(`closed connection to ${cn.mqManagerName}`)
                }
            } catch(err) {
                console.log(err)
            }
        }

        // put request
        let asyncRequestQueueWriter = await cn.createQueueWriter(asyncRequestQueueName, { })
        console.log(`opened queue ${asyncRequestQueueWriter.name} for writing`)
        const msg = 'Hello asynchronous MQ!'
        let result = await asyncRequestQueueWriter.putMessageAsync(msg, {
            msgType: 'REQUEST',
            generateCorrelationId: true,
            replyQueueName: dynamicQueueName,
        })
        let correlationId = result.correlationId
        console.log(correlationId.toString('latin1'))
        reportPut(result)
        await asyncRequestQueueWriter.close()
        console.log(`queue ${asyncRequestQueueWriter.name} closed`)

        // retrieve request
        let asyncRequestQueueReader = await cn.createQueueReader(asyncRequestQueueName, { })
        console.log(`opened queue ${asyncRequestQueueReader.name} for reading`)

        let request = await getMessageAsync(asyncRequestQueueReader, {
            correlationId,
        })
        reportGet(request)
        await asyncRequestQueueReader.close()
        console.log(`queue ${asyncRequestQueueReader.name} closed`)

        if (request) {
            try {
                await run()
                console.log('executed run()')
            } catch(err) {
                console.log(err)
            }
        }
        await cleanup()

        // eslint-disable-next-line no-inner-declarations
        async function reply() {
            await pauseForMs(3000)
            if (request)
            {
                try {
                    await request.putReplyAsync('Same back!')
                    console.log(`wrote reply for correlation id ${correlationId.toString('hex').toUpperCase()} to queue ${request.replyQueueName}`)
                } catch(err ) {
                    console.log(err)
                }
            }
        }

        // eslint-disable-next-line no-inner-declarations
        async function pollReply() {
            return dynQueue.getFirstMessageAsync({
                delay: 1000,
                interval: 200,
                waitInterval: 6000,
                correlationId,
            })
        }

        // eslint-disable-next-line no-inner-declarations
        async function run() {
            return Promise.all([
                reply(),
                pollReply(),
            ]).then(reply => {
                reportGet(reply?.[1])
                console.log('finished')
            }).catch(err => {
                console.log(err)
            })
        }

    } catch(err) {
        console.log(err)
        await cleanup()
    } finally {
        cleanup?.call()
        console.log(END)
    }
}

async function readMessagesFromaQueueReaderStream() {
    console.log('>>> SCENARIO: reading a batch of messages using a QueueReader stream')

    // const messages = [
    //     'greeting 0',
    //     'greeting 1',
    //     'greeting 2',
    //     'greeting 3',
    //     'greeting 4',
    //     'greeting 5',
    //     'greeting 6',
    //     'greeting 7',
    //     'greeting 8',
    //     'greeting 9',
    // ]


    // let cn
    // let queue
    // let reader
    // try {
    //     cn = await provideConnection(queueManagerName)
    //     let text = `opened local connection to ${cn.mqManagerName}`
    //     console.log(text)
    //     queue = await cn.createQueueWriter(syncQueueName, { })
    //     text = `opened queue ${queue.name} for writing`
    //     console.log(text)
    //     messages.forEach(async msg => {
    //         const result = await queue.putMessageAsync(msg, {
    //             msgType: 'DATAGRAM',
    //         })
    //         reportPut(result)
    //     })
    //     await queue.close()
    //     text = `queue ${queue.name} closed`
    //     console.log(text)
    //     reader = await cn.createReadableQueueStream(syncQueueName, {})
    //     console.log(reader)
    //     let data
    //     while ((data = await reader.read())) {
    //         console.log(data)
    //     }
    //     reader.on('error', err => {
    //         console.log(err)
    //     })

    // } catch(err) {
    //     console.log(err)
    // } finally {
    //     cleanup.call()
        console.log(END)
    // }

    // async function cleanup() {
    //     if (queue.isOpen) {
    //         await queue.close()
    //     }
    //     if (cn.isOpen) {
    //         await cn.close()
    //     }
    //     reader?.destroy()
    // }
}

let timer = setInterval(() => {}, 200)

async function runScenarios() {
    console.group('SCENARIO GROUP: Retrieving messages')
    await retrieveSimpleDatagramString()
    await handleRequestReplySequence()
    await handleRequestReplyWithPolling()
    await readMessagesFromaQueueReaderStream()
    clearInterval(timer)
}

runScenarios()
