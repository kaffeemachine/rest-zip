// import { MQC } from 'ibmmq'
import { Connection } from '../main/imqo-connection.mjs'

import dxlCfg from '../dxl-cfg.mjs'

const {
    queueManagerName,
    // asyncReplyQueueName,
    // asyncReplyQueueModel,
    // asyncRequestQueueName,
    // asyncRequestQueueModel,
    // dynamicQueueNamePrefix
} = dxlCfg.permanentQueues

let timer = setInterval(() => {}, 200)

async function openLocalConnection() {
    console.log('SCENARIO: Opening a local connection and closing it.')
    try {
        const cn1 = new Connection(queueManagerName)
        await cn1.connect()
        console.log(`opened connection to ${queueManagerName} without options`)
        const h = cn1.hCn
        const cn2 = Connection.getConnectionByHandle(h)
        console.log(`connection retrieved by handle ${h} is the same as the original connection:`,
            cn1 === cn2)
        await cn1.close()
        console.log('connection closed')
    } catch (e) {
        console.log(e)
    }
    console.log('SCENARIO END')
    clearInterval(timer)
}

openLocalConnection() 