This folder holds non-production code. In this code, I led some experiments 
for a proof of concept.