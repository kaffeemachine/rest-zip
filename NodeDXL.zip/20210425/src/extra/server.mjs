import net from 'net'
import process from 'process'
import split2 from 'split2'

import dxlEnv from '../dxl-cfg.mjs'

const { 
    listenerCfg,
    commCtl,
} = dxlEnv

const {
    messageSeparator,
    maxSizeSplitBuf,
} = commCtl

process.on('uncaughtException', err => {
    console.log('uncaughtException', err)
    process.exitCode = 1
})

process.on('unhandledRejection', reason => {
    console.log('unhandledRejection', reason)
    process.exitCode = 2
})

const log = console.log.bind(console)

class DxlListener {
    server
    reader
    currentClientId = 0
    constructor() { }

    start() {
        this.server = net.createServer({}, socket => {
            socket.setEncoding(listenerCfg.encoding)
            this.reader = socket.pipe(new split2(messageSeparator), {
                maxLength: maxSizeSplitBuf,
                skipOverflow: true,
            }).on('data', log).on('error', log)
        })
        this.server.on('error', log)
        const { host, port } = listenerCfg
        this.server.listen(listenerCfg, () => log(`DXL server ${host} listening at port ${port}`))
    }

    stop() {
        this.server.close(() => log('DXL listen service closed'))
    }
}

const server = new DxlListener()
server.start()
