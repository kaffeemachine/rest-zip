import {
    encode,
    decode,
} from '../demo/dxl-codec.mjs'


function test() {



    let msg = {
        flags: 1,
        timeout: 900,
        msgType: 'REQUEST',
        body: 'Hello, DXL listener!',
        requestId: 5042557362783369795n,
        // requestId: 0x45fac334703bba43n,
    }
    let encoded = encode(0, msg)
    let decoded = decode(0, encoded)
    encoded = encode(0, decoded)
    decoded = decode(0, encoded)
}

test()
