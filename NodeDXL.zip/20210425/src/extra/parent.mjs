import { fork } from 'child_process'



let child = fork('./src/extra/child.mjs', ['hello, World!', 'How do you do'])
child.on('message', msg => {
    console.log('PARENT GOT:', msg)
    console.log('type:', typeof msg)
    console.log('msg is error:', msg instanceof Error)
    if (msg.error) {
        let err = new Error(msg.message)
        err.stack = msg.stack
        console.log('msg is error message for:', err)
        console.log('stack:', err.stack)
    }
    child.send('so let\'s go on!')
})
