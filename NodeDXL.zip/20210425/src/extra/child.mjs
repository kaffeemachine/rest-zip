
import process from 'process'

class ErrorMessage {
    error = true
    constructor(err) {
        this.name = err.name
        this.message = err.message
        this.stack = err.stack
        this.fileName = err.fileName
        this.lineNumber = err. lineNumber
        this.columnNumber = err.columnNumber
    }
}

let phase = 0
process.on('message', msg => {
    console.log('CHILD GOT:', msg)
    if (phase++ > 0) {
        return
    }
    switch(msg) {
        case 'so let\'s go on!':
            try {
                console.log('AT CHILD:', 'having fun')
                throw new Error('just for fun!')
            }  catch(err) {
                process.send(new ErrorMessage(err))
            }
            process.send('do you believe me?')
            break
    }
})

setTimeout(() => process.send('ready'))
process.nextTick(() => process.send('ticking well'))
// eslint-disable-next-line no-undef
setImmediate(() => process.send('acting immediately'))

function runMt() {
    queueMicrotask(() => process.send('microtasking works well!'))
}

runMt()
