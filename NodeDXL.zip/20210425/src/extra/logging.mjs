import {
    LogLevel,
    logger,
    initializeDiagnostics,
} from '../dxl/dxl-diagnostics.mjs'

const init = (DBG, LLL) => {
        console.log(`\nDEBUG: ${DBG}, Log Level: ${LLL}\n==============================================================================`)
    initializeDiagnostics(DBG, LogLevel[LLL])
}

const longMessage = 'this is a very long message *******' +
'*******************************************************' +
'*******************************************************' +
'*******************************************************' +
'*******************************************************' +
'*******************************************************' +
'*******************************************************' +
'*******************************************************' +
'*******************************************************' +
'*******************************************************' +
'*******************************************************'

const shortMessage = 'this is a short message'

const write = () => {
    console.log('with code')
    logger.complete('S001', longMessage)
    logger.verbose('S002', longMessage)
    logger.debug('S003', longMessage)
    logger.info('S004', longMessage)
    logger.warning('S005', longMessage)
    logger.error('S006', longMessage)
    logger.complete('S001', shortMessage)
    logger.verbose('S002', shortMessage)
    logger.debug('S003', shortMessage)
    logger.info('S004', shortMessage)
    logger.warning('S005', shortMessage)
    logger.error('S006', shortMessage)
    console.log('without code')
    logger.complete(longMessage)
    logger.verbose(longMessage)
    logger.debug(longMessage)
    logger.info(longMessage)
    logger.warning(longMessage)
    logger.error(longMessage)
    logger.complete(shortMessage)
    logger.verbose(shortMessage)
    logger.debug(shortMessage)
    logger.info(shortMessage)
    logger.warning(shortMessage)
    logger.error(shortMessage)
}

init(true, 'complete')
write()
init(true, 'verbose')
write()
init(true, 'debug')
write()
init(true, 'info')
write()
init(true, 'warning')
write()
init(true, 'error')
write()
init(false, 'complete')
write()
init(false, 'verbose')
write()
init(false, 'debug')
write()
init(false, 'info')
write()
init(false, 'warning')
write()
init(false, 'error')
write()

