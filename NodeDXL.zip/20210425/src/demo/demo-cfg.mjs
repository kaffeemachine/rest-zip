import assert from 'assert/strict'
import dxlCfg from '../dxl-cfg.mjs'
import {
    LogLevel,
} from '../dxl/dxl-diagnostics.mjs'

const DEBUG = dxlCfg.DEBUG || true
const LOG_LEVEL = dxlCfg.LOG_LEVEL || LogLevel.info

const {
    endianess,
    encoding,
} = dxlCfg.bridgeCfg

assert(endianess !== undefined, 'DEMO ENV: endianess not set')
assert(encoding !== undefined, 'DEMO ENV: encoding not set')
 
const {
    messageSeparator,
    maxSizeSplitBuf,
} = dxlCfg.commCtl

// C - client, S - server (DXL Listener)
const conversationExpirePhase = 10 * 1000 // (C, S) ms to wait after delivery/receipt of quiescing message to start another conversation
const messageStackSize = 10000 // determines how many different messages a generated on start - they will be sent sequentially in a loop
const maxClientDelayForPollrequests = 8000 // (C) maximal time in ms to wait before a poll request is sent after receipt of correlation id
const maxClientDelayBetweenRequests = 2800  // (C) ms - use this to tune the frequency with which the client sends datagrams and requests
const minClientDelayBetweenRequests = 100  // (C) ms - use this to tune the frequency with which the client sends datagrams and requests

const restartLatency = 1000 // (C) pause before a new connection is tried after a QUIESCE message

const clientCfg = {
    ...dxlCfg.listenerCfg, // host, port
    endianess,
    encoding,
    messageSeparator,
    maxSizeSplitBuf,
    conversationExpirePhase,
    messageStackSize,                
    maxClientDelayForPollrequests,  
    maxClientDelayBetweenRequests,
    minClientDelayBetweenRequests,
    restartLatency,
    DEBUG,
    LOG_LEVEL
}

const demoDuration = 15 * 60 * 1000 + 5000 // (S) ms after which to shutdown the DXL server
dxlCfg.bridgeCtl.runInProcess = true
dxlCfg.bridgeCtl.forwardSocketToChild = true

dxlCfg.bridgeCfg.balanceWheelInterval = 2

const demoCfg = {
    ...dxlCfg,
    DEBUG,
    LOG_LEVEL,
    clientCfg,
    demoDuration,
    endianess,
    encoding,
}

demoCfg.DEBUG = true
demoCfg.LogLevel = LogLevel.debug

export default demoCfg
