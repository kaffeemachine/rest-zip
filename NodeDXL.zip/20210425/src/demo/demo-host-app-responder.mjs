import {
    Connection,
    // setTuningParameters,
    provideConnection,
} from '../main/imqo-connection.mjs'
import {
    Warning,
} from '../main/imqo-errors.mjs'
import demoCfg from './demo-cfg.mjs'
import {
    logger,
    initializeDiagnostics,
} from '../dxl/dxl-diagnostics.mjs'
import {
    makeReply,
} from './demo-random-data.mjs'
import {
    initializeCodec,
    decode,
    encode,
} from '../dxl/dxl-codec.mjs'
import assert from 'assert/strict'

const {
    bridgeCfg,
    endianess,
    encoding,
    demoDuration,
} = demoCfg

assert(endianess !== undefined, 'HOST APP RESPONDER: endianess not set')
assert(encoding !== undefined, 'HOST_APP REPONDER: encoding not set')

const {
    queueManagerName,
    asyncRequestQueueName,
} = bridgeCfg

initializeDiagnostics(demoCfg.DEBUG, demoCfg.LOG_LEVEL) // sets DEBUG
initializeCodec(false, endianess, encoding) // first argument sets DEBUG
Connection.initialize(endianess, encoding)

logger.info('RESP 001', `application host responder polling at queue ${asyncRequestQueueName}`)

let tm
let resolve
async function wait(ms) {
    return new Promise(done => {
        resolve = done
        tm = setTimeout(done, ms)
    })
}

let cn
let queue
let terminating = false

// setTuningParameters({
//     getLoopPollTimeMs: 500,
//     getLoopDelayTimeMs: 100,
// })

let requestsReceived = 0
let repliesSent = 0

async function receive() {
    let dynQueues = new Map()
    try {
        cn = cn || await provideConnection(queueManagerName)
        queue = await cn.createQueueReader(asyncRequestQueueName, {
            readExclusive: true,
        })
        queue.getMessage({
            wait: true,
            waitInterval: 100000, //demoDuration,
            // waitInterval: 3 * 1000 * 60 // wait 3 minutes
        }, (err, result) => {
            if (err) {
                if (err.mqrc === 2033 ||  err.mqrc === 2018 || terminating) {
                    return
                }
                return logger.error('RESP 002', err.message)
            } else if (result instanceof Error) {
                return logger.error('RESP 003', err)
            }
            if (result instanceof Warning) {
                return logger.warning('RESP 004', result)
            }
            logger.verbose('RESP 005', `result: ${result.constructor.name}`)
            if (result.constructor.name === 'Message' &&
                // eslint-disable-next-line no-undef
                result.content instanceof Buffer) {
                if (result.contentBuffer?.slice(0, 4).toString(encoding) === 'FYC ') {
                    let msg = decode(-1, result.contentBuffer)
                    if (msg.body) {
                        logger.verbose('RESP 006', msg.body)
                    }
                } else {
                    logger.verbose('RESP 007', '' + result.contentString)
                }
            }
            try {
                if (result.contentBuffer?.slice(0, 4).toString(encoding) === 'FYC ') {
                    requestsReceived++
                    let msg = decode(-1, result.contentBuffer)
                    if (msg.body) {
                        logger.verbose('RESP 008', msg)
                    }
                    // prepare for reply
                    logger.info('RESP 009', 'replying')
                    const reply = makeReply(msg.body, msg.requestId, result.replyQueueName, result.replyQueueManagerName, encoding)
                    const binReply = encode(-1, reply)
                    const dynReplyQueueName = result.replyQueueName
                    const sendReply = (dynReplyQueue, binReply, msg) => {
                        dynReplyQueue.putMessage(binReply, {
                            correlationId: msg.requestId,
                            msgId: msg.requestId,
                            msgType: 'REPLY',
                        }, err => {
                            if (err &&
                                err.mqrc !== 2018 && err.mqrc !== 2052) {
                                    return logger.error('RESP 010', err)
                            }
                            repliesSent++
                            logger.info('RESP 011', `Host App Reply Service: Message #${repliesSent}`) 
                            logger.verbose('RESP 012', `${binReply.toString(encoding)}\nsent reply with correlation id ${msg.requestId} to dynamic queue ${dynReplyQueue.name}`)
                        }, endianess,)
                    }
                    if (dynQueues.has(dynReplyQueueName)) {
                        sendReply(dynQueues.get(dynReplyQueueName), binReply, msg)
                    } else {
                        let drq = null
                        cn.createQueueWriter(dynReplyQueueName).
                        then(dynReplyQueue => {
                            drq = dynReplyQueue
                            sendReply(dynReplyQueue, binReply, msg)
                            dynQueues.set(dynReplyQueueName, dynReplyQueue)
                        }).catch(err => {
                            drq?.isOpen && drq.close()
                            dynQueues.delete(dynReplyQueueName)
                            logger.error('RESP 013', err)
                        })
                    }
                } else {
                    logger.verbose('RESP 014', result.contentString)
                }
                // stop by message
                if (result.contentString === 'x') {
                    logger.info('RESP 015', 'terminating...')
                    queue?.getDone(err => {
                        terminating = true
                        clearTimeout(tm)
                        resolve()
                        logger.info('RESP 016', 'done')
                        if (err) {
                            logger.error('RESP 017', err.message)
                        }
                    })
                }
            } catch(err) {
                logger.error('RESP 018', err)
            }
        })
    } catch(err) {
        logger.error('RESP 019', err)
        if (!terminating) {
            receive()
        }
    }
}

let clock = setInterval(() => {
    logger.info('RESP 020', new Date())
}, 60000)

receive().then( async () => {
    await wait(demoDuration)
    terminating = true
    await wait(2000)
    if (queue && queue.isOpen) {
        await queue.close()
    }
    if (cn && cn.isOpen) {
        await cn.close()
    }
    logger.info('RESP 021', 'STATISTICS:')
    logger.info(`\treceived ${requestsReceived} requests`)
    logger.info(`\tsent ${repliesSent} replies`)
    logger.info('RESP 022', 'That\'s it!')
    clearInterval(clock)
})
