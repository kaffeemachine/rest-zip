import DxlListener from '../dxl/dxl-listener.mjs'
import demoCfg from './demo-cfg.mjs'
import {
    initializeDiagnostics,
} from '../dxl/dxl-diagnostics.mjs'

initializeDiagnostics(demoCfg.DEBUG, demoCfg.LOG_LEVEL)


const dl = new DxlListener(demoCfg)
setTimeout(() => dl.stop(), demoCfg.demoDuration)
dl.start()
