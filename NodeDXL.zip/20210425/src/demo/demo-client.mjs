import net from 'net'
import demoCfg from './demo-cfg.mjs'
import split2 from 'split2'
import assert from 'assert/strict'
import fs from 'fs-extra'
import path from 'path'
import {
    initializeDiagnostics,
    logger,
} from '../dxl/dxl-diagnostics.mjs'

const {
    DEBUG,
    port,
    host,
    endianess,
    encoding,
    messageSeparator,
    maxSizeSplitBuf,
    conversationExpirePhase,
    messageStackSize,
    maxClientDelayForPollrequests,
    maxClientDelayBetweenRequests,
    minClientDelayBetweenRequests,
    restartLatency,
} = demoCfg.clientCfg

assert(endianess !== undefined, 'DECODE: endianess not set')
assert(encoding !== undefined, 'DECODE: encoding not set')

import {
    makeRandomMessage,
} from './demo-random-data.mjs'
import {
    extractCorrelationId,
    initializeCodec,
} from '../dxl/dxl-codec.mjs'

let errors = 0
const errThreshold = 100000

initializeDiagnostics(demoCfg.DEBUG, demoCfg.LOG_LEVEL)
initializeCodec(DEBUG, endianess, encoding)

const noop = () => {}
const rgxRequest = /BusnResult="Y"/

let i = 0
const fatMessages = []
for (const num of [4, 21, 22, ]) {
    const fileName = `DXL_ExampleMessage${num}.xml`
    const filePath = path.resolve('.', 'src', 'demo', 'data', fileName)
    const xml = fs.readFileSync(filePath, { encoding: 'utf8', })
    fatMessages.push([xml, rgxRequest.test(xml)? 0 : 1])
}

const messages = []
while (i++ < messageStackSize) { 
    const msg = (Math.random() < 0.05)?
        fatMessages[Math.floor(fatMessages.length * Math.random())]:
            makeRandomMessage()
    messages.push([msg, rgxRequest.test(msg)])
}
i = 0

class DxlClient {
    socket
    reader
    stop = false
    messagesSent = 0
    requestsSent = 0
    datagramsSent = 0
    pollRequestsSent = 0
    correlationIdsReceived = 0
    repliesReceived = 0
    holdInBufferTogglings = 0
    suspending = false
    cachedMessages = []
    holdInBuffer = false
    #start
    #sendMessageAtRandom
    #sendPollRequest
    #requestTimer
    #pollRequestTimer
    constructor() {
        this.#start = this.start.bind(this)
        this.#sendMessageAtRandom = this.sendMessageAtRandom.bind(this)
        this.#sendPollRequest = this.sendPollRequest.bind(this)
    }
    sendMessageAtRandom() {
        if (this.stop || this.suspending || !this.socket || this.socket.destroyed) {
            logger.info('CLIENT 001', `sendMessageAtRandom: RETURN CAUSE ${this.stop?'STOP':'SUSPENDING'}`)
            return
        }
        i = (i + 1) % messageStackSize
        try {
            if (this.holdInBuffer) {
                logger.verbose('CLieNT 002', '************ CACHING ON ****************')
                this.cachedMessages.push(messages[i])
            } else {
                let holdInBuffer
                while (!this.holdInBuffer && this.cachedMessages.length > 0) {
                    logger.verbose('CLIENT 003', '************ CLEARING CACHE ****************')
                    holdInBuffer = this.holdInBuffer
                    const msg = this.cachedMessages.splice(0, 1)[0]
                    this.holdInBuffer = !this.send(msg[0])
                    msg[1] ? this.requestsSent++ : this.datagramsSent++
                    logger.info('CLieNT 004', `sendMessageAtRandom: ${msg?.[1] ? 'REQUEST' : 'DATAGRAM'} SENT`)
                    if (holdInBuffer != this.holdInBuffer) {
                        this.holdInBufferTogglings++
                        logger.verbose('CLIENT 005', '************ CACHING ON ****************')
                    }
                }
                holdInBuffer = this.holdInBuffer
                if (!holdInBuffer) {
                    logger.verbose('CLIENT 006', '************ CACHING OFF ****************')
                    this.holdInBuffer = !this.send(messages[i][0])
                    messages[i]?.[1] ? this.requestsSent++ : this.datagramsSent++
                    if (holdInBuffer != this.holdInBuffer) {
                        this.holdInBufferTogglings++
                        logger.verbose('CLIENT 007', '************ CACHING ON ****************')
                    }
                    logger.info('CLIENT 008', `sendMessageAtRandom: ${messages[i]?.[1] ? 'REQUEST' : 'DATAGRAM'} #${messages[i]?.[1] ? this.requestsSent : this.datagramsSent} SENT`)
                }
                let timeSpan = Math.floor((maxClientDelayBetweenRequests - minClientDelayBetweenRequests) * Math.random() ** 4) + minClientDelayBetweenRequests
                this.#requestTimer = setTimeout(this.#sendMessageAtRandom, timeSpan)
            }
         } catch(err) { noop() }
    }
    send(msg) {
        const hold = this.socket.write(msg + messageSeparator)
        this.messagesSent++
        return hold
    }
    start() {
        i = 0
        try {
            this.socket = net.connect(port, host, () => {
                this.socket.setEncoding(encoding)
                this.holdInBuffer = false
                this.suspending = false
                this.stop = false
                logger.info('CLIENT 009', `connected to ${host}:${port}`)
            })
            this.socket.on('ready', () => {
                this.sendMessageAtRandom()
            })
            this.reader = this.socket.pipe(split2(messageSeparator), {
                maxLength: maxSizeSplitBuf,
                skipOverflow: true,
            })
            this.socket.on('end', () => {
                logger.info('CLIENT 010', 'session ended')
                clearTimeout(this.#requestTimer)
                this.stop = true
            })
            this.socket.on('close', () => {
                this.stop = true
                logger.info('CLIENT 011', 'connection closed')
                clearTimeout(this.#requestTimer)
                this.reportStatistics()
            })
            this.socket.on('drain', () => {
                this.holdInBuffer = false
            })
            this.socket.on('data', data => {
                logger.verbose('CLIENT 012', `data: ${data}`)
                if (/<SVR_SUSPEND/.test(data)) {
                    this.suspending = true
                    logger.info('CLIENT 013', 'suspending...')
                    clearTimeout(this.#requestTimer) // don't send request 
                    logger.verbose('CLIENT 014', 'DATA: REQUEST TIMEOUT CLEARED FOR NEXT RUN OF sendMessageAtRandom LOOP')
                    this.reportStatistics()
                    return
                }
                if (/<Reply /.test(data)) {
                    logger.info('CLIENT 015', 'reply received')
                    this.repliesReceived++
                    return
                }
                if (/CN_QUIESCE/.test(data)) {
                    logger.info('CLIENT 016', 'quiescing...')
                    clearTimeout(this.#requestTimer)
                    logger.verbose('CLIENT 017', 'DATA: REQUEST TIMEOUT CLEARED FOR NEXT RUN OF sendMessageAtRandom')
                    clearTimeout(this.#pollRequestTimer)
                    logger.verbose('CLIENT 018', 'DATA: POLL REQUEST TIMEOUT CLEARED')
                    // restart in a while
                    this.#requestTimer = setTimeout(() => {
                        this.socket.end(() => {
                            this.socket.destroy()
                            this.#start()
                        })
                    }, conversationExpirePhase)
                    return
                }
                if (/CorrelationIdResponse/.test(data)) {
                    this.correlationIdsReceived++
                    const correlationId = extractCorrelationId(data)
                    const pollRequest = `<POLL_REQUEST CorrelationId="${correlationId}"/>`
                    this.#pollRequestTimer = setTimeout(() => {
                        this.#sendPollRequest(pollRequest)
                    }), Math.floor((maxClientDelayForPollrequests - 100) * (Math.random() ** 4) + 100)
                    logger.verbose('CLIENT 019', `data: ${data}`)
                    return
                }
                logger.verbose('CLIENT 020', `data: ${data}`)
            })
            this.socket.on('error', err => {
                errors++
                logger.error('CILENT 021', err)
                if (errors <= errThreshold) {
                    logger.info('CLIENT 022', 'restarting: ', err)
                    this.#requestTimer = setTimeout(() => this.start(), restartLatency)
                    return
                }
                clearTimeout(this.#requestTimer)
                clearTimeout(this.#pollRequestTimer)
                logger.warning('CLIENT 023', 'too many errors - client stopped')
                this.reportStatistics()
            })
        } catch(err) {
            if (errors <= errThreshold) {
                logger.error('CLIENT 024', `restarting: ${err}`)
                this.#requestTimer = setTimeout(() => this.start(), restartLatency)
                return
            }
            clearTimeout(this.#requestTimer)
            clearTimeout(this.#pollRequestTimer)
            logger.error('CLIENT 025', err)
            logger.warning('CLIENT 026', 'too many errors - client stopped')
            this.reportStatistics()
        }
    }

    sendPollRequest(pollRequest) {
        if (!this.holdInBuffer) {
            let holdInBuffer = this.holdInBuffer
            this.holdInBuffer = !this.send(pollRequest)
            this.pollRequestsSent++
            logger.info('CLIENT 027', `sendPollRequest: POLL REQUEST #${this.pollRequestsSent} SENT`)
            if (holdInBuffer != this.holdInBuffer) {
                this.holdInBufferTogglings++
            }    
        }
    }        

    reportStatistics() {
        logger.info('CLIENT 028', 'STATISTICS:')
        logger.info(`\tsent ${this.datagramsSent} datagrams`)
        logger.info(`\tsent ${this.requestsSent} requests`)
        logger.info(`\treceived ${this.correlationIdsReceived} correlation ids`)
        logger.info(`\tsent ${this.pollRequestsSent} poll requests`)
        logger.info(`\treceived ${this.repliesReceived} replies`)
        logger.info(`\ttoggled caching of replies and poll replies ${this.holdInBufferTogglings} times`)
    }
}

const dxlClient = new DxlClient()
dxlClient.start()

export {
    DxlClient,
}