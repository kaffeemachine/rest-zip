import {
    Connection,
    setTuningParameters,
    provideConnection,
} from '../main/imqo-connection.mjs'
import {
    Warning,
} from '../main/imqo-errors.mjs'
import Message from '../main/imqo-message.mjs'
import demoCfg from './demo-cfg.mjs'
import {
    initializeCodec,
    decode,
} from '../dxl/dxl-codec.mjs'
import {
    logger,
    initializeDiagnostics,
} from '../dxl/dxl-diagnostics.mjs'

const {
    bridgeCfg,
    endianess,
    encoding,
    demoDuration,
} = demoCfg

const {
    queueManagerName,
    syncQueueName,
} = bridgeCfg

initializeDiagnostics(demoCfg.DEBUG, demoCfg.LOG_LEVEL)
initializeCodec(false, endianess, encoding) // first argument sets DEBUG
Connection.initialize(endianess, encoding)

logger.info('RECV 001', `application host receiver polling at queue ${syncQueueName}`)

let tm
let resolve
async function wait(ms) {
    return new Promise(done => {
        resolve = done
        tm = setTimeout(done, ms)
    })
}

let cn
let queue

setTuningParameters({
    getLoopPollTimeMs: 500,
    getLoopDelayTimeMs: 100,
})

let datagramsReceived = 0
let terminating = false

async function receive() {
    try {
        cn = await provideConnection(queueManagerName)
        queue = await cn.createQueueReader(syncQueueName, {
            readExclusive: true,
        })
        queue.getMessage({
            wait: true,
            waitInterval: 3 * 1000 * 60 // wait 3 minutes
        }, (err, result) => {
            if (err) {
                if (err.mqrc === 2033 || err.mqrc === 2018 || terminating) {
                    return
                }
                logger.error('RECV 002', err.message)
            } else if (result instanceof Error) {
                return logger.error('RECV 003', err)
            }
            if (result instanceof Warning) {
                return logger.warning('RECV 004', result)
            }
            datagramsReceived++
            if (result instanceof Message) {
                logger.info('RECV 005', `Host App Receiver Service: Datagram #${datagramsReceived} received`)
                // eslint-disable-next-line no-undef
                if (result.content instanceof Buffer) {
                    if (result.contentBuffer.slice(0, 4).toString(encoding) === 'FYC ') {
                        let msg = decode(-2, result.contentBuffer, encoding)
                        if (msg.body) {
                            logger.verbose('RECV 005', msg.body)
                        }
                    } else {
                        logger.verbose('RECV 006', result.contentString)
                    }
                }
            } else {
                logger.verbose('RECV 007', result.contentString)
            }
            if (result.contentString === 'x') {
                logger.info('RECV 008', 'terminating...')
                queue?.getDone(err => {
                    terminating = true
                    clearTimeout(tm)
                    resolve()
                    logger.info('RECV 009', 'done')
                    if (err) {
                        logger.error('RECV 010', err.message)
                    }
                })
            }
        })
    } catch(err) {
        logger.error('RECV 011', err)
        if (!terminating) {
            receive()
        }
    }
}

let clock = setInterval(() => {
    logger.info('RECV 012', new Date())
}, 60000)

receive().then(async () => {
    await wait(demoDuration + 1000)
    if (queue && queue.isOpen) {
        await queue.close()
    }
    if (cn && cn.isOpen) {
        await cn.close()
    }
    logger.info('RECV 013', `received ${datagramsReceived} datagrams`)
    logger.info('RECV 014', 'That\'s it!')
    clearInterval(clock)
})

