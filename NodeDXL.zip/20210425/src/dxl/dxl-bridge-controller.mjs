import {
    DxlConfigurationMessage,
    DxlControlMessage,
    DxlDataMessage,
    unpackError,
} from './dxl-protocol.mjs'
import {
    Severity,
} from './dxl-errors.mjs'
import DxlBridge from './dxl-bridge.mjs'
import { 
    fork,
} from 'child_process'
import split2 from 'split2'
import dxlCfg from '../dxl-cfg.mjs'
import assert from 'assert/strict'
import {
    logger,
    LogLevel,
    initializeDiagnostics,
} from './dxl-diagnostics.mjs'

const DEBUG = dxlCfg.DEBUG

// initializeDiagnostics(dxlCfg.DEBUG)

const messageSeparator = dxlCfg.commCtl.messageSeparator
const encoding = dxlCfg.byteConversionCharacteristics.encoding

if (DEBUG) {
    assert(messageSeparator !== undefined, 'BRIDGE CONTROLLER: messageSeparator not set')
    assert(encoding !== undefined, 'BRIDGE CONTROLLER: encoding not set')
}


//DEBUG BEGIN>>>
var messagesReceived = 0
var responsesSent = 0
var repliesSent = 0
var closing = 0
//DEBUG <<<END

class DxlBridgeController {
    socket
    bridge = null
    closed = false
    reader
    ready = false
    clientId
    qTm
    tmStatistics
    statsHandlers = []
    bridgeCtl
    msgBuf = []
    constructor(commCtl, bridgeCfg, bridgeCtl, socket, DEBUG = true, LOG_LEVEL = LogLevel.info) {
        socket.pause()
        initializeDiagnostics(DEBUG, LOG_LEVEL)
        this.socket = socket
        this.bridgeCtl = bridgeCtl
        if (bridgeCtl.statisticsTimerInterval > 0){
            this.tmStatistics = setInterval(() => this.queryStatistics(), bridgeCtl.statisticsTimerInterval)
        }
        this.clientId = bridgeCfg.clientId
        if (bridgeCtl.runInProcess || !bridgeCtl.forwardSocketToChild) { // socket remains
            this.quTm = setTimeout(() => {
                try {
                    // on timeout, send quiesce message to client
                    if (!this.socket.destroyed) {
                        this.socket.write(commCtl.quiesceMessage)
                    }
                } catch(err) {
                    this.close()
                }
            }, commCtl.connectionLifespan)
        }
        // current correlationId = correlationIdBase + now() (now is ms since fixed point in time)
        bridgeCfg.correlationIdBase = 
            (bridgeCfg.clientId * bridgeCtl.correlationIdBlockSize) % bridgeCtl.maxReliableInt

        if (bridgeCtl.runInProcess) {
            this.bridge = new DxlBridge(bridgeCfg)
            this.bridge.on('data', data => {
                this.socket.write(data + messageSeparator)
//DEBUG BEGIN>>>
responsesSent++
//DEBUG <<<END  
            })
            this.bridge.on('reply', data => {
                this.socket.write(data + messageSeparator)
//DEBUG BEGIN>>>
repliesSent++
//DEBUG <<<END  
            })
            this.bridge.on('ready', () => {
                this.reader = this.socket.pipe(new split2(messageSeparator), {
                    maxLength: commCtl.maxSizeSplitBuf,
                    skipOverflow: true,
                }).on('data', data => {
//DEBUG BEGIN>>>
messagesReceived++
//DEBUG <<<END
                    this.bridge.write(data)
                }).on('error', err => {
                    this.close()
                    logger.error(`BRIDGE CTL 001 (${this.clientId})`, err)
                }).on('end', () => {
                    logger.info(`BRIDGE CTL 002  (${this.clientId})`, 'socket recieved \'end\'')
                    this.close()
                })
                this.ready = true
            })
            this.bridge.on('error', err => { 
                logger.error(`BRIDGE CTL 003 (${this.clientId})`, err)
                if (err.severity === Severity.fatal) {
                    let statistics = this.bridge.close()
                    logger.printStatistics(`BRIDGE CTL 004 (${this.clientId})`, statistics)
                }
            })
            this.bridge.on('closed', statistics =>  {
                this.closeSocket()
                this.bridge = null
                logger.printStatistics(`BRIDGE CTL 005 (${this.clientId})`, statistics)
            })
            this.bridge.initialize()
        } else {
            logger.info(`BRIDGE CONTROLLER 006 (${this.clientId})`, 'forking child process...')
            this.child = fork('./src/dxl/dxl-sub-process.mjs', [
                DEBUG,
                LOG_LEVEL,
            ], {
                windowsHide: false,
            }).on('message', msg => {
                if (msg.control) {
                    switch(msg.what) {
                        case 'init':
                            logger.info(`BRIDGE CONTROLLER 007 (${this.clientId})`, 'received INIT control message from child')
                            logger.info(`BRIDGE CONTROLLER 007 (${this.clientId})`, 'sending COMM configuration message')
                            this.child.send(new DxlConfigurationMessage('comm', commCtl))
                            break
                        case 'prepared':
                            logger.info(`BRIDGE CONTROLLER 008 (${this.clientId})`, 'received PREPARED control message from child')
                            if (bridgeCtl.forwardSocketToChild) {
                                this.child.send('socket', this.socket)
                            } else {
                                this.child.send('nosocket')
                            }
                            break
                        case 'bridge':
                            logger.info(`BRIDGE CONTROLLER 009 (${this.clientId})`, 'received BRIDGE control message from child')
                            logger.info(`BRIDGE CONTROLLER 009 (${this.clientId})`, 'sending BRIDGE configuration message')
                            this.child.send(new DxlConfigurationMessage('bridge', bridgeCfg))
                            break
                        case 'ready':
                            logger.info(`BRIDGE CONTROLLER 010 (${this.clientId})`, 'received READY control message from child')
                            if(!bridgeCtl.forwardSocketToChild) {
                                this.reader = this.socket.pipe(new split2(messageSeparator)).
                                on('data', data => {
                                    this.writeToChild(data)
                                }).
                                on('error', err => {
                                    logger.info (`BRIDGE CONTROLLER 011 (${this.clientId})`, 'received ERROR message socket')
                                    logger.error(`BRIDGE CONTROLLER 011 (${this.clientId})`, err)
                                    this.close()
                                })
                            }
                            this.working = true
                            break
                        case 'statistics':
                            logger.printStatistics(`BRIDGE CONTROLLER 012 (${this.clientId})`, msg.ctlData)
                            break
                        case 'closed':
                            logger.info(`BRIDGE CONTROLLER 013 (${this.clientId})`, 'received CLOSE control message from child')
                            logger.verbose(`BRIDGE CONTROLLER 013 (${this.clientId})`, msg.ctlData)
                            this.working = false
                            break
                    }
                } else if (msg.error) {
                    logger.info(`BRIDGE CONTROLLER 014 (${this.clientId})`, 'received error message from child')
                    let err = unpackError(msg)
                    logger.error(`BRIDGE CONTROLLER 014 (${this.clientId})`, err)
                    if (err.severity === Severity.fatal) {
                        this.close()
                    }
                } else if (msg.data) {
                    if (!bridgeCtl.forwardSocketToChild) {
                        logger.info(`BRIDGE CONTROLLER 015 (${this.clientId})`, 'received data message from child')
                        logger.verbose(msg.payload)
                        this.socket.write(msg.payload + messageSeparator)
                    } else {
                        // protocol error!
                        throw new Error('logic failure: received data message from child although socket has been passed to it')
                    }
                } else if (msg.diagnostics) {
                    logger.info(`BRIDGE CONTROLLER 016 (${this.clientId})`, `received diagnostics ${msg.what.toUpperCase()} message from socket`)
                    while (this.statsHandlers.length > 0) {
                        const hdlr = this.statsHandlers.splice(0, 1)[0]
                        hdlr(msg.data)
                    }
                } else if (msg.debug) {
                    logger.debug(`BRIDGE CONTROLLER 017 (${this.clientId})`, `${msg.what}, ${msg.payload}`)
                } else if (msg.info) {
                    logger.info(`BRIDGE CONTROLLER 018 (${this.clientId})`, `${msg.what}, ${msg.payload}`)
                } else {
                    logger.info(`BRIDGE CONTROLLER 019 (${this.clientId})`, `received unrecognized message from child:\n${msg}`)
                    for (const prop in msg) {
                        logger.info(`\t${prop}: ${msg[prop]}`)
                    }
                }
            })
        }
    }
    queryStatistics(cb) {
        if (this.bridge) {
            cb(this.bridge.statistics)
        } else {
            this.statsHandlers.push(cb)
            this.child.send(new DxlControlMessage('statistics'))
        }
    }
    writeToChild(data) {
        try {
            if (this.working) {
                logger.info(`BRIDGE CONTROLLER 020 (${this.clientId})`, 'sending data message to child')
                while (this.msgBuf.length > 0) {
                    this.child.send(this.msgBuf.splice(0, 1)[0])
                }
                this.child.send(new DxlDataMessage(data))
            } else {
                logger.info(`BRIDGE CONTROLLER 021 (${this.clientId})`, 'buffering data message')
                this.msgBuf.push(new DxlDataMessage(data))
            }
        } catch(err) {
            if (err.message === 'Channel closed') {
                this.working = false
            } else {
                logger.error(`BRIDGE CONTROLLER 022 (${this.clientId})`, err)
            }
        }
        
    }
    close() {
//DEBUG BEGIN>>>
closing++
//DEBUG <<<END
        if (this.closed) {
            return
        }
        if (this.bridge) {
            this.bridge.close()
        } else {
            this.child?.send(new DxlControlMessage('close'))
        }
        clearTimeout(this.tmStatistics)
        this.closed = true
    }
    closeSocket() {
        clearTimeout(this.quTm)
        this.socket?.unpipe(this.reader)
        this.socket?.end('', () => {
            this.socket?.destroy()
        })
        this.socket = null
        if (this.bridgeCtl.runInProcess || !this.bridgeCtl.forwardSocketToChild) {
            logger.info(`BRIDGE CONTROLLER 023 (${this.clientId})`, 'STATISTICS:')
            logger.info(`\treceived ${messagesReceived} messages`)
            logger.info(`\tsent ${responsesSent} responses`)
            logger.info(`\tsent ${repliesSent} replies`)
        }
        logger.info(`\ttried to close ${closing} times`)
    }
}

export default DxlBridgeController