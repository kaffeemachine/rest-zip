class Severity {
    static warn  = 1    // may be ignored
    static logic = 4
    static error = 5    // needs handling
    static fatal = 10   // needs aborting
}

Object.freeze(Severity)

class DxlProtocolError extends Error {
    code
    severity
    constructor(message, code, severity) {
        super(message)
        this.code = code
        this.severity = severity
    }
}

class DxlError extends Error {
    code
    severity
    constructor(message, code, severity) {
        super(message)
        this.code = code
        this.severity = severity
    }
}

export {
    Severity,
    DxlProtocolError,
    DxlError,
}