
/**
 * A task is a function which return true on success and false otherwise.
 * This class implements buffered scheduling of tasks such that tasks subjet to 
 * different processing have equal chances to be processed. For each processing
 * variant, there is a fifo queue (buffer) on its own. Equal chance is achieved 
 * by a timer which starts a processing cycle every few millis (configurable).
 * From each queue, one task (if available) will be processed per cycle.
 * This approach limits the number of tasks which can be processed per second
 * and queue. However, this is a desired effect.
 * Note that tasks should be short-running synchronous
 * functions to make this algorithm efficient. Long-running synchronous
 * tasks are inappropriate.
 * 
 * If a task returns true, it is removed from the buffer. This allows for a kind
 * of serialization for tasks which run asynchronously using callbacks. On start,
 * such a task would check the busy flag on its queue (synchronization point). If
 * true, the previous task is still active, so the current one returns false and hence
 * will not be removed from its queue. The task will be started again until the busy
 * flag is false which means that there is no active task from the queue.
 * n this case, the current task will set the busy flag to true itself thereby
 * assuring that not other task in its queue will become activated. When the task 
 * returns it does this with the return value true. This allows it to be removed
 * from the queue. When the task's activity ends (which usually is at a later point
 * in time if it is an asynchronous one, e.g. when its callback is called), it sets
 * the busy flag to false again. Then, on the following cycle, the next task can be
 * executed.
 * 
 */

const balanceIntervalDefault = 2

class BalanceWheel {
    idleTime
    taskQueues = new Map()
    timer = null
    idle = true
    #stats = {
        taskCyclesInitiated: 0,
        taskCyclesRun: 0,
        tasksPerformed: 0,
        foundBusy: 0,
        queues: {},
    }
    constructor(balanceInterval) {
        this.idleTime = balanceInterval || balanceIntervalDefault
    }
    runTaskCycle() {
        this.#stats.taskCyclesInitiated++
        if (!this.idle) {
            this.#stats.foundBusy++
            return
        }
        this.idle = false
        for(const queueName of this.taskQueues.keys()) {
            try {
                const queue = this.taskQueues.get(queueName)
                if (queue.length) {
                    if (queue[0]()) { // if sucessfully executed
                        queue.splice(0, 1)
                        this.#stats.tasksPerformed++
                        this.#stats.queues[queueName].tasksPerformed++
                    }
                }
            } catch(err) {
                console.log('BALANCE_WHEEL 001', err)
            }
        }
        this.idle = true       
        this.#stats.taskCyclesRun++
    }

    hasQueue(name) {
        return this.taskQueues.has(name)
    }

    createTaskQueue(name) {
        if (this.taskQueues.has(name)) {
            return
        }
        const queue = []
        queue.busy = false
        this.taskQueues.set(name, queue)
        this.#stats.queues[name] = {
            tasksAdded: 0,
            tasksPerformed: 0,
        }
    }

    createTaskQueues(names) {
        names.forEach(name => this.createTaskQueue(name));
    }

    removeTaskQueue(name) {
        if (this.taskQueues.has(name)) {
            this.taskQueues.delete(name)
            this.#stats.queues[name] = undefined
        }
    }

    addTask(queueName, fun) {
        if (typeof fun !== 'function') {
            throw new Error('tasks must be of type \'function\'')
        }
        if (!this.taskQueues.has(queueName)) {
            this.createTaskQueue(queueName)
        }
        this.taskQueues.get(queueName).push(fun)
        this.#stats.queues[queueName].tasksAdded++
    }

    removeTask(queueName, fun) {
        const queue = this.taskQueues.get(queueName)
        if (queue === undefined) {
            throw new Error(`no such task queue ${queueName}`)
        }
        const pos = queue.indexOf(fun)
        if (pos >= 0) {
            queue.splice(pos, 1)
        }
    }


    start(immediate, forgiving) {
        if (this.timer) {
            if (forgiving) {
                return
            }
            throw new Error('scheduler already running')
        }
        this.timer = setInterval(() => this.runTaskCycle(), this.idleTime)
        if (immediate) {
            this.runTaskCycle()
        }
    }

    get stats() {
        const statistics = {
            ...this.stats
        }
        for (const prop in statistics) {
            statistics[prop].openTasks = statistics[prop].tasksAdded - statistics[prop].tasksPerformed
        }
        return statistics
    }

    stop() {
        if (!this.timer) {
            return
        }
        clearInterval(this.timer)
        this.timer = undefined
    }

    get statistics() {
        return this.#stats
    }
}

export default BalanceWheel
