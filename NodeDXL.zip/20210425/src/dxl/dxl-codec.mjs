import { strict as assert } from 'assert'
import {
    logger,
} from './dxl-diagnostics.mjs'
import Message from '../main/imqo-message.mjs'

let DEBUG
let endianess
let encoding

function initializeCodec(...cfg) {
    [ DEBUG, endianess, encoding ] = cfg
    assert(endianess !== undefined, 'DECODE: endianess not set')
    assert(encoding !== undefined, 'DECODE: encoding not set')
}

let messagesToEncode = 0
let messagesToDecode = 0

const constants = {
    magic: [
        0x46, 0x59, 0x43, 0x20 // "FYC "
    ],
    versionMajor: 0x01,
    versionMinor: 0x00,
    flags: {
        bigEndian: 0x00,
        littleEndian: 0x01,
    },
    messageType: { // UBS
        none: 0x00, // not used
        synchronousRequest: 0x01,
        asynchronousRequest: 0x02,
        pollRequest: 0x03,
        replyFromTarget: 0x04,
        correlationIdReply: 0x05,
        systemExceptionReply: 0x06,
        quiesce: 0x07,
        heartBeat: 0x08, // not used
    },
    timeout: {
        async: 60000, // 1 minute
        other: 0,
    },
    status: {
        ok: 0x00,
        proceesingTimeout: 1,
    },
}

const offsets = {
    magic: 0,
    versionMajor: 4,
    versionMinor: 5,
    flags: 6,
    messageType: 7,
    messageLength: 8,
    requestId: 16, // correlation Id
    timeout: 24, // requests
    status: 24, // replies
    noMessageTypeSpecificHeader: undefined, // quiesce
    messageBody: {
        length: 32,
        text: 40,
    },
}

const UbsMessageType = {
    none: 0x00,
    synchronousRequest: 0x01,
    asynchronousRequest: 0x02,
    pollRequest: 0x03,
    replyFromTarget: 0x04,
    correlationIdReply: 0x05,
    systemExceptionReply: 0x06,
    quiesce: 0x07,
}

function encode(id, msg) {
    messagesToEncode++
    if (DEBUG) {
        assert(msg.body instanceof Message ||
            typeof msg.body === 'string', `message #${messagesToEncode}`)
    }
    let bufBody
    // eslint-disable-next-line no-undef
    if (msg.body instanceof Buffer) {
        bufBody = msg.body
    } else {
        // eslint-disable-next-line no-undef
        bufBody = Buffer.from(msg.body, encoding)
    }
    let msgBodyLength = bufBody.length
    let arrayLen = offsets.messageBody.text + msgBodyLength
    // eslint-disable-next-line no-undef
    let bytes = Buffer.alloc(arrayLen, 0)
    constants.magic.forEach((val, pos) => bytes.writeUInt8(val, offsets.magic + pos))
    bytes.writeUInt8(constants.versionMajor, offsets.versionMajor)
    bytes.writeUInt8(constants.versionMinor, offsets.versionMinor)
    bytes.writeUInt8(endianess, offsets.flags)
    bytes.writeUInt8(UbsMessageType[msg.ubsMsgType], offsets.messageType)
    assert(endianess !== undefined, 'DECODE: endianess not set')
    const writeBigUInt64 = [
        (value, position) => bytes.writeBigUInt64BE(BigInt(value), position),
        (value, position) => bytes.writeBigUInt64LE(BigInt(value), position),
    ][endianess]
    writeBigUInt64(arrayLen, offsets.messageLength)
    writeBigUInt64(msg.requestId || 0, offsets.requestId)
    writeBigUInt64(msg.timeout || constants.timeout.other, offsets.timeout)
    writeBigUInt64(msgBodyLength, offsets.messageBody.length)
    bufBody.copy(bytes, offsets.messageBody.text, 0, bufBody.length)
    try {
        printEncodingInfo(id, bytes)
    } catch(err) {
        logger.error('CODEC.encode', err)
    }
    return bytes
}

function decode(id, data) {
    messagesToDecode++
    if (DEBUG) {
        console.log(data)
        // eslint-disable-next-line no-undef
        assert(data instanceof Buffer || typeof data === 'string', `message #${messagesToDecode}: ${data}`)
    }
    const originalData = data
    // eslint-disable-next-line no-undef
    if (!(data instanceof Buffer)) {
        // eslint-disable-next-line no-undef
        data = Buffer.from(data, encoding)
    }
    const magic = (typeof originalData === 'string')?
        originalData.substr(0, 4) :
        data.slice(offsets.magic, offsets.versionMajor).toString(encoding)
    let result = {}
    if (magic !== 'FYC ') { // not a UBS message
        result.body = (typeof originalData === 'string')?
            originalData :
            data.toString(encoding)
        result.flags = endianess
        result.msgBodyLength = result.body.length
        result.msgLength = data.length
        return result
    }
    // the sender of the message might have a different endianess
    let flags = data.readUInt8(offsets.flags)
    result.flags = flags
    result.magic = magic
    let versionMajor = data.readUInt8(offsets.versionMajor)
    let versionMinor = data.readUInt8(offsets.versionMinor)
    result.version = `${versionMajor}.${versionMinor}`
    result.ubsMsgType = Object.getOwnPropertyNames(UbsMessageType)[data.readUInt8(offsets.messageType)]
    const readBigUInt64 = [ // practically, an int will do
        position => parseInt(data.readBigUInt64BE(position)),
        position => parseInt(data.readBigUInt64LE(position)),
    ][flags]
    result.msgLength = readBigUInt64(offsets.messageLength)
    result.requestId = readBigUInt64(offsets.requestId).toString()
    result.timeout = readBigUInt64(offsets.timeout)
    result.msgBodyLength = readBigUInt64(offsets.messageBody.length)
    // since we don't know the encoding of the sender we take our own
    result.body = data.slice(offsets.messageBody.text).toString(encoding)
    printDecodingInfo(id, result)
    if (DEBUG) {    
        assert.equal(result.msgLength - result.msgBodyLength, offsets.messageBody.text)
    }
    return result
}

function printDiagnostics(...args) {
    logger.debug(...args)
}

function printEncodingInfo(id, bytes) {
    logger.verbose(`client #${id}:`)
    // eslint-disable-next-line no-undef
    assert(bytes instanceof Buffer)
    let endianess = bytes.readUInt8(offsets.flags)
    const readBigUInt64 = [
        position => bytes.readBigUInt64BE(position),
        position => bytes.readBigUInt64LE(position),
    ][endianess]
    logger.verbose(`[${('00' + ('' + offsets.magic)).substr(-2)}] magic bytes:       ${bytes.slice(offsets.magic, offsets.versionMajor).toString('latin1')}`)
    logger.verbose(`[${('00' + ('' + offsets.versionMajor)).substr(-2)}] major version:     ${bytes.readUInt8(offsets.versionMajor)}`)
    logger.verbose(`[${('00' + ('' + offsets.versionMinor)).substr(-2)}] minor version:     ${bytes.readUInt8(offsets.versionMinor)}`)
    logger.verbose(`[${('00' + ('' + offsets.flags)).substr(-2)}] flags:             ${endianess}`)
    let ubsMsgType = bytes.readUInt8(offsets.messageType)
    let msgTypeName = Object.getOwnPropertyNames(UbsMessageType)[ubsMsgType]
    logger.verbose(`[${('00' + ('' + offsets.messageType)).substr(-2)}] UBS messageType:   ${ubsMsgType} (${msgTypeName})`)
    logger.verbose(`[--] buf length        `, bytes.length)
    logger.verbose(`[${('00' + ('' + offsets.messageLength)).substr(-2)}] msg length:       `, parseInt(readBigUInt64(offsets.messageLength)))
    logger.verbose(`[${offsets.requestId}] request id:       `, parseInt(readBigUInt64(offsets.requestId)))
    logger.verbose(`[${offsets.timeout}] timeout:          `, parseInt(readBigUInt64(offsets.timeout)))
    logger.verbose(`[${offsets.messageBody.length}] msgbody len:      `, parseInt(readBigUInt64(offsets.messageBody.length)))
    let text = bytes.slice(offsets.messageBody.text).toString(encoding)
    logger.verbose(`[${offsets.messageBody.text}] msgbody:           ${text}`.substr(0, 200))
    for (let i = 0; i < 49; i += 8) {
        logger.verbose(`[${('00' + i).substr(-2)}]`, bytes.slice(i, i + 8))
    }
}

function printDecodingInfo(id, msg) {
    logger.verbose(`client #${id}:`)
    for (let prop in msg) {
        if (typeof msg[prop] === 'string') {
            logger.verbose(`${(prop + ':                  ').substr(0, 19)} ${msg[prop]}`.substr(0, 200))
        // eslint-disable-next-line no-undef
        } else if (msg[prop] instanceof Buffer) {
            let value = msg[prop].toString(encoding)
            logger.verbose(`${(prop + ':                  ').substr(0, 19)}`,  value)
            } else {
                logger.verbose(`${(prop + ':                  ').substr(0, 19)}`,  msg[prop])
        }
    }
}

function extractCorrelationId(strXmlData) {
    return /CorrelationId="([0-9]+)"/.exec(strXmlData)?.[1]
}

export {
    constants,
    offsets,
    UbsMessageType,
    initializeCodec,
    encode,
    decode,
    printDiagnostics,
    printEncodingInfo,
    printDecodingInfo,
    extractCorrelationId,
}
