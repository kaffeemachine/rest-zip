
/**
 * Parent should start with socket paused
 * Several cases: 
 * 1) use as module: (INTEGRATED)
 * DxlBridge created by user
 * Constructor parameters:
 * Config
 * Instance will work as EventEmitter, controlled by methods
 *   
 * 2) use as Process (SERVER)
 * DxlBridge instance must be created autonomously
 * Communication via 
 * 2a) ipc channel only (control and data)
 * 2b) ipc channel (control) and socket (data)
 * 
 * 2a) two operating modes:
 * 2a1) control mode: setup and tear down 
 * 2a2) data processing mode
 * channel might receive:
 * - string messages
 * - object
 * 
 * 2b) ipc channel for control exclusively
 *     socket for data processing exclusively
 * 
 * Protocol is needed
 * phase SETUP:
 *         send 'init' message
 *         receive: 'socket' + handle => 2b)
 *                   or 'nosocket'    => 2a)
 *         send 'config' message
 *         receive: configuration object
 *         [initalize: connect to queue manager, setup queue access]
 *         send 'ready' message when done
 *         resume socket => 2b)
 *         exerce socket control => 2b)
 * phase SHUTDOWN:
 *         receive 'shutdown' message
 *         [cleanup: close queues, disconnect from queue manager]
 *         disconnect when done
 * phase ABNORMAL_CONDITION:
 * (should be followed by SHUTDOWN)
 *         send error message
 *         receive: 'info' message
 *         send error info object
 * send and receive relate to communication via channel
 * don't forget parent-side failure detection (child crashed)!
 * 
 */

import process from 'process'
import DxlBridge from './dxl-bridge.mjs'
import {
    DxlControlMessage,
    DxlDataMessage,
    DxlDiagnosticsMessage,
    DxlErrorMessage,
} from './dxl-protocol.mjs'
import {
    Severity,
    DxlProtocolError,
} from './dxl-errors.mjs'
import split2 from 'split2'
import {
    logger,
    initializeDiagnostics,
} from './dxl-diagnostics.mjs'

process.on('uncaughtException', err => {
   logger.error('CHILD 001', `uncaughtException: ${err}`)
    if (err.mqrc === 2018) {
        process.exit(0)
    } else {
        logger.error('CHILD 002', err)
        process.exitCode = err.mqrc || err.errCode || 3
    }
})

process.on('unhandledRejection', reason => {
    logger.error('CHILD 003', `unhandledRejection: ${reason}`)
    process.exitCode = 2
})

const DEBUG = process.argv[2]
const LOG_LEVEL = process.argv[3]
initializeDiagnostics(DEBUG, LOG_LEVEL)

class DxlSubProcess {
    bridge
    state = 'waked'
    working = false
    socket
    commCtl
    constructor() { }

    async installBridge(socket) {
        this.socket = socket
        if (this.socket) {
            this.quTm = setTimeout(() => {
                try {
                    // on timeout, send quiesce message to client
                    this.socket.write(this.commCtl.quiesceMessage)
                } catch (err) {
                    // logErr(err)
                    this.close()
                }
            }, this.commCtl.connectionLifespan)
        }
        // create and wire bridge
        this.bridge = new DxlBridge(this.bridgeConfig, DEBUG, LOG_LEVEL)
        logger.info('CHILD 004', 'bridge created')
        await this.bridge.on('ready', () => {
            this.state = 'ready'
            if (this.socket) {
                this.reader = this.socket.pipe(new split2(this.commCtl.messageSeparator), {
                    maxLength: this.commCtl.maxSizeSplitBuf,
                    skipOverflow: true,
                })  
                this.reader.on('data', data => this.bridge.write(data)).
                on('end', async data => {
                    logger.info('CHILD 005', 'received \'end\' on socket')
                    this.bridge.write(data)
                    await this.close()
                }).
                on('close', async () => {
                    logger.info('CHILD 006', 'received \'close\' on socket')
                    await this.close()
                }).
                on('error', async err => {
                    logger.error('CHILD 007:', err)
                    err.code = 'DXL0099'
                    process.send(new DxlErrorMessage(err))
                    await this.close()
                })
                this.socket.on('error', async err => {
                    logger.error('CHILD 008:', err)
                    err.code = 'DXL0099'
                    process.send(new DxlErrorMessage(err))
                    await this.close()
                })
                this.ready = true
                this.working = true
            } else {
                this.working = true
                process.send(new DxlControlMessage('ready'))
            }
        }).on('data', data => {
            if (this.socket) {
                this.socket.write(data + this.commCtl.messageSeparator)
            } else {
                if (this.working) {
                    logger.info('CHILD 009', 'sending data message')
                    process.send(new DxlDataMessage(data))
                }
            }
        }).on('reply', reply => {
            if (this.socket) {
                this.socket.write(reply + this.commCtl.messageSeparator)
            } else {
                if (this.working) {
                    logger.info('CHILD 010', 'sending reply message')
                    process.send(new DxlDataMessage(reply))
                }
            }
        }).on('statistics', stats => {
            process.send(new DxlDiagnosticsMessage(stats))
        }).on('error', err => {
            logger.error('CHILD 011', err)
            process.send(new DxlErrorMessage(err))
        }).on('closed', stats => {
            this.closeSocket()
            this.bridge = undefined
            process.send(new DxlControlMessage('closed', stats))
            process.channel.unref()
            process.disconnect()
        }).on('DEBUG', data => logger.debug('CHILD 012', data)).initialize()
    }
    async close() {
        this.working = false
        await this.bridge.close()
        this.closeSocket()
    }
    closeSocket() {
        clearTimeout(this.quTm)
        this.socket?.unpipe(this.reader)
        this.socket?.end('', () => {
            this.socket?.destroy()
            this.socket = null
        })
    }
    run() {

        logger.info('CHILD 013', 'bridge created')
        process.on('disconnect', () => {
            if (!this.socket) {
                this.bridge?.close()
            }
        })
        process.on('message', (msg, socket) => {
            try {
                switch (msg) {
                    case 'nosocket':
                    case 'socket':
                        if (this.state !== 'readyForAssembly') {
                            process.send(new DxlErrorMessage(new DxlProtocolError(`socket received while in state ${this.state}`, 'DXL0095', Severity.fatal)))
                            return
                        }
                        this.installBridge(socket)
                        break
                    default:
                        if (msg.configuration) {
                            if (msg.what === 'comm') {
                                logger.info('CHILD 014', 'received configuration message COMM')
                                if (this.state !== 'readyForCommCtl') {
                                    process.send(new DxlErrorMessage(new DxlProtocolError(`COMM ctl message received while in state ${this.state}`, 'DXL0093', Severity.fatal)))
                                    return
                                }
                                this.commCtl = msg.cfgData
                                logger.info('CHILD 015', 'sending BRIDGE control message')
                                process.send(new DxlControlMessage('bridge'))
                                this.state = 'readyForBridgeConfiguration'
                            } else if (msg.what === 'bridge') {
                                logger.info('CHILD 016', 'received configuration message BRIDGE')
                                if (this.state !== 'readyForBridgeConfiguration') {
                                    process.send(new DxlErrorMessage(new DxlProtocolError(`BRIDGE configuration message received while in state ${this.state}`, 'DXL0094', Severity.fatal)))
                                    return
                                }
                                this.bridgeConfig = msg.cfgData
                                logger.info('CHILD 017', 'sending control message PREPARED')
                                process.send(new DxlControlMessage('prepared'))
                                this.state = 'readyForAssembly'
                            }
                        } else if (msg.control) {
                            if (msg.what === 'close') {
                                logger.info('CHILD 018', 'received CLOSE control message')
                                 this.bridge?.close()
                            } else if (msg.what === 'statistics') {
                                logger.info('CHILD 019', 'sending STATS diagnostics message')
                                process.send(new DxlControlMessage('statistics', this.bridge.statistics))
                            }
                        } else if (msg.data) {
                            logger.info('CHILD 020', 'received data message')
                            if (this.state !== 'ready') {
                                process.send(new DxlErrorMessage(new DxlProtocolError(`CHILD PROCESS: data message received while in state ${this.state}`, 'DXL0003', Severity.fatal)))
                                return
                            }
                            if (this.socket) {
                                process.send(new DxlErrorMessage(new DxlProtocolError(`CHILD PROCESS: data message received when socket should be used`, 'DXL0007', Severity.fatal)))
                                return
                            }
                            logger.info('CHILD 021', 'writing data to bridge')
                            this.bridge.write(msg.payload)
                        } else {
                            logger.info.log('CHILD 022', `received unrecognized message from child:\n${msg}`)
                            for (const prop in msg) {
                                logger.info(`\t${prop}: ${msg[prop].substr(0, 200)}`)
                            }
                        }
                }
            } catch (err) {
                logger.error('CHILD 023', err)
                process.send(new DxlErrorMessage(err))
            }
        })
        setTimeout(() => {
            logger.info('CHILD 024', 'sending INIT control message')
            process.send(new DxlControlMessage('init'))
            this.state = 'readyForCommCtl'
        }, 0)
    }
}

const sub = new DxlSubProcess()
sub.run()
