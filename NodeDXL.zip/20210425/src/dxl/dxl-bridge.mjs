import EventEmitter from 'events'
import {
    provideConnection,
    Connection,
} from '../main/imqo-connection.mjs'
import {
    Severity,
    DxlError,
    DxlProtocolError,   
} from './dxl-errors.mjs'
import BalanceWheel from './dxl-balance-wheel.mjs'
import {
    constants,
    extractCorrelationId,
    initializeCodec,
    encode,
    decode,
} from './dxl-codec.mjs'
import { 
    logger,
} from './dxl-diagnostics.mjs'
import {
    dateString,
} from './dxl-helpers.mjs'
import {
    MqError,
} from '../main/imqo-errors.mjs'

//DEBUG BEGIN>>>
let messagesReceived = 0
let unrecognizedMessages = 0
let requestsReceived = 0
let pollRequestsReceived = 0
let datagramsReceived = 0
let responsesSent = 0
let repliesSent = 0
//DEBUG <<<END

class DxlBridge extends EventEmitter {
    qm
    cfg
    clientId
    queues = {}
    bw
    correlationIdBase
    openPollRequests = new Set()
    waitingReplies = new Map()
    stats = {
        datagramsReceived: 0,
        datagramsPosted: 0,
        requestsReceived: 0,
        requestsPosted: 0,
        correlationIdResponsesSent : 0,
        pollRequestsReceived: 0,
        repliesRetrieved:0,
        repliesSent: 0,
        errorsOnPut: 0,
        errorsOnPost: 0,
    }
    #taskQueues = ['reply', 'request', 'pollRequest', 'datagram']
    state = 'created'
    constructor(cfg) {
        super()
        if (!cfg) {
            throw new DxlError('missing configuration data', 'DXL0001', Severity.error)
        }
        this.cfg = cfg
        this.clientId = cfg.clientId
        this.stats.id = cfg.clientId
        this.correlationIdBase = cfg.correlationIdBase
        // initializeDiagnostics(cfg.DEBUG)
        initializeCodec(cfg.DEBUG, cfg.endianess, cfg.encoding)
        Connection.initialize(cfg.endianess, cfg.encoding)  // initialize imq wrapper library
// DEBUG BEGIN>>>
        messagesReceived = 0
        unrecognizedMessages = 0
        requestsReceived = 0
        pollRequestsReceived = 0
        datagramsReceived = 0
        responsesSent = 0
        repliesSent = 0

        this.on('data', data => {
            this.emit('DEBUG', data)
        })
// DEBUG <<<END
    }
    /**
     * public
     * 
     */
    async initialize() {
        try {
            await this.prepareQueues()
            this.doWiring()
            this.bw.start()
            const state = 'ready'
            this.state = state
            this.emit(state)
        } catch(err) {
            const code = 'DXL0005'
            const verb = 'BRIDGE_INIT'
            if (err.name === 'MQError') {
                    // eslint-disable-next-line no-ex-assign
                    err = new MqError(err.message, err, this.constructor.name, code, undefined, verb)
                } else {
                    err.code ||= code
                    err.verb ||= verb
                }
                err.severity = Severity.fatal
                this.raiseError(err)
        }
    }
    /**
     * private
     * 
     */
    async prepareQueues() {
        const {
            queueManagerName,
            syncQueueName,
            asyncRequestQueueName,
            asyncReplyQueueModel,
            dynamicQueueNamePrefix,
        } = this.cfg
        await this.connect(queueManagerName)
        this.queues.syncQueueWriter = await this.createWriter(syncQueueName)
        this.queues.asyncWriter = await this.createWriter(asyncRequestQueueName)
        this.queues.dynamicReplyQueueReader = await this.createDynamicReader(asyncReplyQueueModel, dynamicQueueNamePrefix)
//DEBUG BEGIN>>>
        this.emit('DEBUG', `syncQueueWriter ${syncQueueName} ${this.queues.syncQueueWriter? '' : 'not ' }opened\n` +
            `asyncWriter ${asyncRequestQueueName} ${this.queues.asyncWriter? '' : 'not ' }opened\n` +
            `dynamicReplyQueueReader${this.queues.dynamicReplyQueueReader? ' ' + this.queues.dynamicReplyQueueReader.name : ''}`+
            ` ${this.queues.dynamicReplyQueueReader? '' : 'not ' }opened\n`)
//DEBUG <<<END
        this.emit('queues_installed')
    }
    /**
     * private
     * 
     * @param queueManageName
     * @returns 
     */
    async connect(queueManageName) {
        this.qm = await provideConnection(queueManageName)
    }
    /**
     * private
     * 
     * @param queueName 
     * @returns 
     */
    async createWriter(queueName) {
        return await this.qm.createQueueWriter(queueName)
    }
    /**
     * private
     * 
     * @param modelQueueName 
     * @param queueNamePrefix 
     * @returns new dynamic reply queue
     */
    async createDynamicReader(modelQueueName, queueNamePrefix) {
        return await this.qm.createDynamicReplyQueue(queueNamePrefix, {
            modelQueueName, 
        })
    }
    /**
     * private
     * 
     */
    doWiring() {
        this.bw = new BalanceWheel(this.cfg.balanceWheelInterval)
        this.stats.bwStatistics = this.bw.stats
        this.bw.createTaskQueues(this.#taskQueues)
        this.startReadingReplyQueue()
    }
    /**
     * private
     * 
     */
    startReadingReplyQueue() {
        const TASK_QUEUE = 'reply' // reply task queue
        if (!this.bw.taskQueues.has(TASK_QUEUE)) {
            this.bw.createTaskQueue(TASK_QUEUE)
        }
        const options = {
            readExclusive: true,
            wait: true,
            waitInterval: this.cfg.waitForReplyDuration // wait up to n millis between while getting replies
        }
// logDebug(`Queue ${this.queues.dynamicReplyQueueReader.name} getMessage(): being started (${Date.now()})`)
        this.queues.dynamicReplyQueueReader.getMessage(options, (err, result) => {
// logDebug(`Queue ${this.queues.dynamicReplyQueueReader.name} getMessage(): got something (${Date.now()})`)
            if (err) {
// logDebug(`Queue ${this.queues.dynamicReplyQueueReader.name} getMessage(): got an error (${Date.now()})`)
                const code = 'DXL0006'
                const verb = 'GET'
                if (err.name === 'MQError') {
                    let severity = [  2031, ].indexOf(err.mqrc) >= 0 ? Severity.fatal : Severity.error
                    // eslint-disable-next-line no-ex-assign
                    logger.error(`BRIDGE 200 (#${this.clientId})`, `received MQError - severity: ${err.severity}`)
                    err = new MqError(err.message, err,  this.constructor.name, code, options, verb, severity)
                } else {
                    err.code ||= code
                    err.verb ||= verb
                }
                err.Severity |= Severity.error
                return(this.raiseError(err))
            }
// logDebug(`Queue ${this.queues.dynamicReplyQueueReader.name} getMessage(): got a message (${Date.now()})`)
            if (result === null || !result.content) {
// logDebug(`Queue ${this.queues.dynamicReplyQueueReader.name} getMessage(): got message without content (${Date.now()})`)
                return
            }
            let correlationId = parseInt(result.correlationId)
            if (!correlationId) {
// logDebug(`Queue ${this.queues.dynamicReplyQueueReader.name} getMessage(): got message without correlation id (${Date.now()})`)
                return
            }
            this.emit('DEBUG', `BRIDGE: reply received for correlation id ${correlationId} (${Date.now()})`)
            this.stats.repliesRetrieved++
            let msg = decode('', result.data)
            const self = this
// logDebug(`adding task to reply task queue ${Date.now()} `)
            this.bw.addTask(TASK_QUEUE, () => {
                try {
// logDebug(`executing task from reply task queue (${Date.now()})`)
                    if (self.openPollRequests.has(correlationId)) {
// logDebug(`reply task found open poll request (${Date.now()})`)
                        self.openPollRequests.delete(correlationId)
                        self.sendReply(msg.body)
// DEBUG BEGIN>>>
                        self.emit('DEBUG', `BRIDGE: reply for correlation id ${correlationId} sent (${Date.now()})`)
// DEBUG <<<END
                        self.stats.repliesSent++
                    } else {
// logDebug(`reply task adds reply to waiting replies )${Date.now()})`)
                        self.waitingReplies.set(correlationId, msg.body)
                        self.emit('DEBUG', `BRIDGE: reply for correlation id ${correlationId} queued (${Date.now()})`)
                    }
                } catch(err) {
                    err.code = 'DXL0061'
                    err.verb = 'SEND'
                    err.Severity = Severity.error
                    self.raiseError(err)
                }
                return true
            })
        }, this.cfg.encoding)
// logDebug(`Queue ${this.queues.dynamicReplyQueueReader.name} getMessage()): started (${Date.now()})`)
    }
    /**
     * private
     * 
     */
    get nextCorrelationId() {
        return (this.correlationIdBase + Date.now()).toString(10)
    }    
    /**
     * public
     * 
     * @param xmlMessage 
     */
    write(xmlMessage) {
//DEBUG BEGIN>>>
        messagesReceived++
        logger.info(`BRIDGE 201 (#${this.clientId})`, 'xmlMessage received')
//DEBUG <<<END
        if (this.state !== 'ready') {
            throw new DxlProtocolError(`bridge cannot write while in state ${this.state}`, 'DXL0008', Severity.warn)
        }
        try {
            // analyze message
            let rgxType = /<Service/g
            if (rgxType.test(xmlMessage)){
                let rgxRequest = /BusnResult="Y"/g
                if (!rgxRequest.test(xmlMessage)) {
                    // ANY NON-REQUEST
                    // case a) (sync) process and put onto sync queue
//DEBUG BEGIN>>>
                    datagramsReceived++
                    logger.info(`BRIDGE 202 (#${this.clientId})`, 'datagram received')
//DEBUG <<<END
                    this.handleDatagram(xmlMessage)
                } else {
                    // REQUEST
//DEBUG BEGIN
                    requestsReceived++
                    logger.info(`BRIDGE 203 (#${this.clientId})`, 'request received')
//DEBUG <<<END
                    this.handleRequest(xmlMessage)
                } 
            } else {
                let rgxPoll = /<POLL_REQUEST/g
                if (rgxPoll.test(xmlMessage)) {
//DEBUG BEGIN>>>
                    pollRequestsReceived++
                    logger.info(`BRIDGE 204 (#${this.clientId})`, 'poll request received')
//DEBUG <<<END
                    this.handlePollRequest(xmlMessage)
                } else {
                    // ignore unknown patterns
//DEBUG BEGIN>>>
                    unrecognizedMessages++
                    this.emit('DEBUG', `unrecognized: ${xmlMessage}`)
//DEBUG <<<END
                }
            }
        } catch(err) {
            this.raiseError(err)
        }
    }
    /**
     * private
     * 
     * @param msg 
     */
    handleDatagram(xmlMessage) {
        this.stats.datagramsReceived++
        const self = this
        let queue = this.bw.taskQueues.get('datagram')
        this.bw.addTask('datagram', () => {
            if (queue.busy) {
                return false
            }
            queue.busy = true
            let msg = {
                body: xmlMessage,
                ubsMsgType: 'synchronousRequest'
            }
            const binMsg = encode(this.clientId, msg)
            const options = {
                msgType: 'DATAGRAM'
            }
            self.queues.syncQueueWriter.putMessage(binMsg, options, err => {
                queue.busy = false
                if (err) {
                    const code = 'DXL0062'
                    const verb = 'PUT'
                    self.stats.errorsOnPut++
                    if (err.name === 'MQError') {
                        // eslint-disable-next-line no-ex-assign
                        err = new MqError(err.message, err, self.constructor.name, code, options, verb)
                    } else {
                        err.code ||= code
                        err.verb ||= verb
                    }
                    err.Severity = Severity.error
                    return self.raiseError(err)
                }
                self.stats.datagramsPosted++
            })
            return true
        })
    }
    /**
     * private
     * 
     * @param msg 
     */
    handleRequest(xmlMessage) {
        this.stats.requestsReceived++
        const self = this
        let queue = this.bw.taskQueues.get('request')
        this.bw.addTask('request', () => {
            if (queue.busy) {
                return false
            }
            queue.busy = true
            // case b) (async)
            // b1) create request id (correlation id)
            const correlationId = this.nextCorrelationId
// logDebug(`bridge built correlation id ${correlationId}`)
            let msg = {
                body: xmlMessage,
                ubsMsgType: 'asynchronousRequest',
                timeout: constants.timeout.async,
                requestId: correlationId,
            }
           // b2) process and put message with id onto async queue
            const binMsg = encode(self.clientId, msg)
            self.queues.asyncWriter.putMessage(binMsg, {
                msgType: 'REQUEST',
                correlationId,
                replyQueueName: self.queues.dynamicReplyQueueReader.name
            }, err => {
                queue.busy = false
                if (err) {
                    self.stats.errorsOnPost++
                    const code = 'DXL0063'
                    const verb = 'PUT'
                    if (err.name === 'MQError') {
                        // eslint-disable-next-line no-ex-assign
                        err = new MqError(err.message, err, self.constructor.name, code, undefined, verb)
                    } else {
                        err.code ||= code
                        err.verb ||= verb
                    }
                    err.Severity = Severity.error
                    self.raiseError(err)
                }
                self.stats.requestsPosted++
                // b3) on confirmation (callback) send correlation id to client
                const correlationIdResponse = self.buildCorrelationIdResponse(correlationId)
// logDebug(`sending correlation id response (${Date.now()})`)
                self.sendData(correlationIdResponse)
                self.stats.correlationIdResponsesSent++
// DEBUG BEGIN>>>
                logger.info(`BRIDGE 205 (#${this.clientId})`, 'correlation id response sent')
// DEBUG <<<END
            })
            return true
        })
    }
    /**
     * private
     * 
     * @param correlationId 
     * @param replyQueue 
     * @returns 
     */
    buildCorrelationIdResponse(correlationId) {
        return `<?xml version="1.0" encoding="${this.cfg.isoEncoding}"?><CorrelationIdResponse` +
            ` Timestamp="${dateString()}" CorrelationId="${correlationId}"/>`
    } 
    /**
     * private
     * 
     * @param xmlMessage 
     */
    handlePollRequest(xmlMessage) {
        this.stats.pollRequestsReceived++
        const self = this
        this.bw.addTask('pollRequest', () => {
            // case c) (poll request with correlation id)
            let correlationId = parseInt(extractCorrelationId(xmlMessage))
            if (!correlationId) {
                // not found/NaN: ignore
                // TODO: make sure that this behavior is correct
                return
            }
            logger.info(`BRIDGE 206 (#${self.clientId})`, `received poll request for correlation id ${correlationId} (${Date.now()})`)
            try {
                if (self.waitingReplies.has(correlationId)) {
                    self.sendReply(self.waitingReplies.get(correlationId))
                    self.stats.repliesSent++
// DEBUG BEGIN>>>
                    this.emit('DEBUG', `BRIDGE: reply sent for correlation id ${correlationId} (${Date.now()})`)
// DEBUG <<<END
                    self.waitingReplies.delete(correlationId)
                } else {
                    self.openPollRequests.add(correlationId)
// DEBUG BEGIN>>>
                    this.emit('DEBUG', `BRIDGE: poll request for correlation id ${correlationId} open (${Date.now()})`)
// DEBUG <<<END
                }
            } catch(err) {
                err.code = 'DXL0064'
                err.verb = 'SEND'
                err.Severity = Severity.error
                self.raiseError(err)
            }
            return true
        })
    }
    /**
     * private
     * 
     * @param data 
     */
     sendData(data) {
        this.emit('data', data)
//DEBUG BEGIN
        responsesSent++
//DEBUG <<<END
    }
    /**
     * private
     * 
     * @param data 
     */
     sendReply(data) {
        this.emit('reply', data)
//DEBUG BEGIN
        repliesSent++
//DEBUG <<<END
    }
    /**
     * private
     * 
     * @param err 
     */
    raiseError(err) {
        this.emit('error', err)
    }
    /**
     * public
     * 
     */
    get statistics() {
        const stats = { ...this.stats, }
        stats.bwStatistics = {
            ...this.bw.stats,
        }
        return stats
    }
    /**
     * public
     * 
     * @returns statistics
     */
    async close() {
        if (this.state === 'closed') {
            return
        }
        try {
            for (let qname  in this.queues) {
                await this.queues[qname]?.getDoneAsync()
                await this.queues[qname]?.close()
            }
            this.queues = {}
            await this.qm?.close()
            this.qm = null
            const state = 'closed'
            this.state = state
            this.emit(state, this.statistics)
        } catch(err) {
            const code = 'DXL0006'
            const verb = 'CLOSE'
            if (err.name === 'MQError') {
                // eslint-disable-next-line no-ex-assign
                err = new MqError(err.message, err, this.constructor.name, code, undefined, verb, Severity.error)
            } else {
                err.code ||= code
                err.verb ||= verb
            }
            this.raiseError(err)
        }
        this.bw?.stop()
//DEBUG BEGIN>>>
        this.emit('INFO', `received ${messagesReceived} messages`)
        this.emit('INFO', `could not recognize ${unrecognizedMessages} messages`)
        this.emit('INFO', `received ${datagramsReceived} datagrams`)
        this.emit('INFO', `received ${requestsReceived} requests`)
        this.emit('INFO', `sent ${responsesSent} correlation ids`)
        this.emit('INFO', `received ${pollRequestsReceived} poll requests`)
        this.emit('INFO', `sent ${repliesSent} replies`)
//DEBUG <<<END
        this.emit('INFO', this.statistics)
    }
}

export default DxlBridge

