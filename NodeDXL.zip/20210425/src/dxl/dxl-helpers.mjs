function dateString() {
    let d = new Date()
    return [
        '20' + ('00' + d.getYear()).substr(-2),
        ('00' + d.getMonth()).substr(-2),
        ('00' + d.getDay()).substr(-2),
        ('00' + d.getHours()).substr(-2),
        ('00' + d.getMinutes()).substr(-2),
        ('00' + d.getSeconds()).substr(-2),
        ('000' + d.getMilliseconds()).substr(-3),
    ].join('')
}

export {
    dateString,
}