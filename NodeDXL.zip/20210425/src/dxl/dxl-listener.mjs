import net from 'net'
import process from 'process'

import {
    initializeDiagnostics,
    logger,
} from './dxl-diagnostics.mjs'
import DxlBridgeController from './dxl-bridge-controller.mjs'


process.on('uncaughtException', err => {
    logger.error('LISTENER 001', `uncaughtException ${err}`)
    if (err.mqrc === 2018) {
        process.exit(0)
    } else {
        logger.error('LISTENER 002', err)
        process.exitCode = err.mqrc || err.errCode || 3
    }
})

process.on('unhandledRejection', reason => {
    logger.error('LISTENER 003', `unhandledRejection: ${reason}`)
    process.exitCode = 2
})

class DxlListener {
    server
    bridgeControllers = new Set()
    currentClientId = 0
    cfg
    listenerCfg
    bridgeCfg
    bridgeCtl
    commCtl
    constructor(cfg) {
        this.cfg = cfg
        initializeDiagnostics(cfg.DEBUG, cfg.LOG_LEVEL) // DEBUG
    }

    start() {
        this.server = net.createServer({}, socket => {
            this.cfg.bridgeCfg.clientId = ++this.currentClientId
            socket.setEncoding(this.cfg.listenerCfg.encoding)
            socket.pause()
            const args = [
                this.cfg.commCtl,
                this.cfg.bridgeCfg,
                this.cfg.bridgeCtl,
                socket,
                this.cfg.DEBUG,
                this.cfg.LOG_LEVEL,
            ]
            const bridgeController = new DxlBridgeController(...args)
            this.bridgeControllers.add(bridgeController)
        })
        this.server.on('error', err => logger.error('LISTENER 004', err))
        const { host, port } = this.cfg.listenerCfg
        this.server.listen(this.cfg.listenerCfg, () => logger.info('LISTENER 005', `DXL server ${host} listening at port ${port}`))
    }

    stop() {
        this.bridgeControllers.forEach(async controller => await controller.close())
        this.server.close(() => logger.info('LISTENER 006', 'DXL listen service closed'))
    }
}

export default DxlListener