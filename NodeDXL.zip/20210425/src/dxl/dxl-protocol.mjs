import assert from 'assert/strict'
import {
    NotImplementedError,
    NotFoundError,
    InvalidOperationError,
    ArgumentError,
    MqError,
} from '../main/imqo-errors.mjs'

import {
    DxlProtocolError,
    DxlError,
} from './dxl-errors.mjs'

function DxlConfigurationMessage(what, cfgData) {
    this.configuration = true
    this.what = what
    this.cfgData = cfgData
}

function DxlControlMessage(what, ctlData) {
    this.control = true
    this.what = what
    this.ctlData = ctlData
}

function DxlDataMessage(payload) {
    this.data = true
    this.payload = payload
}

function DxlDiagnosticsMessage(what, payload) {
    this.diagnostics = true
    this.what = what
    this.payload = payload
}

function DxlDebugMessage(what, payload) {
    this.debug = true
    this.what = what
    this.payload = payload
}

function DxlInfoMessage(what, payload) {
    this.info = true
    this.what = what
    this.payload = payload
}

/**
 * 
 * @param err 
 * @returns 
 */
function DxlErrorMessage(err) {
    this.error = true
    this.name = err.name
    this.message = err.message
    this.severity = err.severity
    this.fileName = err.fileName
    this.lineNumber = err.lineNumber
    this.columnNumber = err.columnNumber
    this.stack = err.stack
    this.code = err.code
    this.options = err.options
    this.verb = err.verb
    this.mqcc = err.mqcc
    this.mqccstr = err.mqccstr
    this.mqrc = err.mqrc
    this.mqrcstr = err.mqrcstr
    this.mqObjectName = err.mqObjectName
    this.version = err.version
    this.severity = err.severity
}

function copyProperties(src, tgt) {
    [
        'fileName',
        'lineNumber',
        'columnNumber',
        'stack',
        'code',
        'severity',
        'message',
        'options',
        'verb',
        'mqcc',
        'mqccstr',
        'mqrc',
        'mqrcstr',
        'mqObjectName',
        'version',
    ].forEach(prop => {
        if (src[prop] || src[prop] === 0) {
            tgt[prop] = src[prop]
        }
    })
}

function unpackError(packet) {
    assert(packet.error)
    let err
    console.log(`unpack() severity: ${packet.severity}`)
    switch(packet.name) {
        case 'ArgumentError':
            err = new ArgumentError(packet.message, packet.code, packet.options, packet.verb, packet.severity)
            break
        case 'DxlProtocolError':
            err = new DxlProtocolError(packet.message, packet.code, packet.severity)
            break
        case 'DxlError':
            err = new DxlError(packet.message, packet.code, packet.severity)
            break
        case 'InvalidOperationError':
            err = new InvalidOperationError(packet.message, packet.code, packet.options, packet.verb, packet.severity)
            break
        case 'NotFoundError':
            err = new NotFoundError(packet.message, packet.code, packet.options, packet.verb, packet.severity)
            break
        case 'NotImplementedError':
            err = new NotImplementedError(packet.message, packet.options, packet.verb, packet.severity)
            break
        case 'MqError':
            err = new MqError(packet.message, packet, packet.mqObjectName, packet.code, packet.options, packet.verb, packet.severity)
            break
        case 'RangeError':
            err = new RangeError(packet.message)
            break
        case 'ReferenceError':
            err = new ReferenceError(packet.message)
            break
        case 'SyntaxError':
            err = new SyntaxError(packet.message)
            break
        case 'TypeError':
            err = new TypeError(packet.message)
            break
        default:
            err = new Error()
            break
    }
    copyProperties(packet, err)
    return err
}

export {
    DxlConfigurationMessage,
    DxlControlMessage,
    DxlDataMessage,
    DxlDebugMessage,
    DxlDiagnosticsMessage,
    DxlErrorMessage,
    DxlInfoMessage,
    unpackError,
} 