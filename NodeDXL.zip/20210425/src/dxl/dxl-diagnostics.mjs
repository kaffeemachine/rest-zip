const LogLevel = {
    complete: 0,
    verbose: 1,
    debug: 2,
    info: 4,
    warning: 8,
    error: 16,
}
Object.freeze(LogLevel)

const maxLogMessageLength = 160
let DEBUG = true
let LOG_LEVEL = LogLevel.verbose

function initializeDiagnostics(debug, logLevel = LogLevel.warning) {
    DEBUG = debug
    LOG_LEVEL = logLevel
}

const logger = new (function() {
    Object.getOwnPropertyNames(LogLevel).forEach(prop => {
        this[prop] = (code, message) => log(LogLevel[prop], code, message)
    })
    this.printStatistics = (label, statistics) => {
        this.info(label, 'STATISTICS:')
        for (let facet in statistics) {
            if (!facet.startsWith('bw')) {
                this.info(`\t${facet}: ${statistics[facet]}`)
            }
        }
        statistics = statistics.bwStatistics
        for (let facet in statistics) {
            this.info(`\t${facet}: ${statistics[facet]}`)
        }
    }
})()
Object.freeze(logger)

function log(logLevel, code, message) {
   if ((logLevel !== 0 && !logLevel) || isNaN(parseInt(logLevel)) || LOG_LEVEL > logLevel) {
        return
    }
    const label = Object.getOwnPropertyNames(LogLevel).find(prop => LogLevel[prop] === logLevel)?.toUpperCase()
    if (!label) {
        return
    }
    if (logLevel === LogLevel.debug && !DEBUG && LOG_LEVEL !== LogLevel.debug) {
        return
    }
    message ||= code
    if (message === code) {
        code = undefined
    }
    if (logLevel > LogLevel.complete && logLevel !== LogLevel.error && message.length > maxLogMessageLength) {
        message = message.substr(0, maxLogMessageLength - 3) + '...'
    }
    const output = `[${label}] ${code && code !== message? '(' + code.toString().toUpperCase() + ') ' : ''}${message}`
    console.log(output)
}

// function logErr(id, err) {
//     if(DEBUG) {
//         if (Number.isInteger(id)) {
//             if (id === -2) {
//                 console.log(`ERROR [${err.code || err.mqrc || '----'}}]: Host Receiver Service -`, err)
//                 return
//             }
//             if (id === -1) {
//                 console.log(`ERROR [${err.code || err.mqrc || '----'}}]: Host Responder Service -`, err)
//                 return
//             }
//             switch(id) {
//                 case 0:
//                     console.log(`ERROR [${err.code || err.mqrc || '----'}]: Test -`, err)
//                     break
//                 default:
//                     console.log(`ERROR [${err.code || err.mqrc || '----'}]: ClientConnectioon #${id} -`, err)
//                     break
//             }
//         } else {
//             console.log(id, err)
//         }
//     }
// }

// function logWarn(clientId, warning) {
//     if(DEBUG) {
//         if (!warning) {
//             warning = clientId
//             console.log(`WARNING [${warning.code === 0? 0 : (warning.code || '-')}]: ${warning.message}`)
//             return
//         }
//         console.log(`WARNING [${warning.code === 0? 0 : (warning.code || '-')}]: Client #${clientId} - ${warning.message}`)
//     }
// }

// function logInfo(clientId, info) {
//     if(DEBUG) {
//         if (!info) {
//             info = clientId
//             console.log(`INFO: ${info.message}`)
//             return
//         }
//         info ||= clientId
//         console.log(`INFO: Client #${clientId} - ${info.message}`)
//     }
// }

// function logDebug(id, ...info) {
//     if(DEBUG) {
//         if (Number.isInteger(id)) {
//             if (id === -2) {
//                 console.log('INFO: Host Receiver Service', ...info)
//                 return
//             }
//             if (id === -1) {
//                 console.log('INFO: Host Responder Service', ...info)
//                 return
//             }
//             switch(id) {
//                 case 0:
//                     console.log('INFO: Test:', ...info)
//                     break
//                 default:
//                     console.log(`INFO: Client #${id}:`, ...info)
//                     break
//             }
//         } else {
//             console.log(id, ...info)
//         }
//     }
// }

export {
    logger,
    LogLevel,
    log,
    // logErr,
    // logWarn,
    // logInfo,
    // logDebug,
    initializeDiagnostics,
}