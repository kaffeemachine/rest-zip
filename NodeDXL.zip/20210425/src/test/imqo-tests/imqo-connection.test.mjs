/**
 * @jest-environment node
 */

import {
    expect,
    test,
} from '@jest/globals'
import {
    Connection,
} from'../../main/imqo-connection.mjs'
import {
    queueManagerName,
} from './imqo-test-cfg.mjs'

// basic connection creation
test('a new connection is closed', () => {
    // arrange
    let cn
    // act
    cn = new Connection(queueManagerName)
    // assert
    expect(cn.isClosed).toBe(true)
})

test('creation of a connection without queue manager name fails', () => {
    // arrange
    const expectedError = new Error('no queue manager name specified')
    const createConnectionWithoutQueueManagerName = () => {
        // act
        return new Connection()
    }
    // assert
    expect(createConnectionWithoutQueueManagerName).toThrow(expectedError)
})

test('opening a connection without queue manager name fails', async () => {
    // arrange
    const expectedError = new Error('no queue manager name specified')
    const openConnectionWithoutQueueManagerName = async () => {
        // act
        return await Connection.open()
    }
    // assert
     await expect(openConnectionWithoutQueueManagerName()).rejects.toThrow(expectedError)
})

test('opening a connection changes its state to \'open\'', async () => {
    // arrange
    const cn = new Connection(queueManagerName)
    // act
    await cn.connect()
    // assert
    expect(cn.isOpen).toBe(true)
    await cn.close()
    // try {
    // // eslint-disable-next-line no-empty
    // } catch(err) { }
})

test('closing an open connection changes its state to \'closed\'', async () => {
    // arrange
    const cn = await Connection.open(queueManagerName)
    // act
    await cn.close()
    // assert
   expect(cn.isClosed).toBe(true)
})

test('trying to connect to a non-existing queue manager fails', async () => {
    // arrange
    const cn = new Connection('fakeQmNanger')
    const openWithNonExistingQmMqnger = async () => {
        // act
        await cn.connect()
    }
    // assert
    await expect(openWithNonExistingQmMqnger).rejects.toThrow()
})

test('trying to open a connection which is already open returns same connection', async () => {
    // arrange
    const cn = await Connection.open(queueManagerName)
    // act
    const actual = await cn.connect()
    // assert
    expect(actual).toBe(cn)
})

test('trying to close a connection which is not open fails', async () => {
    // arrange
    const cn = new Connection(queueManagerName)
    const expectedError = new Error('connection is already closed')
    // act
    const closeAClosedConnection = async () => {
        await cn.close()
    }
    // assert
    await expect(closeAClosedConnection()).rejects.toThrow(expectedError)
})

test('opening a connection fires \'open\' event', async () => {
    // arrange
    const cn = new Connection(queueManagerName)
    const executor = async resolve => {
        cn.on('open', () => {
            resolve(true)
        })
        // act
        await cn.connect()
    }
    const trapOpenEvent = async () => {
        // eslint-disable-next-line no-async-promise-executor
        return new Promise(executor)
    }
    // assert
    await expect(trapOpenEvent()).resolves.toBe(true)
})

test('closing a connection fires \'closed\' event', async () => {
    // arrange
    const cn = await Connection.open(queueManagerName)
    const executor = async resolve => {
        cn.on('closed', () => {
            resolve(true)
        })
        // act
        await cn.close()
    }
    const trapCloseEvent = async () => {
        return new Promise(executor)
    }
    // assert
    await expect(trapCloseEvent()).resolves.toBe(true)
})

test('getConnectionByHandle yields an open connection by its handle', async () => {
    // arrange
    const cn = new Connection(queueManagerName)

    const connectAndRetrieveByHandle = async () => {
        try {
            await cn.connect()
            // act
            const retrieved = Connection.getConnectionByHandle(cn.hCn)
            await cn.close()
            return retrieved
        } catch(e) {
            return e
        }
    }
    // assert
    await expect(connectAndRetrieveByHandle()).resolves.toBe(cn)
})

test('a closed connection is not returned by getConnectionByHandle', async () => {
    // arrange
    const cn = await Connection.open(queueManagerName)
    // act
    await cn.close()
    // assert
    expect(Connection.getConnectionByHandle(cn.hCN)).toBe(undefined)
})

test('a previously closed connection can be re-opened', async () => {
    // arrange
    const cn = await Connection.open(queueManagerName)
    await cn.close()
    // act
    const result = await cn.connect(queueManagerName)
    // assert
    expect(result).toBe(cn)
    expect(cn.isOpen).toBe(true)
    expect(Connection.getConnectionByHandle(cn.hCn)).toBe(cn)
})