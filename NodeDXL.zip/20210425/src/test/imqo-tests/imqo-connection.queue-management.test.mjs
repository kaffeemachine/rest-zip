/**
 * @jest-environment node
 */

import {
    beforeEach,
    expect,
    test,
} from '@jest/globals'
import { 
    Connection,
    provideConnection,
} from '../../main/imqo-connection.mjs'
import {
    queueManagerName,
    asyncReplyQueueModel,
    dynamicQueueNamePrefix
} from './imqo-test-cfg.mjs'

const endianess = 1
const encoding ='latin1'

beforeEach(() => {
    Connection.initialize(endianess, encoding)
})

test('creating a dynamic reply queue with correct parameters succeeds', async () => {
    // arrange
    const cn = await provideConnection(queueManagerName)
    const qNamePrefix = dynamicQueueNamePrefix.substr(0, dynamicQueueNamePrefix.indexOf('*'))
    // act
    const drq = await cn.createDynamicReplyQueue(dynamicQueueNamePrefix, {
        dynamic: true,
        readExclusive: true,
        modelQueueName: asyncReplyQueueModel,
        tx: false,
    })
    // assert
    expect(!drq).not.toBe(true)
    expect(drq.name.substr(0, qNamePrefix.length)).toBe(qNamePrefix)
    // cleanup
    if (drq.isOpen) {
        await drq.close()
    }
    await cn.close()
})

test('a previously created dynamic reply queue may be opened for write', async () => {
    // arrange
    Connection.initialize(1, 'latin1')
    const cn = await provideConnection(queueManagerName)
    const drq = await cn.createDynamicReplyQueue(dynamicQueueNamePrefix, {
        dynamic: true,
        readExclusive: true,
        modelQueueName: asyncReplyQueueModel,
        tx: false,
    })
    // act
    const dwq = await cn.createQueueWriter(drq.name)
    // assert
    expect(!!dwq).toBe(true)
    // cleanup
    if (drq.isOpen) {
        await drq.close()
    }
    if (dwq.isOpen) {
        await dwq.close()
    }
    await cn.close()
})