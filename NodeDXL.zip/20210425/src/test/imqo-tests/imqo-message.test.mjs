/**
 * @jest-environment node
 */

import {
    expect,
    test,
} from '@jest/globals'

test('dummy', () => {
    // arrange
    // act
    // assert
    expect(true).toBe(true)
})