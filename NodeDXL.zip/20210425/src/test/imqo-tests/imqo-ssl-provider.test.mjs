/**
 * @jest-environment node
 */

import {
    describe,
    expect,
    test,
} from '@jest/globals'
import mq from 'ibmmq'
import SslProvider from '../../main/imqo-ssl-provider.mjs'

const MQC = mq.MQC
const cipherSpec = 'ECDHE_RSA_AES_128_GCM_SHA256'
const clientAuthentication = 'always'
const clientAuth = MQC.MQSCA_ALWAYS_REQUIRED

test('ssl provider sets client authentication and cipher spec correctly', () => {
    // arrange
    const sslp = new SslProvider({
        cipherSpec,
        clientAuthentication,
    })
    const cd = new mq.MQCD()    // connection descriptor
    // act
    sslp.configure(cd)
    // assert
    expect(cd.SSLCipherSpec).toBe(cipherSpec)
    expect(cd.SSLClientAuth).toBe(clientAuth)
})

test('creating an SSL provider with an invalid cipher spec fails', () => {
    // arrange
    const options = {
        cipherSpec: '08-15'
    }
    const expectedMessage =  `invalid cipher spec '${options.cipherSpec}'`
    const createAnSslProviderWithAnInvalidCipherSpec = () => {
        // act
        return new SslProvider(options)
    }
    // assert
    expect(createAnSslProviderWithAnInvalidCipherSpec).toThrow(expectedMessage)
})

test('creating an SSL provider with an invalid client authentication option fails', () => {
    // arrange
    const options = {
        clientAuthentication: 'none'
    }
    const expectedMessage = `invalid client authentication option '${options.clientAuthentication}'`
    const createAnSslProviderWithAnInvalidClientAuthenticationOption = () => {
        // act
        return new SslProvider(options)
    }
    // assert
    expect(createAnSslProviderWithAnInvalidClientAuthenticationOption).toThrow(expectedMessage)
})

describe.each([
    ['neverRequired', 'MQSCA_NEVER_REQUIRED', MQC.MQSCA_NEVER_REQUIRED],
    ['always', 'MQSCA_ALWAYS_REQUIRED', MQC.MQSCA_ALWAYS_REQUIRED],
    ['optional', 'MQSCA_OPTIONAL', MQC.MQSCA_OPTIONAL],
], 'connection security', (value, mq_flag, expected) => {
    test(`option '${value}' causes ${mq_flag} flag (${expected}) to be set as client authentication`, () => {
        // arrange
        const sslp = new SslProvider({
            clientAuthentication: value,
        })
        // act
        const sco = sslp.configure(new mq.MQCNO())
        // assert
        expect(sco.SSLClientAuth).toBe(MQC[mq_flag])
    })
})
