const queueManagerName = 'QM_PEGASUS'
const asyncReplyQueueName = 'FYC00.FYC00.LF000.FYC.R.DXL.ASYNC'
const asyncReplyQueueModel = 'FYX00.FYC00.LF000.FYC.R.DXL.ASYNC.MODEL'
const asyncRequestQueueName = 'FYC00.FYC00.LF000.FYC.Q.DXL.ASYNC'
const syncQueueName = 'FYC00.FYC00.LF000.FYC.DXL.SYNC'
const dynamicQueueNamePrefix = 'FYX00.FYC00.LF000.FYC.R.DXL.DYN*' // MAXLEN: 32 chars

const waitForReplyDuration = 60 * 1000 * 3

const byteConversionCharacteristics = {
    isoEncoding: 'ISO-8859-1',
    encoding: 'latin1',   // the same in node speak
    endianess: 1, // little endian (for binary conversions)
}

const {
    isoEncoding,
    encoding,
    endianess,
} = byteConversionCharacteristics

export {
    isoEncoding,
    encoding,   // the same in node speak
    endianess, // little endian (for binary conversions)
    queueManagerName,
    asyncReplyQueueName,
    asyncReplyQueueModel,
    asyncRequestQueueName,
    syncQueueName,
    dynamicQueueNamePrefix, // MAXLEN: 32 chars
    waitForReplyDuration,
}