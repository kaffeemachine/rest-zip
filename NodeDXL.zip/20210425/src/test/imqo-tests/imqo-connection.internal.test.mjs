/**
 * @jest-environment node
 */

import {
    describe,
    expect,
    test,
} from '@jest/globals'
import { Connection } from '../../main/imqo-connection.mjs'
import mq from 'ibmmq'

const MQC = mq.MQC

// evaluating options
test('setMqOptions function returns a Connection Options object', () => {
    // arrange
    let actual
    // act
    actual = Connection.setMqOptions({})
    // assert
    expect(actual instanceof mq.MQCNO).toBe(true)
})

test('given application name option is correctly set by setMqOptions', () => {
    // arrange
    const applicationName = 'nodejs ibm mq application'
    const options = { applicationName, }
    // act
    const cno = Connection.setMqOptions(options)
    // assert
    expect(cno.ApplName).toBe(applicationName)
})

describe.each([
    ['standard', 'MQCNO_STANDARD_BINDING', MQC.MQCNO_STANDARD_BINDING],
    ['shared', 'MQCNO_SHARED_BINDING', MQC.MQCNO_SHARED_BINDING],
    ['isolated', 'MQCNO_ISOLATED_BINDING', MQC.MQCNO_ISOLATED_BINDING],
    ['local', 'MQCNO_LOCAL_BINDING', MQC.MQCNO_LOCAL_BINDING],
    ['client', 'MQCNO_CLIENT_BINDING', MQC.MQCNO_CLIENT_BINDING],
])('bindings', (field, mq_flag, expected) => {
    test(`option '${field}' causes ${mq_flag} flag (${expected}) to be set by setMqOptions`, () => {
        // arrange
        let options = { bindings: { [field]: true } }
        // act
        const cno = Connection.setMqOptions(options)
        // assert
        // eslint-disable-next-line no-undef
        expect(cno.Options & MQC[mq_flag]).toBe(expected)
    })
})

test('setMqOptions: having user authentication with user id and password set but no user credentials provided fails', () => {
    // arrange
    let options = {
        authentication: {
            type: 'userCredentials',
        },
     }
    // act
    const setOptionsToRequireUserCredentialsWithoutProvidingThem = () => {
        Connection.setMqOptions(options)
    }
    // assert
    expect(setOptionsToRequireUserCredentialsWithoutProvidingThem).toThrow('missing user credentials')
})

test('setMqOptions sets user id and password correctly for required credentials when delivered', () => {
    // arrange
    const userId = 'user4711'
    const password = 'Pa$$w0rdxyz@!!#'
    const options = {
        authentication: {
            type: 'userCredentials',
            userCredentials: {
                userId,
                password,
            },
        },
    }
    // act
    const cn = Connection.setMqOptions(options)
    // assert
    expect(!!cn.SecurityParms).toBe(true)
    expect(cn.SecurityParms.UserId).toBe(userId)
    expect(cn.SecurityParms.Password).toBe(password)
    expect(cn.SecurityParms._authenticationType).toBe(MQC.MQCSP_AUTH_USER_ID_AND_PWD)
})

// eslint-disable-next-line no-undef
test('channel and connection name are correctly set by setMqOptions', () => {
    // arrange
    const connectionName = 'localhost(1414)'
    const channelName = 'SYSTEM.SSL.SVRCONN'
    const options = {
        connectionName,
        channelName,
    }
    
    // act
    const cn = Connection.setMqOptions(options)
    // assert
    // eslint-disable-next-line no-undef
    expect(cn.ClientConn.ConnectionName).toBe(connectionName)
    // eslint-disable-next-line no-undef
    expect(cn.ClientConn.ChannelName).toBe(channelName)
})
