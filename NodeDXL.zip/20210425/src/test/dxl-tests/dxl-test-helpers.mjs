import dxlTestCfg from './dxl-test-cfg.mjs'

const {
    isoEncoding,
    endianess,
} = dxlTestCfg.byteConversionCharacteristics

const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz01234567890'

function makeRandomMessage() {
    return `<?xml version="1.0" encoding="${isoEncoding}"?>
    <Service xmlns="uri://bw.ubs.com/map">
      <Header UbsXmlStd="1.7" CreationTimestamp="${Date.now()}" ServiceName="${rndmString()}" Entity="033" MsgLanguage="en" Timestamp="${dateString()}" ` +
        `BusnDealId="${rndmEmptyString()}"  BusnTxnId="${rndmEmptyString()}" Async="${rndmYesNo()}" BusnResult="${rndmYesNo()}" ` +
        `Confirm="${rndmYesNo()}" ExtGroupId="${rndmEmptyString()}" IntGroupId="${rndmEmptyString()}" ` +
        `TrackingId="${rndmEmptyString()}" SrvcExecId="" MessageId="${rndmEmptyString()}" SessionId="${rndmEmptyString()}" SrvcPriority="">
        <Version Major="1" Minor="0" Patch=20"/>
        <SecurityContextList>
          <SecurityContext Index="0" UserType="2" UserId="FR90672" Location="CH" AuthnStrength="S" ` +
           `AuthnTimeStamp="${dateString()}" Channel="10" Zone="-"/>
          <SecurityContext Index="2" UserType="2" SwSysId="G34" AudTrailId="G34"/>
        </SecurityContextList>
      </Header>
      <Input>
        <ExtCwbContractId>${rndmEmptyString()}</ExtCwbContractId>
      </Input>
    </Service>`
}

function makeRandomRequest() {
    return `<?xml version="1.0" encoding="${isoEncoding}"?>
    <Service xmlns="uri://bw.ubs.com/map">
      <Header UbsXmlStd="1.7" CreationTimestamp="${Date.now()}" ServiceName="${rndmString()}" Entity="033" MsgLanguage="en" Timestamp="${dateString()}" ` +
        `BusnDealId="${rndmEmptyString()}"  BusnTxnId="${rndmEmptyString()}" Async="${rndmYesNo()}" BusnResult="Y" ` +
        `Confirm="${rndmYesNo()}" ExtGroupId="${rndmEmptyString()}" IntGroupId="${rndmEmptyString()}" ` +
        `TrackingId="${rndmEmptyString()}" SrvcExecId="" MessageId="${rndmEmptyString()}" SessionId="${rndmEmptyString()}" SrvcPriority="">
        <Version Major="1" Minor="0" Patch=20"/>
        <SecurityContextList>
          <SecurityContext Index="0" UserType="2" UserId="FR90672" Location="CH" AuthnStrength="S" ` +
           `AuthnTimeStamp="${dateString()}" Channel="10" Zone="-"/>
          <SecurityContext Index="2" UserType="2" SwSysId="G34" AudTrailId="G34"/>
        </SecurityContextList>
      </Header>
      <Input>
        <ExtCwbContractId>${rndmEmptyString()}</ExtCwbContractId>
      </Input>
    </Service>`
}

function makeRandomDatagram() {
    return `<?xml version="1.0" encoding="${isoEncoding}"?>
    <Service xmlns="uri://bw.ubs.com/map">
      <Header UbsXmlStd="1.7" CreationTimestamp="${Date.now()}" ServiceName="${rndmString()}" Entity="033" MsgLanguage="en" Timestamp="${dateString()}" ` +
        `BusnDealId="${rndmEmptyString()}"  BusnTxnId="${rndmEmptyString()}" Async="${rndmYesNo()}" BusnResult="N" ` +
        `Confirm="${rndmYesNo()}" ExtGroupId="${rndmEmptyString()}" IntGroupId="${rndmEmptyString()}" ` +
        `TrackingId="${rndmEmptyString()}" SrvcExecId="" MessageId="${rndmEmptyString()}" SessionId="${rndmEmptyString()}" SrvcPriority="">
        <Version Major="1" Minor="0" Patch=20"/>
        <SecurityContextList>
          <SecurityContext Index="0" UserType="2" UserId="FR90672" Location="CH" AuthnStrength="S" ` +
           `AuthnTimeStamp="${dateString()}" Channel="10" Zone="-"/>
          <SecurityContext Index="2" UserType="2" SwSysId="G34" AudTrailId="G34"/>
        </SecurityContextList>
      </Header>
      <Input>
        <ExtCwbContractId>${rndmEmptyString()}</ExtCwbContractId>
      </Input>
    </Service>`
}

function makeReply(request, correlationId, replyQueueName, replyQueueManagerName) {
    let strCorrelationId = correlationId.toString()
    return {
        body: request.replaceAll('<Service', `<Reply ReplyCreationTimestamp="${Date.now()}"`).
            replace('BusnResult="Y"', `CorrelationId="${strCorrelationId}"`).
            replace('<ExtCwbContractId>', `<ExtCwbContractId accepted="${rndmYesNo()}">`).
            replace('ExtGroupId=', `ReplyQueueName="${replyQueueName}" ExtGroupId=`).
            replace('Service>', 'Reply>'),
        response: correlationId,
        replyQueueName,
        replyQueueManagerName,
    }
}

class PromisePlaceHolder {
  settled = false
  constructor() {
    this.promise = new Promise((resolve, reject) => {
      this.succeed = resolve
      this.fail = err => reject(err)
    }).finally(() => this.settled = true)
  }
}

function rndmEmptyString() {
    let x = Math.random()
    return (x>= 0.7? rndmString() : '')
}

function rndmYesNo() {
    let x = Math.random()
    return (x>= 0.5? 'Y' : 'N')   
}

function rndmCharBuf(bufLen, fillLen) {
    bufLen = bufLen || 24
    fillLen = fillLen || bufLen
    if (bufLen < fillLen) {
        fillLen = bufLen
    }
    // eslint-disable-next-line no-undef
    let buf = Buffer.alloc(bufLen)
    for (let i = 0; i< fillLen; i++) {
        let idx = Math.floor(((i === 0) ? 26 : chars.length) * Math.random())
        buf[i] = chars.charCodeAt(idx)
    }
    return buf
}

function rndmString(len) {
    return rndmCharBuf(len).toString('latin1')
}

function rndmBuf() {
    // eslint-disable-next-line no-undef
    let buf = Buffer.alloc(8)
    for (let i = 0; i< 8; i++) {
        buf[i] = Math.floor(256 * Math.random())
    }  
    return buf
}

function rndmBigUInt64() {
    return (endianess == 1)?
        rndmBuf().readBigUInt64LE(0) :
        rndmBuf().readBigUInt64BE(0)
}

function rndmBigUInt64Hex() {
    return rndmBigUInt64().toString(16).toUpperCase()
}

function rndmHexString() {
    return rndmBuf().toString('hex').toUpperCase()
}

function dateString() {
    let d = new Date()
    return [
        '20' + ('00' + d.getYear()).substr(-2),
        ('00' + d.getMonth()).substr(-2),
        ('00' + d.getDay()).substr(-2),
        ('00' + d.getHours()).substr(-2),
        ('00' + d.getMinutes()).substr(-2),
        ('00' + d.getSeconds()).substr(-2),
        ('000' + d.getMilliseconds()).substr(-3),
    ].join('')
}

export {
    dateString,
    rndmHexString,
    rndmBuf,
    rndmBigUInt64,
    rndmBigUInt64Hex,
    rndmString,
    rndmCharBuf,
    rndmYesNo,
    rndmEmptyString,
    makeRandomDatagram,
    makeRandomMessage,
    makeRandomRequest,
    makeReply,
    PromisePlaceHolder,
}
