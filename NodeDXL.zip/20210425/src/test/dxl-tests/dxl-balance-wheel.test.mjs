/**
 * @jest-environment node
 */

 import {
    beforeEach,
    afterEach,
    expect,
    test,
} from '@jest/globals'
import DxlBalanceWheel from '../../dxl/dxl-balance-wheel.mjs'

const interval = 1
let bw

beforeEach(() => {
    bw = new DxlBalanceWheel(interval)
})
afterEach(() => {
    bw?.stop()
})

test('creating task queues succeeds', () => {
    // arrange
    const queues = ['Q1', 'Q2', 'Q3', 'Q4']
    // act
    bw.createTaskQueues(queues)
    // assert
    expect(bw.taskQueues.size).toBe(queues.length)
    queues.forEach(q => expect(bw.taskQueues.has(q)).toBe(true))
})
test('creating an existing task queue succeeds', () => {
    // arrange
    const tq = 'Q'
    bw.createTaskQueue(tq)
    // act
    bw.createTaskQueue(tq)
    // assert
    expect(bw.taskQueues.has(tq)).toBe(true)
})
test('adding a task to a non-existing task queue succeeds', () => {
    // arrange
    const tq = 'Q'
    bw.createTaskQueue(tq)
    function noop() {}
    const nonTq = 'NQ'
    // act
    bw.addTask(nonTq, noop)
    // assert
    expect(bw.taskQueues.has(nonTq)).toBe(true)
})
test('an added task is executed once in a task cycle and then disappears', () => {
    // arrange
    let actual = 0
    const tq = 'Q'
    bw.createTaskQueue(tq)
    function run() {
        actual++
        return true
    }
    bw.addTask(tq, run)
    // act
    bw.runTaskCycle()
    // assert
    expect(actual).toBe(1)
    expect(bw.taskQueues.get(tq).indexOf(run)).toBe(-1)
    expect(bw.stats.tasksPerformed).toBe(1)
})
test('from the tasks added to the task queues, the first ones are executed in sequence in a task cycle', () => {
    // arrange
    let strSequence = ''
    const tq1 = 'Q1'
    const tq2 = 'Q2'
    const tq3 = 'Q3'
    const queueNames = [tq1, tq2, tq3]
    bw.createTaskQueues(queueNames)
    let r1_1 = false
    let r1_2 = false
    let r1_3 = false
    function run1_1() { r1_1 = true; strSequence += 1; return true }
    function run1_2() { r1_2 = true; strSequence += 4; return true }
    function run1_3() { r1_3 = true; strSequence += 7; return true }
    bw.addTask(tq1, run1_1)
    bw.addTask(tq1, run1_2)
    bw.addTask(tq1, run1_3)
    let r2_1 = false
    let r2_2 = false
    function run2_1() { r2_1 = true; strSequence += 2; return true }
    function run2_2() { r2_2 = true; strSequence += 5; return true }
    bw.addTask(tq2, run2_1)
    bw.addTask(tq2, run2_2)
    let r3_1 = false
    let r3_2 = false
    let r3_3 = false
    let r3_4 = false
    function run3_1() { r3_1 = true; strSequence += 3; return true }
    function run3_2() { r3_2 = true; strSequence += 6; return true }
    function run3_3() { r3_3 = true; strSequence += 8; return true }
    function run3_4() { r3_4 = true; strSequence += 9; return true }
    bw.addTask(tq3, run3_1)
    bw.addTask(tq3, run3_2)
    bw.addTask(tq3, run3_3)
    bw.addTask(tq3, run3_4)
    // act
    bw.runTaskCycle()
    // assert
    expect(r1_1).toBe(true)
    expect(bw.taskQueues.get(tq1).indexOf(run1_1)).toBe(-1)
    expect(r1_2).toBe(false)
    expect(bw.taskQueues.get(tq1).indexOf(run1_2)).toBeGreaterThanOrEqual(0)
    expect(r1_3).toBe(false)
    expect(bw.taskQueues.get(tq1).indexOf(run1_3)).toBeGreaterThanOrEqual(0)
    expect(r2_1).toBe(true)
    expect(bw.taskQueues.get(tq2).indexOf(run2_1)).toBe(-1)
    expect(r2_2).toBe(false)
    expect(bw.taskQueues.get(tq2).indexOf(run2_2)).toBeGreaterThanOrEqual(0)
    expect(r3_1).toBe(true)
    expect(bw.taskQueues.get(tq3).indexOf(run3_1)).toBe(-1)
    expect(r3_2).toBe(false)
    expect(bw.taskQueues.get(tq3).indexOf(run3_2)).toBeGreaterThanOrEqual(0)
    expect(r3_3).toBe(false)
    expect(bw.taskQueues.get(tq3).indexOf(run3_3)).toBeGreaterThanOrEqual(0)
    expect(r3_4).toBe(false)
    expect(bw.taskQueues.get(tq3).indexOf(run3_4)).toBeGreaterThanOrEqual(0)
    expect(bw.stats.tasksPerformed).toBe(3)
    expect(bw.stats.taskCyclesRun).toBe(1)
    expect(bw.stats.taskCyclesInitiated).toBe(1)
    expect(bw.stats.foundBusy).toBe(0)
    expect(strSequence).toBe('123')
})
test('all tasks added to the task queues are executed in sequence after start', async() => {
    let strSequence = ''
    // arrange
    const tq1 = 'Q1'
    const tq2 = 'Q2'
    const tq3 = 'Q3'
    const queueNames = [tq1, tq2, tq3]
    bw.createTaskQueues(queueNames)
    let r1_1 = false
    let r1_2 = false
    let r1_3 = false
    function run1_1() { r1_1 = true; strSequence += 1; return true }
    function run1_2() { r1_2 = true; strSequence += 4; return true }
    function run1_3() { r1_3 = true; strSequence += 7; return true }
    bw.addTask(tq1, run1_1)
    bw.addTask(tq1, run1_2)
    bw.addTask(tq1, run1_3)
    let r2_1 = false
    let r2_2 = false
    function run2_1() { r2_1 = true; strSequence += 2; return true }
    function run2_2() { r2_2 = true; strSequence += 5; return true }
    bw.addTask(tq2, run2_1)
    bw.addTask(tq2, run2_2)
    let r3_1 = false
    let r3_2 = false
    let r3_3 = false
    let r3_4 = false
    function run3_1() { r3_1 = true; strSequence += 3; return true }
    function run3_2() { r3_2 = true; strSequence += 6; return true }
    function run3_3() { r3_3 = true; strSequence += 8; return true }
    function run3_4() { r3_4 = true; strSequence += 9; return true }
    bw.addTask(tq3, run3_1)
    bw.addTask(tq3, run3_2)
    bw.addTask(tq3, run3_3)
    bw.addTask(tq3, run3_4)
    // act
    return new Promise((resolve, reject) => {
        bw.addTask(tq3, () => {
            bw.stop()
            try {
                // assert
                expect(r1_1).toBe(true)
                expect(bw.taskQueues.get(tq1).indexOf(run1_1)).toBe(-1)
                expect(r1_2).toBe(true)
                expect(bw.taskQueues.get(tq1).indexOf(run1_2)).toBe(-1)
                expect(r1_3).toBe(true)
                expect(bw.taskQueues.get(tq1).indexOf(run1_3)).toBe(-1)
                expect(r2_1).toBe(true)
                expect(bw.taskQueues.get(tq2).indexOf(run2_1)).toBe(-1)
                expect(r2_2).toBe(true)
                expect(bw.taskQueues.get(tq2).indexOf(run2_2)).toBe(-1)
                expect(r3_1).toBe(true)
                expect(bw.taskQueues.get(tq3).indexOf(run3_1)).toBe(-1)
                expect(r3_2).toBe(true)
                expect(bw.taskQueues.get(tq3).indexOf(run3_2)).toBe(-1)
                expect(r3_3).toBe(true)
                expect(bw.taskQueues.get(tq3).indexOf(run3_3)).toBe(-1)
                expect(r3_4).toBe(true)
                expect(bw.taskQueues.get(tq3).indexOf(run3_4)).toBe(-1)
                expect(bw.stats.tasksPerformed).toBe(9)
                expect(bw.stats.taskCyclesRun).toBe(4)
                expect(bw.stats.taskCyclesInitiated).toBe(5)
                expect(bw.stats.foundBusy).toBe(0)
                expect(strSequence).toBe('123456789')
                resolve()
            } catch(err) {
                reject(err)
            }                
        })
        bw.start()
    })
})