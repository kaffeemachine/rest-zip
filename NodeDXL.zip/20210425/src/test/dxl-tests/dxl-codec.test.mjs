/**
 * @jest-environment node
 */

import {
    beforeEach,
    expect,
    test,
} from '@jest/globals'
import {
    constants,
    encode,
    decode,
    extractCorrelationId,
    initializeCodec,
} from '../../dxl/dxl-codec.mjs'

beforeEach(() => {
    initializeCodec(false, 1, 'latin1')
})

test('encode and decode are inverse to each other', () => {
    let msg = {
        flags: 1,
        timeout: 900,
        ubsMsgType: 'asynchronousRequest',
        body: 'Hello, DXL listener!',
        requestId: 5042557362783369795,
        // requestId: 0x45fac334703bba43n,
    }
    let encoded = encode(0, msg)
    let decoded = decode(0, encoded)
    encoded = encode(0, decoded)
    decoded = decode(0, encoded)
    expect(decoded.magic).toBe('FYC ')
    expect(decoded.version).toBe(`${constants.versionMajor}.${constants.versionMinor}`)
    expect(decoded.ubsMsgType).toBe(msg.ubsMsgType)
    expect(decoded.flags).toBe(msg.flags)
    expect(decoded.timeout.toString()).toBe(msg.timeout.toString())
    expect(decoded.requestId.toString()).toBe(msg.requestId.toString())
    expect(decoded.msgBodyLength.toString()).toBe(msg.body.length.toString())
    expect(decoded.body).toBe(msg.body)    
})

test('extractCorrelationId finds numeric string as correlation ids', () => {
    let expected = '2398124953234'
    let msg = `<?xml version="1.0" encoding="ISO-8859-1"?><CorrelationIdResponsse Timestamp="SOME_TIMESTAMP" CorrelationId="${expected}"/>`
    let actual = extractCorrelationId(msg)
    expect(actual).toBe(expected)
})