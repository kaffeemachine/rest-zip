/**
 * @jest-environment node
 */

import {
    afterEach,
    beforeAll,
    beforeEach,
    describe,
    expect,
    test,
} from '@jest/globals'
import resetQueues from './dxl-test-queue-control.mjs'
import dxlTestCfg from './dxl-test-cfg.mjs'
import DxlBridge from '../../dxl/dxl-bridge.mjs'
import {
    DxlError,
    Severity,
} from '../../dxl/dxl-errors.mjs'
import {
     makeRandomDatagram,
     makeRandomRequest,
     PromisePlaceHolder,
 } from './dxl-test-helpers.mjs'
 import TestReceiver from './dxl-test-receiver.mjs'
 import TestResponder from './dxl-test-responder.mjs'

const {
    // DEBUG,
    bridgeCfg,
    bridgeCtl,
    byteConversionCharacteristics,
    testReceiverCfg,
    testResponderCfg,
} = dxlTestCfg
const DEBUG = true

bridgeCfg.DEBUG = false
bridgeCfg.balanceWheelInterval = 1
bridgeCfg.clientId = 1
bridgeCfg.correlationIdBase = 
    (bridgeCfg.clientId * bridgeCtl.correlationIdBlockSize) % bridgeCtl.maxReliableInt

let guard = null

function log(err) {
    console.error('*** BRIDGE ERROR: ***', err)
}

function logDbg(...args) {
    if (DEBUG) {
        console.log(...args)
    }
}

let dirtyStuff
beforeEach(() => {
    dirtyStuff = {}
    guard = new PromisePlaceHolder()
})
afterEach(resetQueues)
beforeAll(resetQueues)



async function cleanup() {
    clearTimeout(dirtyStuff.tm)
    try {
        await dirtyStuff.bridge.close()
        // eslint-disable-next-line no-empty
    } catch(err) { }
    await dirtyStuff.receiver?.stop()
    await dirtyStuff.responder?.stop()
    guard?.succeed()
}

const rgxResponse = new RegExp(`<\\?xml version="1.0" encoding="${byteConversionCharacteristics.isoEncoding}"\\?>` + 
    `<CorrelationIdResponse Timestamp="\\d+" CorrelationId="(\\d+)"\\/>`)
const rgxReply = new RegExp(`<\\?xml version="1.0" encoding="${byteConversionCharacteristics.isoEncoding}"\\?>[\\s\\S]*` +
    `<Reply ReplyCreationTimestamp="\\d+" [\\s\\S]* CorrelationId="(\\d+)"[\\s\\S]*<\\/Reply>`, 'g')

describe('initialization tests', () => {

    test('bridge creation without configuration data fails', () => {
        // arrange
        function createBridgeWithoutConfigurationData() {
            // act
            new DxlBridge()
        }
        // assert
        expect(createBridgeWithoutConfigurationData).toThrow(new DxlError('missing configuration data', 'DXL0001', Severity.error))
    })

    test('bridge is correctly configured after creation', () => {
        // arrange
        // act
        const bridge = new DxlBridge(bridgeCfg)
        // assert
        expect(bridge.stats.id).toBe(1)
        expect(bridge.correlationIdBase).toBe(bridgeCfg.correlationIdBase)
    })
    
    test('after call to prepareQueues(), all queue writers and readers are opened', async () => {
        // arrange
        const ms = 3000
        const bridge = new DxlBridge(bridgeCfg)
        dirtyStuff = {
            bridge,
        }
        let testPromise = new Promise((resolve, reject) => {
            bridge.on('queues_installed', () => {
                try {
                    expect(bridge.queues.syncQueueWriter.name === bridgeCfg.syncQueueName)
                    expect(bridge.queues.asyncWriter.name !== bridgeCfg.asyncRequestQueueName)
                    let prefix = bridgeCfg.dynamicQueueNamePrefix
                    prefix = prefix.substr(0, prefix.length - 1)
                    expect(bridge.queues.dynamicReplyQueueReader.name.startsWith(prefix)).toBe(true)
                    resolve()
                } catch(err) {
                    reject(err)
                } finally {
                    cleanup()
                }
            }).on('error', err => {
                cleanup()
                reject(err)
            })
            dirtyStuff.tm = setTimeout(async () => {
                cleanup()
                reject(new Error(`timeout of ${ms} ms reached before queues are opened`))            
            }, ms)
            // act
            bridge.prepareQueues().catch(reject).finally(cleanup)
        })
        return Promise.all([
            testPromise,
            guard.promise
        ])
    })
    
    test('after initializing, the bridge is ready', async () => {
        // arrange
        const ms = 3000
        const bridge = new DxlBridge(bridgeCfg)
        dirtyStuff.bridge = bridge
        bridge.on('error', log)
        let testPromise =  new Promise((resolve, reject) => {
            bridge.on('ready', async () => {
                await cleanup()
                resolve()
            })
            dirtyStuff.tm = setTimeout(async () => {
                await cleanup()
                reject(new Error(`timeout reached after ${ms} ms before queues are opened`))            
            }, ms)
            bridge.initialize().catch(async err => {
               await cleanup()
               reject(err)
            })
        })
        return Promise.all([
            testPromise,
            guard.promise,
        ])
    })
})

describe('message processing tests', () => {

    test('a posted datagram is received on the other side with its content preserved', async () => {
        // arrange
        const ms = 3000
        const bridge = new DxlBridge(bridgeCfg)
        const receiver = new TestReceiver()
        dirtyStuff = {
            bridge,
            receiver,
        }

        try {
            await new Promise((resolve, reject) => {
                bridge.on('ready', resolve).on('error', reject).
                initialize().catch(reject)
            })
            await new Promise((resolve, reject) => {
                receiver.on('ready', resolve).on('error', reject).
                start(testReceiverCfg).catch(reject)
            })
            bridge.removeAllListeners('ready').removeAllListeners('error')
            receiver.removeAllListeners('ready').removeAllListeners('error')

            const datagram = makeRandomDatagram()
            await new Promise((resolve, reject) => {
                bridge.on('error', reject)
                receiver.on('error', reject).
                on('data', data => {
                    try {
                        expect(data).toBe(datagram)
                        resolve()
                    } catch (err) {
                        reject(err)
                    }
                })
                dirtyStuff.tm = setTimeout(() => {
                    reject(new Error(`timeout reached after ${ms} ms before data is received on the other side`))
                }, ms)
                // act
                try {
                    bridge.write(datagram)
                } catch (err) {
                    reject(err)
                }
            })
        } finally {
            await Promise.all([
                cleanup(),
                guard.promise
            ])
        }
    })

    test('a posted request is received on the other side with its content preserved', async () => {
        // arrange
        const ms = 3000
        const bridge = new DxlBridge(bridgeCfg)
        const receiver = new TestReceiver()
        dirtyStuff = {
            bridge,
            receiver,
        }

        try {
            await new Promise((resolve, reject) => {
                bridge.on('ready', resolve).on('error', reject).
                initialize().catch(reject)
            })
            const cfg = {
                ...testReceiverCfg,
                syncQueueName: testResponderCfg.asyncRequestQueueName,
            }
            await new Promise((resolve, reject) => {
                receiver.on('ready', resolve).on('error', reject).
                start(cfg).catch(reject)
            })
            bridge.removeAllListeners('ready').removeAllListeners('error')
            receiver.removeAllListeners('ready').removeAllListeners('error')

            const request = makeRandomRequest()
            await new Promise((resolve, reject) => {
                bridge.on('error', reject)
                receiver.on('data', async data => {
                    // assert
                    try {
                        expect(data).toBe(request)
                        resolve()
                    } catch(err) {
                        reject(err)
                    }
                }).on('error', reject)
                dirtyStuff.tm = setTimeout(() => {
                    reject(new Error(`timeout of ${ms} ms reached before data is received on the other side`))            
                }, ms)
                try {
                    // act
                    bridge.write(request)
                } catch(err) {
                    reject
                }
            })
        } finally {
            await Promise.all([
                await cleanup(),
                guard.promise,
            ])
        }
    })

    test('for a posted request, a correlation id response is emitted', async () => {
        // arrange
        const ms = 3000
        const bridge = new DxlBridge(bridgeCfg)
        const receiver = new TestReceiver()
        dirtyStuff = {
            bridge,
            receiver,
        }
        try {
            await new Promise((resolve, reject) => {
                bridge.on('ready', resolve).on('error', reject).
                initialize().catch(reject)
            })
            const cfg = {
                ...testReceiverCfg,
                syncQueueName: testResponderCfg.asyncRequestQueueName,
            }
            await new Promise((resolve, reject) => {
                receiver.on('ready', resolve).on('error', reject).
                start(cfg).catch(reject)
            })
            bridge.removeAllListeners('ready').removeAllListeners('error')
            receiver.removeAllListeners('ready').removeAllListeners('error')

            const request = makeRandomRequest()
            await new Promise((resolve, reject) => {
                bridge.on('data', async data => {
                    // assert
                    try {
                        expect(data).toMatch(rgxResponse)
                        resolve()
                    } catch(err) {
                        reject(err)
                    }
                }).on('error', reject)
                dirtyStuff.tm = setTimeout(() => {
                    reject(new Error(`timeout reached after ${ms} ms before data is received on the other side`))            
                }, ms)
                try {
                    // act
                    bridge.write(request)
                } catch(err) {
                    reject(err)
                }
            })
        } finally {
            await Promise.all([
                await cleanup(),
                guard.promise,
            ])
        }
    })
    
    test('for a posted request, the correlation id emitted the bridge is the same as that unpacked on the other side', async () => {
        // arrange
        const ms = 3000
        const bridge = new DxlBridge(bridgeCfg)
        const receiver = new TestReceiver()
        dirtyStuff = {
            bridge,
            receiver,
        }
        try {
            await new Promise((resolve, reject) => {
                bridge.on('ready', resolve).on('error', reject).
                initialize().catch(reject)
            })
            const cfg = {
                ...testReceiverCfg,
                syncQueueName: testResponderCfg.asyncRequestQueueName,
            }
            await new Promise((resolve, reject) => {
                receiver.on('ready', resolve).on('error', reject).
                start(cfg).catch(reject)
            })
            bridge.removeAllListeners('ready').removeAllListeners('error')
            receiver.removeAllListeners('ready').removeAllListeners('error')

            const request = makeRandomRequest()
            let correlationId = false
            await new Promise((resolve, reject) => {
                async function evaluate(correlId) {
                    // assert
                    try {
                        expect(parseInt(correlId)).toBe(parseInt(correlationId))
                        resolve()
                    } catch(err) {
                        reject(err)
                    }
                }
                receiver.on('correlationId', async ci => {
                    if (!correlationId) {
                        correlationId = ci
                        return
                    }
                    // assert
                    await evaluate(ci)
                }).on('error', reject)
                bridge.on('data', async data => {
                    let matches = rgxResponse.exec(data)
                    if(!matches) {
                        reject(new Error(`no matches: data ${data} (${Date.now()})`))              
                    }
                    if (!correlationId) {
                        correlationId = matches?.[1]
                        return
                    }
                    // assert
                    await evaluate(matches?.[1])
                }).on('error', reject)
                dirtyStuff.tm = setTimeout(() => {
                    reject(new Error(`timeout reachhed after ${ms} ms reached data is received on the other side`))            
                }, ms)
                // act
                try {
                    bridge.write(request)
                } catch(err) {
                    reject(err)
                }
            })
        } finally {
            await Promise.all([
                await cleanup(),
                guard.promise,
            ])
        }
    })
    
    test('for a posted request, a reply message is obtained after sending a correlated poll request', async () => {
        // arrange
        const ms = 6000
        const bridge = new DxlBridge(bridgeCfg)
        const responder = new TestResponder()
        dirtyStuff = {
            bridge,
            responder,
        }
        try {
            await new Promise((resolve, reject) => {
                bridge.on('ready', resolve).on('error', reject).on('DEBUG', logDbg).
                initialize().catch(reject)
            })
            const cfg = {
                ...testResponderCfg,
                syncQueueName: testResponderCfg.asyncRequestQueueName,
                dynReplyQueueName: bridge.queues.dynamicReplyQueueReader.name,
            }
            await new Promise((resolve, reject) => {
                responder.on('ready', message => {
                    logDbg(message)
                    resolve()
                }).on('error', reject).
                on('request', logDbg).
                start(cfg).catch(err => reject({
                    location: 'RESP_1',
                    err,
                }))
            })
            bridge.removeAllListeners('ready').removeAllListeners('error')
            responder.removeAllListeners('ready').removeAllListeners('error')
            const request = makeRandomRequest()
            logDbg(`TEST: bridge waiting at dynamic queue ${bridge.queues.dynamicReplyQueueReader.name}`)
            await new Promise((resolve, reject) => {
                responder.on('DEBUG', message => {
                    logDbg(message)
                }).on('error', err => {
                    reject({
                        location: 'RESP_2',
                        err,
                    })
                })
                bridge.on('data', data => {
                    let matches = rgxResponse.exec(data)
                    const pollRequest = `<POLL_REQUEST CorrelationId="${matches?.[1]}"/>`
                    try {
                        logDbg(`TEST: about to write poll request ${pollRequest} to bridge (${Date.now()})`)
                        bridge.write(pollRequest)
                    } catch(err) {
                        reject({
                            location: 'BRID_1',
                            err,
                        })
                    }
                }).
                on('reply', () => {
                    logDbg(`TEST: [ASSERT] reply received (${Date.now()})`)
                    resolve()
                })
                dirtyStuff.tm = setTimeout(() => {
                    reject(new Error(`timeout of ${ms} ms reached before a reply is received (${Date.now()})`))            
                }, ms)
                // act
                try {
                    logDbg(`TEST: [ACT] about to write request (${Date.now()})`)
                    bridge.write(request)
                } catch(err) {
                    reject({
                        location: 'BRID_2',
                        err,
                    })
                }
            })
        } finally {
            await Promise.all([
                await cleanup(),
                guard.promise,
            ])
        }
    })

    test.skip('for requests sent each 10 ms we get all the correlated replies', async() => {
        // arrange
        const msgNum = 20
        const interval = 50
        const bridge = new DxlBridge(bridgeCfg)
        const responder = new TestResponder()
        let tmi
        let stopTimer
        const ms = 5000
        let msgsSent = 0
        let repliesReceived = 0
        let timeoutTask = new PromisePlaceHolder()
        let responderTask = new PromisePlaceHolder()
        let dataTask = new PromisePlaceHolder()
        let cleanupTask = new PromisePlaceHolder()
    
        responder.on('ready', () => {
            tmi = setInterval(() => {
                if (++msgsSent === msgNum) {
                    clearInterval(tmi)
                }
                // act
                bridge.write(makeRandomRequest())
            }, interval)
            const tm = setTimeout(() => {
                timeoutTask.fail(new Error(`timeout of ${ms} ms reached before all ${msgNum} replies were received\n` + 
                    `   BRIDGE requests received:  ${bridge.stats.requestsReceived}\n` +
                    `   BRIDGE correlation id replies sent: ${bridge.stats.correlationIdRepliesSent}\n` +
                    `   BRIDGE poll requests received:      ${bridge.stats.pollRequestsReceived}\n` +
                    `   REPONDER requests received:         ${responder.stats.requestsReceived}\n` +
                    `   RESPONDER replies sent:             ${responder.stats.repliesSent}\n` +
                    `   BRIDGE replies received:            ${bridge.stats.repliesRetrieved}\n` +
                    `   BRIDGE replies queued:              ${bridge.stats.bwStatistics.queues['reply'].tasksAdded}\n` +
                    `   BRIDGE replies processed:           ${bridge.stats.bwStatistics.queues['reply'].tasksPerformed}\n` +
                    `   BRIDGE task cycles initiated:       ${bridge.stats.bwStatistics.taskCyclesInitiated}\n` +
                    `   BRIDGE task cycles run:             ${bridge.stats.bwStatistics.taskCyclesRun}\n` +
                    `   (${Date.now()})`))            
            }, ms)
            stopTimer = () => {
                clearTimeout(tm)
                if (!timeoutTask.settled) {
                    timeoutTask.succeed()
                }
            }
        })
    
        bridge.on('ready', () => {
    // logDbg('bridge ready')
            const cfg = {
                ...testResponderCfg,
                syncQueueName: testResponderCfg.asyncRequestQueueName,
                dynReplyQueueName: bridge.queues.dynamicReplyQueueReader.name,
            }
            responder.start(cfg).
            then(() => responderTask.succeed()).
            catch(err => responderTask.fail(err))
        })
    
        bridge.on('data', data => {
            if (rgxResponse.test(data)) {
                let matches = rgxResponse.exec(data)
                const pollRequest = `<POLL_REQUEST CorrelationId="${matches?.[1]}"/>`
                bridge.write(pollRequest)
    // logDbg(`TEST: wrote poll request ${pollRequest} to bridge (${Date.now()})`)
                return
            }
            if (rgxReply.test(data)) {
                if (++repliesReceived === msgNum) {
                    try {
    logDbg(`open poll requests: ${bridge.openPollRequests.size}`)
    logDbg(`waiting replies: ${bridge.waitingReplies.size}`)
                        // assert
                        expect(bridge.openPollRequests.size).toBe(0)
                        expect(bridge.waitingReplies.size).toBe(0)
                        stopTimer?.call()
                        dataTask.succeed()
                    }
                    catch(err) {
                        dataTask.fail(err)
                    }
                }
            }
        })
    
        let testPromise = Promise.all([
            timeoutTask.promise,
            responderTask.promise,
            dataTask.promise,
            bridge.initialize()
        ]).finally(() => {
            stopTimer?.call()
            Promise.allSettled([
                responder.stop(),
                bridge.close(),
            ]).finally(() => cleanupTask.succeed())
        })
        return Promise.all([
            testPromise,
            cleanupTask.promise,
        ])
    })

})
