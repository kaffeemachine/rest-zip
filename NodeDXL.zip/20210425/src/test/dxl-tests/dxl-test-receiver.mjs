import {
    EventEmitter,
} from 'events'
import {
    Connection,
    provideConnection,
} from '../../main/imqo-connection.mjs'
import {
    initializeCodec,
    decode,
} from '../../dxl/dxl-codec.mjs'

class TestReceiver extends EventEmitter {
    qm
    readQueue
    startedAt = Date.now()
    constructor() {
        super()
    }
    async start(options) {
        const {
            DEBUG,
            endianess,
            encoding,
            queueManagerName,
            syncQueueName,
            waitForReplyDuration,
        } = options
        Connection.initialize(endianess, encoding)
        initializeCodec(DEBUG, endianess, encoding)
        this.qm = await provideConnection(queueManagerName)
        this.readQueue = await this.qm.createQueueReader(syncQueueName, {
            readExclusive: true,
        })
        this.readQueue.getMessage({
            wait: true,
            waitInterval: waitForReplyDuration, // wait up to n millis between while getting replies
        }, (err, result) =>  {
            if (err) {
                return this.emit('error', err)
            }
            let msg = decode('', result.data)
            this.emit('data', msg.body)
            const  correlationId = msg.requestId
            if (correlationId) {
                this.emit('correlationId', correlationId)
            }
        })
        this.emit('ready')
    }
    async stop() {
        this.readQueue?.getDone()
        if (this.readQueue?.isOpen) {
            await this.readQueue.close()
        }
        if (this.qm?.isOpen) {
            await this.qm.close()
        }
    }
}

export default TestReceiver