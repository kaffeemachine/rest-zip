import {
    EventEmitter,
} from 'events'
import {
    Connection,
    provideConnection,
} from '../../main/imqo-connection.mjs'
import {
    initializeCodec,
    encode,
    decode,
} from '../../dxl/dxl-codec.mjs'
import {
    makeReply,
} from './dxl-test-helpers.mjs'
import assert from 'assert/strict'

class TestResponder extends EventEmitter {
    qm
    readQueue
    startedAt = Date.now()
    stats = {
        requestsReceived: 0,
        repliesSent: 0,
    }
    constructor() {
        super()
    }
    async start(options) {
        const {
            DEBUG,
            endianess,
            encoding,
            queueManagerName,
            asyncRequestQueueName,
            dynReplyQueueName,
            waitForReplyDuration,
        } = options
        Connection.initialize(endianess, encoding)
        initializeCodec(DEBUG, endianess, encoding)
        this.qm = await provideConnection(queueManagerName)
        this.readQueue = await this.qm.createQueueReader(asyncRequestQueueName, {
            readExclusive: true,
        })
        this.dynamicQueueWriter = await this.qm.createQueueWriter(dynReplyQueueName)
        this.readQueue.getMessage({
            wait: true,
            waitInterval: waitForReplyDuration, // wait up to n millis between while getting replies
        }, (err, result) =>  {
            if (err) {
                return this.emit('error', err)
            }
            assert(this.dynamicQueueWriter.name.localeCompare(result.replyQueueName) === 0)
            this.emit('DEBUG', `RESPONDER: got request for correlation id ${parseInt(result.correlationId)} (${Date.now()})`)
            this.stats.requestsReceived++
            let msg = decode(-1, result.contentBuffer)
            // this.emit('DEBUG', `RESPONDER: correlation Id: ${msg.requestId}, queue: ${result.replyQueueName}, queue manager: ${result.replyQueueManagerName}`)
            const reply = makeReply(msg.body, msg.requestId, result.replyQueueName, result.replyQueueManagerName, encoding)
            const binReply = encode(-1, reply)
            this.emit('DEBUG', `RESPONDER: about to put reply onto queue ${result.replyQueueName} (${Date.now()})`)
            this.dynamicQueueWriter.putMessage(binReply, {
                correlationId: msg.requestId,
                msgId: msg.requestId,
                msgType: 'REPLY',
            }, err => {
                if (err) {
                    this.emit('error', `RESPONDER: got error while writing to queue ${this.dynamicQueueWriter.name} ` +
                        `(${Date.now()}):\n${err}`)
                } else {
                    this.emit('DEBUG', `RESPONDER: put reply onto queue ${this.dynamicQueueWriter.name} (${Date.now()})`)
                }
            }, endianess)
            this.stats.repliesSent++
        })
        this.emit('ready', `RESPONDER: will write to queue ${this.dynamicQueueWriter.name}`)
    }
    async stop() {
        try {
            this.dynamicQueueWriter?.getDone()
            if (this.dynamicQueueWriter?.isOpen) {
                await this.dynamicQueueWriter.close()
            }
            this.readQueue?.getDone()
            if (this.readQueue?.isOpen) {
                await this.readQueue.close()
            }
            if (this.qm?.isOpen) {
                await this.qm.close()
            }
        // eslint-disable-next-line no-empty
        } catch(err) {}
    }
}

export default TestResponder