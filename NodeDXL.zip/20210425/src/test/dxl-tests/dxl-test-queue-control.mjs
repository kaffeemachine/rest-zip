import dxlTestCfg from './dxl-test-cfg.mjs'
import { URL } from 'url'
import path from 'path'
import fs from 'fs-extra'
import process from 'process'
import { execSync } from 'child_process'

const {
    permanentQueues,
    mqInstallation,
    byteConversionCharacteristics,
} = dxlTestCfg

function resetQueues() {
    let runDir = decodeURI(new URL(import.meta.url).pathname)
    if (process.platform === 'win32') {
        runDir = runDir.substr(1)
    }
    runDir = path.dirname(runDir)

    let fileName = path.join(runDir, 'queueCtl.txt')
    let cmdStr = `CLEAR QLOCAL (${permanentQueues.asyncRequestQueueName})
    CLEAR QLOCAL (${permanentQueues.syncQueueName})
    end
    `
    fs.writeFileSync(fileName, cmdStr, { encoding: byteConversionCharacteristics.encoding,})

    const exePath = path.join(mqInstallation, 'bin64', 'runmqsc.exe')
    try {
        execSync(`"${exePath}" ${permanentQueues.queueManagerName} < "${fileName}"`)
    } catch(err) {
        // console.log('**** QUEUE CONTROL ERROR - QUEUE RESET SCRIPT FAILED ****',
        // `"${exePath}" ${permanentQueues.queueManagerName} < "${fileName}"`) 
        // err.output.forEach(buf => {
        //     if (buf) {
        //         console.log(buf?.toString())
        //     }
        // })
    }
}

export default resetQueues
