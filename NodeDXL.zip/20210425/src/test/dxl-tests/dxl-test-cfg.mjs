import dxlCfg from '../../dxl-cfg.mjs'

const mqInstallation = 'C:\\Program Files\\IBM\\MQ_1'

const {
    queueManagerName,
    asyncRequestQueueName,
    syncQueueName,
} = dxlCfg.permanentQueues

const testResponderCfg = {
    ...dxlCfg.byteConversionCharacteristics,
    queueManagerName,
    asyncRequestQueueName,
    waitForReplyDuration: dxlCfg.bridgeCfg.waitForReplyDuration,
}

const testReceiverCfg = {
    ...dxlCfg.byteConversionCharacteristics,
    queueManagerName,
    syncQueueName,
    waitForReplyDuration: dxlCfg.bridgeCfg.waitForReplyDuration,
}

const dxlTestCfg = {
    ...dxlCfg,
    testReceiverCfg,
    testResponderCfg,
    mqInstallation,
}

export default dxlTestCfg
