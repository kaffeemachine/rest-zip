import process from 'process'
import {
    maxReliableInt
} from './main/imqo-constants.mjs'
// const maxReliableInt =  1240000000000000

function paramFromArgV(name) {
    for (let v of process.argv) {
        let parm = v.toUpperCase()
        if (parm.startsWith(name.toUpperCase())) {
            return parm
        }
    }
    return false
}

// *** set to false to suppress diagnostic output: ***
const DEFAULT_DEBUG = false
const DEBUG = paramFromArgV('DEBUG') || !!process.env['DEBUG'] || DEFAULT_DEBUG // switch for debug messages

const host = 'PEGASUS'
let runtimePort = parseInt((paramFromArgV('DXL_PORT') || process.env['DXL_PORT'])?.split('=')[1])
const port = runtimePort || 28080

const queueManagerName = 'QM_PEGASUS'
const asyncReplyQueueModel = 'FYX00.FYC00.LF000.FYC.R.DXL.ASYNC.MODEL'
const asyncRequestQueueName = 'FYC00.FYC00.LF000.FYC.Q.DXL.ASYNC'
const syncQueueName = 'FYC00.FYC00.LF000.FYC.DXL.SYNC'
const dynamicQueueNamePrefix = 'FYX00.FYC00.LF000.FYC.R.DXL.DYN*' // MAXLEN: 32 chars

const permanentQueues = {
    queueManagerName,
    asyncRequestQueueName,
    syncQueueName,
}

const byteConversionCharacteristics = {
    isoEncoding: 'ISO-8859-1',
    encoding: 'latin1',   // the same as above in node speak
    endianess: 1, // little endian (for binary conversions)
}

const statisticsTimerInterval = 60 * 1000 // frequency: every n ms

const EOM = '\x00'  // end of message
const messageSeparator = EOM
const maxSizeSplitBuf = 2 ** 28 // maximum buffer length for message stream splitting
const connectionLifespan = 20 * 60 * 1000 // ms after which quiescing message is sent by the server
const quiesceMessage = `<?xml version="1.0" ` +
    `encoding="${byteConversionCharacteristics.isoEncoding}"?>` +
    `<CN_QUIESCE/>${messageSeparator}`

const commCtl = {
    messageSeparator,
    maxSizeSplitBuf,
    connectionLifespan,
    quiesceMessage,
}

const balanceWheelInterval = 3
const waitForReplyDuration = 3 * 60 * 1000

const bridgeCfg = {
    DEBUG,
    ...byteConversionCharacteristics,
    ...permanentQueues,
    asyncReplyQueueModel,
    dynamicQueueNamePrefix, // MAXLEN: 32 chars
    balanceWheelInterval,
    waitForReplyDuration,
}

const correlationIdBlockSize = 2 * connectionLifespan

const bridgeCtl = {
    runInProcess: false,
    forwardSocketToChild: false,
    correlationIdBlockSize,
    maxReliableInt,
    statisticsTimerInterval,
}

const listenerCfg = {
    host,
    port,
    encoding: byteConversionCharacteristics.encoding,
}
   
const dxlCfg = {
    DEBUG,
    byteConversionCharacteristics,
    bridgeCfg,
    bridgeCtl,
    commCtl,
    listenerCfg,
    permanentQueues,
}

export default dxlCfg
