const maxReliableInt = 1240000000000000
const numberEncoding = 'latin1'

export {
    maxReliableInt,
    numberEncoding,
}