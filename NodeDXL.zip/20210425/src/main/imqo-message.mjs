import { MQC as _MQC, Put1, MQOD } from 'ibmmq'
import {
    MqError,
    InvalidOperationError,
    ArgumentError
} from './imqo-errors.mjs'
const MQC = _MQC
import {
    checkPutOptions,
    evaluatePutOptions,
} from './imqo-queue-helpers.mjs'
import { numberEncoding } from './imqo-constants.mjs'

function noop() {}

function mqMsgType2String(type) {
    let msgStr
    switch (type) {
        case MQC.MQMT_REQUEST:
            msgStr = 'REQUEST'
            break
        case MQC.MQMT_REPLY:
            msgStr = 'REPLY'
            break
        case MQC.MQMT_REPORT:
            msgStr = 'REPORT'
            break
        case MQC.MQMT_DATAGRAM:
            msgStr = 'DATAGRAM'
            break
        default:
            msgStr = `unknown value ${type}`
            break;
    }
    return msgStr
}

class Message {
    cn
    mqmd
    data
    encoding = Message.encoding || 'utf8'
    endianess = (Message.endianess === 0)? 0 : 1
    
    static initialize(endianess, encoding) {
        Message.endianess = (endianess === 0)? 0 : 1
        Message.encoding = encoding || 'utf8'
    }

    static defaultEncoding = 'utf8'
    constructor(cn, mqmd, data, encoding) {
        this.cn = cn
        this.mqmd = mqmd
        this.data = data
        this.encoding = encoding || Message.encoding
    }

    get contentBuffer() {
        if (typeof this.data === 'string') {
            // eslint-disable-next-line no-undef
            return Buffer.from(this.data, this.encoding)
        }
        return this.data
    }
    get contentString() {
        // eslint-disable-next-line no-undef
        if (this.data instanceof Buffer) {
            return this.data.toString(this.encoding)
        }
        return this.data
    }
    get content() {
        return this.data
    }
    get type() {
        return this.mqmd.MsgType
    }
    get typeStr() {
        return mqMsgType2String(this.mqmd.MsgType)
    }
    get correlationId() {
        // eslint-disable-next-line no-undef
        return (this.mqmd.CorrelId instanceof Buffer)?
            this.mqmd.CorrelId :
            // eslint-disable-next-line no-undef
            Buffer.from(this.mqmd.CorrelId, numberEncoding)
    }
    get msgId() {
        // eslint-disable-next-line no-undef
        return (this.mqmd.MsgId instanceof Buffer)?
            this.mqmd.MsgId :
            // eslint-disable-next-line no-undef
            Buffer.from(this.mqmd.MsgId, numberEncoding)
    }
    get replyQueueName() {
        return this.mqmd.ReplyToQ
    }
    get replyQueueManagerName() {
        return this.mqmd.ReplyToQMgr
    }

    async putReplyAsync(data, options = {}) {
        return new Promise((resolve, reject) => {
            this.putReply(data, options, (err, result) => {
                if (err) {
                    return reject(err)
                }
                resolve(result)
            })
        })
    }

    putReply(data, options = {}, cb) {
        const verb = 'PUT1'
        if (this.mqmd.MsgType !== MQC.MQMT_REQUEST) {
            throw new InvalidOperationError('only requests may put a reply', 'IMQO0104', options, verb)
        }
        options.msgType= 'REPLY'
        options.failIfQuiescing = true
        if (this.correlationId) {
            options.correlationId = options.correlationId || this.correlationId
        }
        checkPutOptions(options, data, verb)
        const { mqmd, mqpmo } = evaluatePutOptions(options, this.replyQManagerName, this.endianess, this.encoding, verb)
        const mqod = new MQOD()
        mqod.ObjectQMgrName = this.mqmd.ReplyToQMgr
        mqod.ObjectName = this.mqmd.ReplyToQ
        try {
            if (this.cn.isClosed) {
                throw new InvalidOperationError('connection closed', 'IMQO0101', options, verb)
            }       
            Put1(this.cn.hCn, mqod, mqmd, mqpmo, data, err => {
                if (err) {
                    return cb(new MqError(err.message, err, mqod.ObjectName, 'IMQO0063', options, verb))
                }
                const result = {}
                if (mqmd.MsgId) {
                    result.msgId = mqmd.MsgId
                }
                if (mqmd.CorrelId) {
                    result.correlationId = mqmd.CorrelId
                }
                cb(null, result)
            })
        } catch(err) {
            try {
                if (err instanceof ArgumentError) {
                    return cb(err)
                }
                return cb(new MqError(err.message, err, mqod.ObjectName, 'IMQO0064', options, verb))
            } catch (err) {
                noop()
            }
        }
    }

    // get isSegmented() {
    //     return false
    // }
    // get hasMoreSegments() {
    //     const verb = 'GET'
    //     throw new NotImplementedError('property hasMoreSegments not yet implemented', null, verb)
    // }
    // get fullyRetrieved() {
    //     const verb = 'GET'
    //     throw new NotImplementedError('property fullyRetrieved not yet implemented', null, verb)
    // }
    // get fullContent() {
    //     const verb = 'GET'
    //     throw new NotImplementedError('property fullContent not yet implemented', null, verb)
    // }
    // get fullContentString() {
    //     const verb = 'GET'
    //     throw new NotImplementedError('property fullContentString not yet implemented', null, verb)
    // }
    // get segments() {
    //     const verb = 'GET'
    //     throw new NotImplementedError('property segments not yet implemented', options, verb)
    // }
    // getNextSegment(options = {}) {
    //     const verb = 'GET'
    //     throw new NotImplementedError('method nextSegment not yet implemented', options, verb)
    // }
    // get isInGroup() {
    //     return false
    // }
    // get isLastMessageInGroup() {
    //     const verb = 'GET'
    //     throw new NotImplementedError('property isLastMessageInGroup not yet implemented', options, verb)
    // }
    // getNextMessageInGroup(options = {}) {
    //     const verb = 'GET'
    //     throw new NotImplementedError('method getNextMessageInGroup not yet implemented', options, verb)
    // }
    // getAllMessagesInGroup(options = {}) {
    //     const verb = 'GET'
    //     throw new NotImplementedError('method getAllMessagesInGroup not yet implemented', options, verb)
    // }
}

export default Message
