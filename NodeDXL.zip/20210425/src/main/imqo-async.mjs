/**
 * provide all those ibmmq functions in an async version
 * 
 * remark: hObj usually stands for a connection or a queue handle
 */

 import {
    // Back as Back$,
    // Begin as Begin$,
    // Cmit as Cmit$,
    // CrtMh as CrtMh$,
    // DltMh as DltMh$,
    // DltMp as DltMp$,
    Get as Get$,
    GetDone as GetDone$,
    // Inq as Inq$,
    // InqMp as InqMp$,
    // Set as Set$,
    // Stat as Stat$,
    // Subrq as Subrq$,
    // ClosePromise,
    // ConnPromise,
    ConnxPromise,
    DiscPromise,
    OpenPromise,
    PutPromise,
    Put1Promise,
    // SubPromise,
} from 'ibmmq'

 import { promisify } from 'util'

 const pms = {
    // BackPromise: promisify(Back$),
    // BeginPromise: promisify(Begin$),
    GetDonePromise: promisify(GetDone$),
    // CmitPromise: promisify(Cmit$),
    // CrtMhPromise: promisify(CrtMh$),
    // DltMhPromise: promisify(DltMh$),
    // DltMpPromise: promisify(DltMp$),
    GetPromise: promisify(Get$),
//     InqPromise: promisify(Inq$),
//     InqMpPromise: promisify(InqMp$),
//     SetPromise: promisify(Set$),
//     StatPromise: promisify(Stat$),
//     SubrqPromise: promisify(Subrq$),
}

const mqa = {
    // async Back(hCn) {
    //     return pms.BackPromise(hCn)
    // },
    // async Begin(hCn) {
    //     return pms.BeginPromise(hCn)
    // },
    async CancelGet(hObj) {
        return pms.GetDonePromise(hObj)
    },
    // async Close(hCn) {
    //     return ClosePromise(hCn)
    // },
    // async Cmit(hCn) {
    //     return pms.CmitPromise(hCn)
    // },
    // async Conn(managerName) {
    //     return ConnPromise(managerName)
    // },
    async Connx(managerName, options) {
        return ConnxPromise(managerName, options)
    },
    // async CrtMh(options) {
    //     return pms.CrtMhPromise(options)
    // },
    async Disc(hCn) {
        return DiscPromise(hCn)
    },
    // async DltMh(hMsg, options) {
    //     return pms.DltMhPromise(hMsg, options)
    // },
    // async DltMp(hMsg, options, propertyName) {
    //     return pms.DltMpPromise(hMsg, options, propertyName)
    // },
    async Get(hObj, messageDescriptor, options) {
        return pms.GetPromise(hObj, messageDescriptor, options)
    },
    async GetDone(hObj) {
        return pms.GetDonePromise(hObj)
    },
    // async Inq(hObj, selectors) {
    //     return pms.InqPromise(hObj, selectors)
    // },
    // async InqMp(hCn, hMsg, options, property, propertyName) {
    //     return pms.InqMpPromise(hCn, hMsg, options, property, propertyName)
    // },
    async Open(hCn, objectDescriptor, openOptions) {
        return OpenPromise(hCn, objectDescriptor, openOptions)
    },
    async Put(hObj, msgDescriptor, options, data) {
        return PutPromise(hObj, msgDescriptor, options, data)
    },
    async Put1(hCn, hQu, msgDescriptor, options, data) {
        return Put1Promise(hCn, hQu, msgDescriptor, options, data)
    },
    // async Set(hQu, selectors) {
    //     return pms.SetPromise(hQu, selectors)
    // },
    // async Stat(hCn, type) {
    //     return pms.StatPromise(hCn, type)
    // },
    // async Sub(hCn, hQu, Subscription) {
    //     return SubPromise(hCn, hQu, Subscription)
    // },
    // async Subrq(hCn, hSub, action, options) {
    //     return pms.SubrqPromise(hCn, hSub, action, options)
    // },  
}
// export async function Back(hCn) {
//     return pms.BackPromise(hCn)
// }
// export async function Begin(hCn) {
//     return pms.BeginPromise(hCn)
// }
export async function CancelGet(hObj) {
    return pms.GetDonePromise(hObj)
}
// export async function Close(hCn) {
//     return ClosePromise(hCn)
// }
// export async function Cmit(hCn) {
//     return pms.CmitPromise(hCn)
// }
// export async function Conn(managerName) {
//     return ConnPromise(managerName)
// }
export async function Connx(managerName, options) {
    return ConnxPromise(managerName, options)
}
// export async function CrtMh(options) {
//     return pms.CrtMhPromise(options)
// }
export async function Disc(hCn) {
    return DiscPromise(hCn)
}
// export async function DltMh(hMsg, options) {
//     return pms.DltMhPromise(hMsg, options)
// }
// export async function DltMp(hMsg, options, propertyName) {
//     return pms.DltMpPromise(hMsg, options, propertyName)
// }
export async function Get(hObj, messageDescriptor, options) {
    return pms.GetPromise(hObj, messageDescriptor, options)
}
export async function GetDone(hObj) {
    return pms.GetDonePromise(hObj)
}
// export async function Inq(hObj, selectors) {
//     return pms.InqPromise(hObj, selectors)
// }
// export async function InqMp(hCn, hMsg, options, property, propertyName) {
//     return pms.InqMpPromise(hCn, hMsg, options, property, propertyName)
// }
export async function Open(hCn, objectDescriptor, openOptions) {
    return OpenPromise(hCn, objectDescriptor, openOptions)
}
export async function Put(hObj, msgDescriptor, options, data) {
    return PutPromise(hObj, msgDescriptor, options, data)
}
export async function Put1(hCn, hQu, msgDescriptor, options, data) {
    return Put1Promise(hCn, hQu, msgDescriptor, options, data)
}
// export async function Set(hQu, selectors) {
//     return pms.SetPromise(hQu, selectors)
// }
// export async function Stat(hCn, type) {
//     return pms.StatPromise(hCn, type)
// }
// export async function Sub(hCn, hQu, Subscription) {
//     return SubPromise(hCn, hQu, Subscription)
// }
// export async function Subrq(hCn, hSub, action, options) {
//     return pms.SubrqPromise(hCn, hSub, action, options)
// }
export default mqa
