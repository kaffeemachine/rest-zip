

class ArgumentError extends Error {
    code
    options
    verb
    severity
    constructor(message, code, options, verb, severity) {
        super(message)
        this.code = code
        this.options = options
        this.verb = verb
        this.severity = severity
    }
}

class InvalidOperationError extends Error {
    code
    options
    verb
    severity
    constructor(message, code, options, verb, severity) {
        super(message)
        this.code = code
        this.options = options
        this.verb = verb
        this.severity = severity
    }
}

class MqError extends Error {
    mqObjectName
    mqcc
    mqccstr
    mqrc
    mqrcstr
    version
    options
    verb
    code
    severity
    constructor(message, mqError, mqObjectName, code, options, verb, severity) {
        super(message || mqError.message)
        this.name = 'MqErrror'
        this.mqObjectName = mqObjectName
        this.mqcc = mqError.mqcc
        this.mqccstr = mqError.mqccstr
        this.mqrc = mqError.mqrc
        this.mqrcstr = mqError.mqrcstr
        this.stack = mqError.stack
        this.version = mqError.version
        this.options = options
        this.verb = mqError.verb || verb
        this.code = code
        this.severity = severity
    }
}

class NotFoundError extends Error {
    code
    options
    verb
    severity
    constructor(message, code, options, verb, severity) {
        super(message)
        this.code = code
        this.options = options
        this.verb = verb
        this.severity = severity
    }
    code
}

class NotImplementedError extends Error {
    code
    options
    verb
    severity
    constructor(message, code, options, verb, severity) {
        super(message)
        this.code = code
        this.options = options
        this.verb = verb
        this.severity = severity
    }
    code
}

class Info {
    #message
    #verb
    constructor(message, verb) {
        this.#message = message
        this.#verb = verb
    }
    get message() {
        return this.#message
    }
    get verb() {
        return this.#verb
    }
}

class Warning {
    #code
    #message
    #verb
    constructor(message, code, verb) {
        this.#code = code
        this.#message = message
        this.#verb = verb
    }
    get code() {
        return this.#code
    }
    get message() {
        return this.#message
    }
    get verb() {
        return this.#verb
    }
}

export {
    ArgumentError,
    InvalidOperationError,
    MqError,
    NotFoundError,
    NotImplementedError,
    Info,
    Warning,
}