import { strict as assert } from 'assert'
import Message from './imqo-message.mjs'
import {
    ArgumentError,
    InvalidOperationError,
    MqError,
    NotFoundError,
    Warning,
} from './imqo-errors.mjs'
import {
    MQC,
    Get,
    Put,
    Open,
    Close,
    MQOD,
    MQMD,
    MQPMO,
    GetDone,
} from 'ibmmq'

import {
    checkGetOptions,
    checkPutOptions,
    evaluatePutOptions,
    evaluateGetOptions,
    numberToBuffer,
} from './imqo-queue-helpers.mjs'
// import { logErr } from '../demo/dxl-diagnostics.mjs'


    /**
     * MQ OPEN OPTIONS
     * 
     * MQOO_ALTERNATE_USER_AUTHORITY  :4096
     * MQOO_BIND_AS_Q_DEF             :0
     * MQOO_BIND_NOT_FIXED            :32768
     * MQOO_BIND_ON_GROUP             :4194304
     * MQOO_BIND_ON_OPEN              :16384
     * MQOO_BROWSE                    :8
     * MQOO_CO_OP                     :131072
     * MQOO_FAIL_IF_QUIESCING         :8192
     * MQOO_INPUT_AS_Q_DEF            :1
     * MQOO_INPUT_EXCLUSIVE           :4
     * MQOO_INPUT_SHARED              :2
     * MQOO_INQUIRE                   :32
     * MQOO_NO_MULTICAST              :2097152
     * MQOO_NO_READ_AHEAD             :524288
     * MQOO_OUTPUT                    :16
     * MQOO_PASS_ALL_CONTEXT          :512
     * MQOO_PASS_IDENTITY_CONTEXT     :256
     * MQOO_READ_AHEAD                :1048576
     * MQOO_READ_AHEAD_AS_Q_DEF       :0
     * MQOO_RESOLVE_LOCAL_Q           :262144
     * MQOO_RESOLVE_LOCAL_TOPIC       :262144
     * MQOO_RESOLVE_NAMES             :65536
     * MQOO_SAVE_ALL_CONTEXT          :128
     * MQOO_SET                       :64
     * MQOO_SET_ALL_CONTEXT           :2048
     * MQOO_SET_IDENTITY_CONTEXT      :1024
     */

     
function noop() {}

let Connection
class Queue {
    #cn     // connection
    #hCn    // connection handle
    #hQu =  MQC.MQHO_UNUSABLE_HOBJ    // queue handle
    #name   // name of queue

    static initialize(endianess, encoding, connectionClass) {
        Message.endianess = endianess
        Message.encoding = encoding
        Connection = connectionClass
    }
    
    constructor(connection, name) {
        const verb = 'CREATE_QUEUE_WRAPPER'
        if(!name || typeof name !== 'string') {
            throw new ArgumentError('no queue name specified', 'IMQO0009', null, verb)
        }
        if (!connection || !(connection instanceof Connection)) {
            throw new ArgumentError('no valid connection object', 'IMQO0010', null, verb)
        }
        if (!connection || connection.isClosed) {
            throw new InvalidOperationError('connection closed', 'IMQO0011', null, verb)
        }
        this.#cn = connection
        this.#hCn = connection.hCn
        this.#name = name
    }

    get endianess() {
        return Message.endianess
    }

    get encoding() {
        return Message.encoding
    }
     
    get name() {
        return this.#name
    }

    get cn() {
        return this.#cn
    }

    get hCn() {
        return this.#hCn
    }

    get isOpen() {
        return !this.isClosed
    }

    get isClosed() {
        return !this.#hQu || this.#hQu === MQC.MQHO_UNUSABLE_HOBJ
    }

    async open(options = { }) {
        return new Promise((resolve, reject) => {
            if (this.isOpen) {
                return this
            }
            options = {
                failIfQuiescing: true,
                ...options,
            }
            let opts = 0
            opts += options.failIfQuiescing? MQC.MQOO_FAIL_IF_QUIESCING : 0
            opts += options.write? MQC.MQOO_OUTPUT : 0
            opts += options.read? MQC.MQOO_INPUT_AS_Q_DEF : 0
            opts += options.readExclusive? MQC.MQOO_INPUT_EXCLUSIVE : 0
            let od = new MQOD()
            od.ObjectQMgrName = this.hCn._name
            if (options.dynamic) {
                od.ObjectName = options.modelQueueName
                od.DynamicQName = this.#name
            } else {
                od.ObjectName = this.name
            }
            od.ObjectType = MQC.MQOT_Q
            if (this.cn.isClosed) {
                return
            }
            Open(this.hCn, od, opts, (err, hQu) => {
                const verb = 'OPEN'
                if (err) {
                    let message = err.message
                    if (err.name === 'MQError') {
                        if (err.mqrc === MQC.MQRC_UNKNOWN_OBJECT_NAME) {
                            if (options.dynamic) {
                                message = `invalid model queue '${options.modelQueueName}' (${err.message})`
                                return reject(new ArgumentError(message, 'IMQO0012', options, verb))
                            }
                            else {
                               message = `invalid queue name '${this.#name}' (${err.message})` 
                               return reject(new ArgumentError(message, 'IMQO0013', options, verb))
                            }
                        } else if (err.mqrc === MQC.MQRC_DYNAMIC_Q_NAME_ERROR) {
                            message =`invalid dyn queue name '${this.#name}' (${err.message})`
                            return reject(new ArgumentError(message, 'IMQO0014', options, verb))
                        }
                    }
                    return reject(new MqError(message, err, this.name, 'IMQO0050', options, verb))
                }
                this.#hQu = hQu
                this.#name = hQu._name
                resolve(this)
            })
        })
    }

    /**
     * close the queue
     */
    async close() {
        return new Promise((resolve, reject) => {
            const verb = 'CLOSE'
            if (this.cn.isClosed) {
                return reject(new InvalidOperationError('connection closed', 'IMQO0101', undefined, verb))
            }
            if (this.isClosed) {
                return reject(new InvalidOperationError(`queue ${this.#name} not open`, 'IMQO0102', undefined, verb))
            }
            let closeOption = MQC.MQCO_NONE
            Close(this.#hQu, closeOption, (err, hQu) => {
                if (err) {
                    return reject(new MqError(err.message, err, this.name, 'IMQO0051', undefined, verb))
                }
                this.#hQu = hQu
                resolve(hQu)
            })
        })
    }

    /**
     * put a message onto the queue
     * @param data { Buffer | String } payload
     * @param options { Object? } holds options for put operation
     * @param cb { function (err, info ) : void } fulfillment handler
     */
    putMessage(data, options = {}, cb, endianess, encoding) {
        const verb = 'PUT'
        endianess = (endianess === 0)? 0 : this.endianess
        encoding = encoding || this.encoding
        if (!cb) {
            // programming error
            throw new ArgumentError('callback missing', 'IMQO0015', options, verb)
        }
        if (typeof cb !== 'function') {
             // programming error
             throw new ArgumentError('callback must be a function', 'IMQO0016', options, verb)
        }
        try {
            checkPutOptions(options, data)
            const { mqmd, mqpmo } = evaluatePutOptions(options, this.#hCn._name, endianess, encoding)
            assert(mqmd instanceof MQMD, 'no MQMD returned')
            assert(mqpmo instanceof MQPMO, 'no MQPMO returned')
            if (this.#cn.isClosed || this.isClosed) {
                return
            }
            Put(this.#hQu, mqmd, mqpmo, data, err => {
                if (err && this.cn.isOpen) {
// console.log('====================================================================================')
// console.log('IMQO0052', err)
// console.log(new MqError(err.message, err, this.name, 'IMQO0052', options, verb))
// console.log('====================================================================================')
                    return cb(new MqError(err.message, err, this.name, 'IMQO0052', options, verb))
                }
                const result = { verb, data, options, }
                if (mqmd.MsgId) {
                    result.msgId = numberToBuffer(mqmd.MsgId)
                }
                if (mqmd.CorrelId) {
                    result.correlationId = numberToBuffer(mqmd.CorrelId)
                }
                try {
                    if (this.cn.isOpen) {
                        cb(null, result)
                    }
                } catch(err) { noop() }
            })
        } catch(err) {
            try {
                if (this.cn.isOpen) {
                    cb(err)
                }
            } catch(err) { noop() }
        }
    }

    /**
     * put a message onto this queue
     * @param data { Buffer | String } payload
     * @param options { Object }  holds options for put operation
     */
    async putMessageAsync(data, options = {}, endianess, encoding) {
        return new Promise((resolve, reject) => {
            try {
                this.putMessage(data, options, (err, result) => {
                    if (err) {
                        return reject(err)
                    }
                    return resolve(result)
                }, endianess, encoding)
            } catch(err) {
                reject(err)
            }
        })
    }

    /**
     * get a message from this queue
     * @param options properties specify how the get operation should be performed
     * @param cb { (err, result) => void } fulfillment event handler
     * @param verb { string? } passthrough parameter when called from poll method
     */
    getMessage(options = {}, cb, encoding) {
        const verb = 'GET'
        encoding = encoding || this.encoding
        if (!cb) {
            // programming error
            throw new ArgumentError('callback missing', 'IMQO0015', options, verb)
        }
        if (typeof cb !== 'function') {
            // programming error
            throw new ArgumentError('callback must be a function', 'IMQO0016', options, verb)
        }
        try {
            checkGetOptions(options, verb)
            if (this.#cn.isClosed || this.isClosed) { // return silently
                return
            }
            let { mqmd, mqgmo } = evaluateGetOptions(options, this.endianess, encoding)
            Get(this.#hQu, mqmd, mqgmo, (err, hObj, gmo, md, buf) => {
                if (err) {
                    if (err.mqrc === MQC.MQRC_NO_MSG_AVAILABLE) {
                        const mqErr = new MqError(err.message, err, this.name, 'IMQO0100',  options, verb)
                        try {
                            if (this.cn.isOpen) {
                                return cb(mqErr)
                            }
                        } catch(err) { 
                            return
                        }
// console.log('QUEUE.getMessage()', err.mqrc, err)
                        try {
                            if (this.cn.isOpen) {
                                return cb(null, new Warning('not found', 100, verb))
                            }
                        } catch(err) {
                            return
                        }
                    }
                    try {
                        if (this.cn.isOpen) {
                            return cb(new MqError(err.message, err, this.name, 'IMQO0053',  options, verb))
                        }
                    } catch(err) { 
                        return
                     }
                }
                try {
                    if (this.cn.isOpen) {
// console.log(`Queue ${this.name} getMessage(): got one! (${Date.now()})`)
                        // eslint-disable-next-line no-undef
                        cb(null, new Message(this.cn, md, Buffer.from(buf), encoding))
                    }
                } catch(err) {
                    return
                }
            })
        } catch(err) {
            try {
                if (this.cn.isOpen) {
                    cb(err)
                }
            } catch(err) { 
                return
            }
        }
    }

    async getFirstMessageAsync(options, encoding) {
        return new Promise((resolve, reject) => {
            this.getMessage(options, (err, data) => {
                if (err) {
console.log('QUEUE.getFirstMessageAsync()', err)
                    return reject(err)
                }
                if (data.constructor.name === 'Warning') {
                    return reject(new NotFoundError('not found', 'IMQO0100', options, 'GETFIRST'))
                }
                this.getDone(err => {
                    noop(err) // ignore
                })
                resolve(data)
            }, encoding)
        })
    }

    getDone(cb) {
        try {
            if (this.cn.isClosed || this.isClosed) {
                return
            }
            GetDone(this.#hQu, cb)
        } catch(err) { noop() }
    }
    
    async getDoneAsync() {
        return new Promise(resolve => {
            this.getDone(resolve)
        })
    }

}

Object.freeze(Queue)

export default Queue

