import process from 'process'
import {
    InvalidOperationError,
    ArgumentError,
} from './imqo-errors.mjs'
import {
    EventEmitter,
} from 'events'
import {
    MQC,
    MQCSP,
    MQCNO,
    MQCD,
    setTuningParameters,
    // Connx,
    // Disc,
} from 'ibmmq'
import {
    Connx,
    Disc
} from './imqo-async.mjs'
import Queue from './imqo-queue.mjs'
import QueueReader from './imqo-queue-reader.mjs'

const MAX_DYN_Q_NAME_LENGTH = 32
const openConnectionCache = new Map()

class Connection extends EventEmitter {

    #hCn = MQC.MQHC_UNUSABLE_HCONN
    #mqManagerName = ''
    #sslProvider
    #asClient = false

    static initialize(endianess, encoding) {
        Queue.initialize(endianess === 0? 0 : 1, encoding || 'utf8', Connection)
        QueueReader.initialize(endianess === 0? 0 : 1, encoding || 'utf8', Connection)
    }
    
    constructor(mqManagerName, sslProvider = undefined) {
        const verb = 'CREATE_CONNECTION_WRAPPER'
        if (!mqManagerName || typeof mqManagerName !== 'string') {
            throw new ArgumentError('no queue manager name specified', 'IMQO0001', null, verb)
        }
        super()
        this.#sslProvider = sslProvider
        this.#mqManagerName = mqManagerName
    }

//#region properties
    get mqManagerName() {
        return this.#mqManagerName
    }
    get hCn() {
        return (this.#hCn || MQC.MQHC_UNUSABLE_HCONN)
    }
    get isOpen() {
        return !this.isClosed
    }
    get isClosed() {
        return this.#hCn === MQC.MQHC_UNUSABLE_HCONN
    }
//#endregion properties

//#region internal 
    static setBindings(cno, options, verb) {
        if (options.local && options.client) {
            throw new ArgumentError('connection cannot be both local and client', 'IMQO0002', options, verb)
        }
        if (options.standard) {
            cno.Options = MQC.MQCNO_STANDARD_BINDING
            return
        }
        cno.Options = MQC.MQCNO_STANDARD_BINDING       // 0
        if (options.shared) {
            cno.Options = MQC.MQCNO_SHARED_BINDING     // 256
        }
        if (options.isolated) {
            cno.Options = MQC.MQCNO_ISOLATED_BINDING    // 512
        }
        if (options.local) {
            cno.Options |= MQC.MQCNO_LOCAL_BINDING      // 1024
        }
        if (options.client) {
            cno.Options = MQC.MQCNO_CLIENT_BINDING      // 2048
        }                                               
    }

    static getAuthOptions(authentication, options, verb) {
        const sp = new MQCSP()
        switch(authentication.type) {
            case 'userCredentials':
                if (!authentication.userCredentials) {
                    throw new ArgumentError('missing user credentials', 'IMQO0040', options, verb)
                }
                sp.UserId = authentication.userCredentials.userId
                sp.Password = authentication.userCredentials.password
                sp._authenticationType = MQC.MQCSP_AUTH_USER_ID_AND_PWD
                break
            default:
                break
        }
        return sp
    }

    static setMqOptions(options, sslProvider, verb) {
        const cno = new MQCNO()
        if (options.applicationName && MQC.MQCNO_CURRENT_VERSION >= 7) {
            cno.ApplName = options.applicationName
        }
        if (options.bindings) {
            this.setBindings(cno, options.bindings, verb)
        }
        const cd = new MQCD()
        cd.ConnectionName = options.connectionName || ''
        cd.ChannelName = options.channelName || ''
        if (cd.options === MQC.MQCNO_CLIENT_BINDING) {
            if (!cd.connectionName) {
                throw new ArgumentError('missing connection name for client binding', 'IMQO0003', options, verb)
            }
            if (!cd.channelName) {
                throw new ArgumentError('missing channel name for client binding', 'IMQO0004', options, verb)
            }
        }
        cno.ClientConn = cd
        if (sslProvider) {
            cno.SSLConfig = sslProvider.configure(cd, options.sslOptions, options, verb)
        }
        if (options.authentication) {
            cno.SecurityParms = this.getAuthOptions(options.authentication, options, verb)
        }
        return cno
    }

    async connectAsClient(options = {}) {
        options = {
            ...options,
            bindings: {
                ...options.bindings,
                client: true,
            },
        }
        return await this.connect(options)
    }

    async connect(options = {}) {
        const verb = 'CONNECT'
        if (this.isOpen) {
            return this
        }
        const cno = this.#sslProvider?
            Connection.setMqOptions(options, this.#sslProvider, verb) :
            new MQCNO()
        const hCn = await Connx(this.#mqManagerName, cno)
        this.#hCn = hCn
        this.#asClient = options?.bindings?.client === true
        openConnectionCache.set(hCn._hConn, this)
        this.emit('open', {
            handle: hCn,
            mqManager: this.#mqManagerName,
        })
        return this
    }
//#endregion internal

//#region public connection management operations
    static async open(mqManagerName, options = {}, sslProvider) {
        const cn = new Connection(mqManagerName, sslProvider, options)
        return await cn.connect(options)
    }

    static async openAsClient(mqManagerName, options = {}, sslProvider) {
        const cn = new Connection(mqManagerName, sslProvider)
        return await cn.connectAsClient(options)
    }

    static getConnectionByHandle(hCn) {
        return openConnectionCache.get(hCn?._hConn)
    }
    /**
     * 
     */
    async close() {
        const verb ='CLOSE'
        if (this.isClosed) {
            throw new InvalidOperationError('connection is already closed', 'IMQO0099', null, verb)
        }
        try {
            await Disc(this.#hCn)
        // eslint-disable-next-line no-empty
        } catch(err) {}
        openConnectionCache.delete(this.#hCn._hConn)
        this.#hCn = MQC.MQHC_UNUSABLE_HCONN
        this.emit('closed', this)
        return this
    }
//#endregion creation and connection operations

//#region message queue management
    checkReady(queueName, options, verb) {
        if (this.isClosed) {
            throw new InvalidOperationError('connection closed', 'IMQO0101', options, verb)
        }
        if (!queueName || typeof queueName !== 'string') {
            throw new ArgumentError('no queue name specified', 'IMQO0005', options, verb)
        }
    }

    /**
     * MQ OBJECT OPEN OPTIONS
     * 
     * MQOO_ALTERNATE_USER_AUTHORITY  :4096
     * MQOO_BIND_AS_Q_DEF             :0
     * MQOO_BIND_NOT_FIXED            :32768
     * MQOO_BIND_ON_GROUP             :4194304
     * MQOO_BIND_ON_OPEN              :16384
     * MQOO_BROWSE                    :8
     * MQOO_CO_OP                     :131072
     * MQOO_FAIL_IF_QUIESCING         :8192
     * MQOO_INPUT_AS_Q_DEF            :1
     * MQOO_INPUT_EXCLUSIVE           :4
     * MQOO_INPUT_SHARED              :2
     * MQOO_INQUIRE                   :32
     * MQOO_NO_MULTICAST              :2097152
     * MQOO_NO_READ_AHEAD             :524288
     * MQOO_OUTPUT                    :16
     * MQOO_PASS_ALL_CONTEXT          :512
     * MQOO_PASS_IDENTITY_CONTEXT     :256
     * MQOO_READ_AHEAD                :1048576
     * MQOO_READ_AHEAD_AS_Q_DEF       :0
     * MQOO_RESOLVE_LOCAL_Q           :262144
     * MQOO_RESOLVE_LOCAL_TOPIC       :262144
     * MQOO_RESOLVE_NAMES             :65536
     * MQOO_SAVE_ALL_CONTEXT          :128
     * MQOO_SET                       :64
     * MQOO_SET_ALL_CONTEXT           :2048
     * MQOO_SET_IDENTITY_CONTEXT      :1024
     */

    /**
     * This method open an exisiting dynamic reply queue
     * in read mode, i.e. for GET operations.
     * @param {*} queueName - if last character is '*', then the maximum length is 32
     * @param {*} options Allowed Properties:
     *                      bool read             - nonexclusive GET
     *                      bool readEclusive     - exclusive GET
     *                      string modelQueueName - name of existing model queue (required)
     *                      bool tx               - participates in transaction (optional)
     *                    If both read and readExclusive are be set to true or none is set,
     *                    then readExclusive will be set to true
     */
    async createDynamicReplyQueue(queueName, options = {}) {
        const verb ='CREATE_QUEUE'
        if (this.#asClient) {
            throw new InvalidOperationError('client connections unable to create dynamic queues', 'IMQO0098', options, verb)
        }
        // readExclusive setting dominates read setting
        options.read = options.read && !options.readExclusive
        options = {
            ...options,
            readExclusive: !options.read,
            dynamic: true,
        }
        this.checkReady(queueName, options, verb)
        if ((!options.read === true && !options.readExclusive === true) ||
            (options.read === true && options.readExclusive === true)) {
            throw new ArgumentError('exactly on of read and readExclusive options must be true', 'IMQO0006', options, verb)
        }
        if (queueName.endsWith('*') && queueName.length > MAX_DYN_Q_NAME_LENGTH) {
            throw new ArgumentError('name prefix of a dynamic queue must not exceed 32 characters', 'IMQO0007', options, verb)
        }
        /**
         * @TODO: verify platform string for z/OS
         */
        if (process.platform === 'z/OS' && queueName.indexOf('*') === 0) {
            throw new ArgumentError('\'*\' must not be the first character of a dynamic queue name on z/OS', 'IMQO0008', options, verb)
        }
        let queue = new Queue(this, queueName)
        await queue.open(options)
        this.emit('create_queue', queueName)
        return queue
    }

    /**
     * This method opens an existing queue
     * in write mode, i.e. for PUT operations.
     * @param {*} queueName - name of the queue
     * @param {*} options Allowed Properties:
     *                      bool tx               - participates in transaction (optional, default is false)
     */
    async createQueueWriter(queueName, options = {}) {
        let queue = null
        const verb = 'CREATE_QUEUEWRITER'
        this.checkReady(queueName, options, verb)
        options = {
            tx: false,
            ...options,
            write: true,
            read: false,
            readExclusive: false,
        }
        queue = new Queue(this, queueName)
        await queue.open(options)
        this.emit('open_queue', queueName)
        return queue
    }

    /**
     * This method opens an existing queue
     * as a readable stream, i.e. for GET operations.
     * @param {*} queueName - name of the queue
     * @param {*} options Allowed Properties:
     *                      bool tx               - participates in transaction (optional, default is false)
     */
     async createReadableQueueStream(queueName, options = {}, endianess, encoding) {
        const verb = 'CREATE_READABLE_QUEUE_STREAM'
        let readable = this.checkReady(queueName, options, verb)
        if (readable) {
            return readable
        }
        options = {
            tx: false,
            ...options,
            write: false,
            read: true,
            readExclusive: true,
        }
        return await (new QueueReader(this, queueName, options, endianess, encoding)).open()
    }

    /**
     * This method opens an existing queue
     * in read mode, i.e. for GET operations.
     * @param {*} queueName - name of the queue
     * @param {*} options Allowed Properties:
     *                      bool tx               - participates in transaction (optional, default is false)
     */
    async createQueueReader(queueName, options = {}) {
        const verb = 'CREATE_QUEUE_READER'
        let queue = this.checkReady(queueName, options, verb)
        if (queue) {
            return queue
        }
        options = {
            tx: false,
            ...options,
            write: false,
            read: true,
            readExclusive: false,
        }
        queue = new Queue(this, queueName)
        await queue.open(options)
        this.emit('open_queue', queueName)
        return queue
    }

    /**
     * This method opens an exisiting queue
     * in exclusive read mode, i.e. for GET operations.
     * @param {*} queueName - name of the queue
     * @param {*} options Allowed Properties:
     *                      bool tx               - participates in transaction (optional, default is false)
     */
    async openQueueForReadExclusive(queueName, options = {}) {
        const verb = "READ_EXCLUSIVE"
        this.checkReady(queueName, options, verb)
        options = {
            ...options,
            write: false,
            read: false,
            readExclusive: true,
        }
        const queue = new Queue(this, queueName)
        await queue.open(options)
        this.emit('open_queue', queueName)
        return queue
    }
//#endregion message queue management
}

async function provideConnection(mqManagerName) {
    return await Connection.open(mqManagerName)
}

export {
    Connection,
    setTuningParameters,
    provideConnection,
}
