import { ArgumentError } from './imqo-errors.mjs'
import { MQC, MQSCO } from 'ibmmq'
import cipherSpecs from './imqo-ssl-cipherspecs.mjs'

class SslProvider {
    #cipherSpec
    #clientAuthentication
    #certificateLabel
    #keyRepository

    constructor(options = { }, verb) { // SSL options
        options = {
            cipherSpec: 'TLS_RSA_WITH_AES_256_CBC_SHA256',
            clientAuthentication: 'optional',
            ...options
        }
        if (!(cipherSpecs.map(s => s.name).includes(options.cipherSpec))) {
            throw new ArgumentError(`invalid cipher spec '${options.cipherSpec}'`, options, verb)
        }
        if (!['neverRequired', 'always', 'optional'].includes(options.clientAuthentication)) {
            throw new ArgumentError(`invalid client authentication option '${options.clientAuthentication}'`, options, verb)
        }
        this.#cipherSpec = options.cipherSpec
        this.#clientAuthentication = this.getClientAuth(options.clientAuthentication)
        this.#certificateLabel = options.certificateLabel
        this.#keyRepository = options.keyRepository
    }

    getClientAuth(option) {
        const verb = 'CHECK_CLIENT_AUTH'
        switch(option) {
            case 'neverRequired':
                return MQC.MQSCA_NEVER_REQUIRED
            case 'always':
                return  MQC.MQSCA_ALWAYS_REQUIRED
            case 'optional':
                return MQC.MQSCA_OPTIONAL
            default:
                throw new ArgumentError(`invalid client authentication option '${option}'`, null, verb)
        }
    }

    configure(cd) { // MQCD connection descriptor
        cd.SSLCipherSpec = this.#cipherSpec
        cd.SSLClientAuth = this.#clientAuthentication
        const sco = new MQSCO() // MQCSO connection security options
        sco.CertificateLabel = this.#certificateLabel
        sco.KeyRepository = this.#keyRepository
        return sco
    }
}

export default SslProvider
