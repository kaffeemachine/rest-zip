import {
    MQC,
    MQMD,
    MQGMO,
    MQPMO,
} from 'ibmmq'
import { ArgumentError } from './imqo-errors.mjs'
import {
    maxReliableInt,
    numberEncoding,
} from './imqo-constants.mjs'
import assert from 'assert/strict'

const WAIT_INTERVAL = 100

/**
 * write a ulong (UInt64) to the first 8 bytes of a new 24-byte buffer
 * note that intVal is of type 'number', not 'bigint', and should be
 * precise i.e. < 1240000000000000
 * 
 * @param intVal 
 * @param endianess 
 */
function writeBigUInt64toBuf24 (intVal, endianess) {
    assert(typeof intVal === 'number')
    assert(intVal === intVal % maxReliableInt)
    // eslint-disable-next-line no-undef
    let buf = Buffer.alloc(24)
    buf[endianess === 1? 'writeBigUInt64LE' : 'writeBigUInt64BE'](intVal, 0)
    return buf
}

/**
 * check validity of msgId and correlationId if set
 * @param options
 * @param verb
 */
function checkReferenceIds(options, verb) {
    for (let which of [ 'correlationId', 'msgId']) {
        let id = options[which]
        if (id) {
            if (//typeof id !== 'number' &&
                typeof id !== 'string' &&
                // eslint-disable-next-line no-undef
                !(id instanceof Buffer)
            ) {
                throw new ArgumentError(`${which} must be of type Buffer or String`, 'IMQO0020', options, verb)
            }
            // eslint-disable-next-line no-undef
            if (id instanceof Buffer) {
                if (id.length > 48) {
                    throw new ArgumentError(`${which} buffer length exceeds maximum of 48 bytes`, 'IMQO0022', options, verb)
                }
            }
            if (typeof id === 'string') {
                if (id.length > 48) {
                    throw new ArgumentError(`${which} string length exeeds maximum of 48 bytes`, 'IMQO0024', options, verb)
                }
            }
        }    
    }
}

/**
 *  check validity of put options set
 * @param options { object } holds put options
 * @throws ArgumentError
 */
function checkPutOptions(options, data, verb) {
    verb = verb || 'PUT'
    if (!['DATAGRAM', 'REPLY', 'REPORT', 'REQUEST',].some(
        msgType => msgType === options.msgType
    )) {
        throw new ArgumentError(`invalid message type [${options.msgType}]`, 'IMQO0018', options, verb)
    }
    if (options.correlationId && options.generateCorrelationId) {
        throw new ArgumentError('only one of correlationId and generateCorrelationId may be specified', 'IMQO0019', options, verb)
    }
    if (options.msgId && options.generateMsgId) {
        throw new ArgumentError('only one of msgId and generateMsgId may be specified', 'IMQO0021', options, verb)
    }
    checkReferenceIds(options, verb)
    // eslint-disable-next-line no-undef
    if (typeof data !== 'string' && !(data instanceof Buffer)) {
        throw new ArgumentError('data must be of tpye String or Buffer', 'IMQO0023', options, verb)
    }
}

/***
 * translate options on how the put operation should be performed
 * into a representation understood by MQ (MQMD and MQPMO objects)
 * @param options { Object }  holds options for put operation
 */
function evaluatePutOptions(options, replyQManagerName, endianess, encoding, verb) {
    verb = verb || 'PUT'
    const mqmd = new MQMD()
    const mqpmo = new MQPMO()
    mqpmo.Options = (options.failIfQuiescing === false) ?
        MQC.MQPMO_NONE :
        MQC.MQPMO_FAIL_IF_QUIESCING
    switch (options.msgType) {
        case 'DATAGRAM':
            mqmd.MsgType === MQC.MGMT_DATAGRAM
            break
        case 'REPLY':
            mqmd.MsgType = MQC.MQMT_REPLY
            break
        case 'REPORT':
            mqmd.MsgType = MQC.MQMT_REPORT
            break
        case 'REQUEST':
            mqmd.MsgType = MQC.MQMT_REQUEST
            if (!options.replyQueueName) {
                throw new ArgumentError('reply queue not specified', 'IMQO0016', options, verb)
            }
            // eslint-disable-next-line no-undef
            mqmd.ReplyToQ = Buffer.from(options.replyQueueName, encoding)
            // eslint-disable-next-line no-undef
            mqmd.ReplyToQMgr = Buffer.from(options.replyQueueManagerName || replyQManagerName, encoding)
            if (!options.correlationId &&
                !options.generateCorrelationId && 
                !options.msgId &&
                !options.generateMsgId
            ) {
                throw new ArgumentError('for message type REQUEST, one option of \'correlationId\',' + 
                    '\'generateCorrelationId\', \'msgId\', or \'generateMsgId\' must be set', 'IMQO0025', options, verb)
            }
            break
        default:
            throw new ArgumentError('message type not set', 'IMQO0017', options, verb)
    }
    if (options.msgId) {
        // checkReferenceIds() should have been called before
        if (typeof options.msgId === 'number') {
                mqmd.MsgId = writeBigUInt64toBuf24(options.msgId, endianess)
        } else {
            // eslint-disable-next-line no-undef
            if (options.msgId instanceof Buffer) {
                mqmd.MsgId = options.msgId
            } else if (typeof options.msgId === 'string') {
                // eslint-disable-next-line no-undef
                mqmd.MsgId = Buffer.from(options.msgId, numberEncoding)
            }
        }
    } else if (options.generateMsgId) {
        mqpmo.Options |= MQC.MQPMO_NEW_MSG_ID
    }
    if (options.correlationId) {
        // checkReferenceIds() should have been called before
        if (typeof options.correlationId === 'number') {
            mqmd.CorrelId = writeBigUInt64toBuf24(options.correlationId, endianess)
        } else {
            // eslint-disable-next-line no-undef
            if (options.correlationId instanceof Buffer) {
                mqmd.CorrelId = options.correlationId
            } else if (typeof options.correlationId === 'string') {
                // eslint-disable-next-line no-undef
                mqmd.CorrelId = Buffer.from(options.correlationId, numberEncoding)
            }
        }
    } else if (options.generateCorrelationId) {
        mqpmo.Options |= MQC.MQPMO_NEW_CORREL_ID
    }
    mqpmo.Options |= (options.tx) ? MQC.MQPMO_SYNCPOINT : MQC.MQPMO_NO_SYNCPOINT
    return { mqmd, mqpmo }
}

function checkGetOptions(options) {
    const verb = 'GET'
    checkReferenceIds(options, verb)
}

/**
     * translate options on how the get operation should be performed
     * into a representation understood by MQ (MQMD and MQGMO objects)
     * @param options { Object }  holds options for get operation
 */
function evaluateGetOptions(options, endianess, encoding) {
    const mqmd = new MQMD()
    const mqgmo = new MQGMO()
    mqgmo.Options = (options.failIfQuiescing === false) ?
        MQC.MQPMO_NONE :
        MQC.MQPMO_FAIL_IF_QUIESCING // default
    mqgmo.Options |= MQC.MQGMO_COMPLETE_MSG
    mqgmo.Options |= (options.tx) ? MQC.MQPMO_SYNCPOINT : MQC.MQPMO_NO_SYNCPOINT
    if (options.wait === false) {
        mqgmo.WaitInterval = 0
        mqgmo.Options |= MQC.MQGMO_NO_WAIT
    } else {
        mqgmo.WaitInterval = options.waitInterval ?? WAIT_INTERVAL
        mqgmo.Options |= MQC.MQGMO_WAIT
    }
    mqgmo.MatchOptions = MQC.MQPMO_NONE
    // checkReferenceIds() should have been called before
    if (options.correlationId) {
        if (typeof options.correlationId === 'number') {
            mqmd.CorrelId = writeBigUInt64toBuf24(options.correlationId, endianess)
        } else if (typeof options.correlationId === 'string') {
            // eslint-disable-next-line no-undef
            mqmd.CorrelId = Buffer.from(options.correlationId, encoding)
        // eslint-disable-next-line no-undef
        } else if (options.correlationId instanceof Buffer) {
            mqmd.CorrelId = options.correlationId
        }
        mqgmo.MatchOptions = MQC.MQMO_MATCH_CORREL_ID
    }
    if (options.msgId) {
        // checkReferenceIds() should have been called before
        mqmd.MsgId = writeBigUInt64toBuf24(options.msgId, endianess)
        mqgmo.MatchOptions = MQC.MQMO_MATCH_MSG_ID
    }
    return { mqmd, mqgmo, options }
}

function numberToBuffer(src)  {
    // eslint-disable-next-line no-undef
    return (src instanceof Buffer)?
        src :
        // eslint-disable-next-line no-undef
        (typeof src === 'string')?
            // eslint-disable-next-line no-undef
            Buffer.from(src, numberEncoding) :
            writeBigUInt64toBuf24(src)
}


export {
    checkPutOptions,
    checkGetOptions,
    evaluatePutOptions,
    evaluateGetOptions,
    writeBigUInt64toBuf24,
    numberToBuffer,
}