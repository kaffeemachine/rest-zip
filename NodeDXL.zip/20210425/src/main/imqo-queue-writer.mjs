import { Writable } from 'stream'

class QueueWriter extends Writable {
    cn
    name
    constructor(connection, name) {
        super()
        this.cn = connection
        this.name = name
    }
}

export default QueueWriter