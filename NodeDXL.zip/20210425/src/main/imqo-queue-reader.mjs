import { Readable } from 'stream'
import Message from './imqo-message.mjs'
import {
    ArgumentError,
    InvalidOperationError,
    MqError,
} from './imqo-errors.mjs'
import {
    MQC,
    Get,
    Open,
    Close,
    MQOD,
    GetDone,
} from 'ibmmq'

import {
    checkGetOptions,
    evaluateGetOptions,
} from './imqo-queue-helpers.mjs'

class QueueReader extends Readable {
    cn
    name    
    endianess   
    options
    hCn    // connection handle
    hQu =  MQC.MQHO_UNUSABLE_HOBJ    // queue handle

    static initialize(...cfg) {
        [ QueueReader.endianess, QueueReader.encoding, ] = cfg
    }

    constructor(connection, name, options, endianess, encoding) {
        super({
            encoding: encoding || QueueReader.encoding,
            objectMode: true,
            emitClose: true,
            hiqhWatherMark: 8192,
        })
        this.cn = connection
        this.name = name
        this.endianess = endianess || QueueReader.endianess
        const verb = 'CREATE'
        if(!name || typeof name !== 'string') {
            throw new ArgumentError('no queue name specified', 'IMQO0009', null, verb)
        }
        if (!connection || !(connection.constructor.name === 'Connection')) {
            throw new ArgumentError('no valid connection object', 'IMQO0010', null, verb)
        }
        if (!connection || connection.isClosed) {
            throw new InvalidOperationError('connection closed', 'IMQO0011', null, verb)
        }
        this.hCn = connection.hCn._hConn
        this.options = options
    }

    async open() {
        return new Promise((resolve, reject) => {
            try {
                const verb = 'OPEN'
                const options = {
                    failIfQuiescing: true,
                    ...this.options,
                }
                let opts = 0
                opts += options.failIfQuiescing? MQC.MQOO_FAIL_IF_QUIESCING : 0
                opts += options.read? MQC.MQOO_INPUT_AS_Q_DEF : 0
                opts += options.readExclusive? MQC.MQOO_INPUT_EXCLUSIVE : 0
                let od = new MQOD()
                od.ObjectQMgrName = this.hCn._name
                if (options.dynamic) {
                    od.ObjectName = options.modelQueueName
                    od.DynamicQName = this.name
                } else {
                    od.ObjectName = this.name
                }
                od.ObjectType = MQC.MQOT_Q
                Open(this.hCn, od, opts, (err, hQu) => {
                    if (err) {
                        let message = err.message
                        if (err.name === 'MQError') {
                            if (err.mqrc === MQC.MQRC_UNKNOWN_OBJECT_NAME) {
                                if (options.dynamic) {
                                    message = `invalid model queue '${options.modelQueueName}' (${err.message})`
                                    return reject(new ArgumentError(message, 'IMQO0012', options, verb))
                                }
                                else {
                                message = `invalid queue name '${this.name}' (${err.message})` 
                                return reject(new ArgumentError(message, 'IMQO0013', options, verb))
                                }
                            } else if (err.mqrc === MQC.MQRC_DYNAMIC_Q_NAME_ERROR) {
                                message =`invalid dyn queue name '${this.name}' (${err.message})`
                                return reject(new ArgumentError(message, 'IMQO0014', options, verb))
                            }
                        }
                        return reject(new MqError(message, err, this.name, 'IMQO0050', options, verb))
                    }
                    this.hQu = hQu
                    this.name = hQu._name
                    resolve(this)
                })
            } catch(err) {
                reject(err)
            }
        })
    }

    _destroy(err, done) {
        const verb = 'DESTROY'
        if (this.cn.isClosed) {
            return done(new InvalidOperationError('connection closed', 'IMQO0101', undefined, verb))
        }
        if (this.destroyed()) {
            return done()
        }
        GetDone(this.hQu, () => {
            const closeOption = MQC.MQCO_NONE
            Close(this.hQu, closeOption, (error, hQu) => {
                if (error) {
                    return done(new MqError(error.message, error, this.name, 'IMQO0051', undefined, verb))
                }
                this.hQu = hQu
                done(err)
            })
        })
    }

    _read() {
        const verb = 'READ'
        if (this.cn.isClosed || this.hQu ===  MQC.MQHO_UNUSABLE_HOBJ ) { // return silently
            return
        }
        const options = {
            readExclusive: this.options.readExclusive || true,
            wait: true,
            waitInterval: this.options.waitForReplyDuration || 300000 // wait up to n millis between while getting replies
        }
        try {
            checkGetOptions(options, verb)
            let { mqmd, mqgmo } = evaluateGetOptions(options, this.endianess, this.readableEncoding)
            Get(this.hQu, mqmd, mqgmo, (err, hObj, gmo, md, buf) => {
                if (err) {
                    if (err.mqrc === MQC.MQRC_NO_MSG_AVAILABLE) {
                        return
                    }
                    return this.emit('error', new MqError(err.message, err, this.name, 'IMQO0053',  options, verb))
                }
                // eslint-disable-next-line no-undef
                if (!this.push(new Message(this.cn, md, Buffer.from(buf), encoding))) {
                    GetDone(this.hQu)
                }
            })
        } catch(err) {
            return this.emit('error', new MqError(err.message, err, this.name, 'IMQO0053',  options, verb))
        }
    }

    get readable() {
        return super.readable() && this.hQu ===  MQC.MQHO_UNUSABLE_HOBJ
    }
}

export default QueueReader
